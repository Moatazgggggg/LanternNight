extends RefCounted
# ذكاء اصطناعي (يعمل عند المضيف فقط): الوحش سكيري + البوتات — مع مستويات صعوبة

# chase, patrol, invest, search, vision, hear, lose, catch, predict, sniff, search_radius
const DIFFS := [
	{"chase": 5.2, "patrol": 2.3, "invest": 3.4, "search": 3.0, "vision": 16.0, "hear": 8.0, "lose": 0.5, "catch": 1.9, "predict": 0.0, "sniff": 0.0, "radius": 10.0},
	{"chase": 5.9, "patrol": 2.7, "invest": 3.9, "search": 3.3, "vision": 21.0, "hear": 11.0, "lose": 0.9, "catch": 2.0, "predict": 0.0, "sniff": 0.0, "radius": 12.0},
	{"chase": 6.6, "patrol": 3.0, "invest": 4.5, "search": 3.8, "vision": 27.0, "hear": 14.0, "lose": 1.3, "catch": 2.2, "predict": 0.3, "sniff": 0.0, "radius": 14.0},
	{"chase": 7.4, "patrol": 3.5, "invest": 5.2, "search": 4.4, "vision": 34.0, "hear": 19.0, "lose": 2.4, "catch": 2.4, "predict": 0.6, "sniff": 0.0, "radius": 18.0},
	{"chase": 8.4, "patrol": 4.0, "invest": 6.0, "search": 5.0, "vision": 44.0, "hear": 26.0, "lose": 4.0, "catch": 2.6, "predict": 0.9, "sniff": 22.0, "radius": 26.0},
]
const BOT_WALK := 3.6
const BOT_RUN := 5.4
const NONE := Vector2i(99999, 99999)

var main
var astar := AStarGrid2D.new()
var cells := {}
var cell_list: Array = []
var n := 41
# حالة الوحش: 0 دورية 1 مطاردة 2 بحث 3 تحقيق 4 توقف بعد الإمساك
var m_state := 0
var m_target := -999
var m_last_seen := Vector3.ZERO
var m_lose_t := 0.0
var m_path: Array = []
var m_i := 0
var m_repath := 0.0
var m_wait := 1.0
var m_queue: Array = []
var m_cur_spot := -1
var m_stuck := 0.0
var m_last_pos := Vector3.ZERO
var m_say_t := 9.0
var m_sniff_t := 12.0
var bots := {}
var tprev := {}
var tvel := {}

func D() -> Dictionary:
	var d: Dictionary = DIFFS[clampi(main.diff, 0, DIFFS.size() - 1)].duplicate()
	if main.monster_type == "granny":
		for k in ["chase", "patrol", "invest", "search"]:
			d[k] = float(d[k]) * 0.88
		d["hear"] = float(d["hear"]) * 1.5
	return d

# ───────────── شبكة المسارات (تُبنى على دفعات حتى لا يتجمد الجهاز) ─────────────
func build_grid(space: PhysicsDirectSpaceState3D, h: float, start: Vector3) -> void:
	n = int(ceil(h)) + 1
	astar = AStarGrid2D.new()
	astar.region = Rect2i(-n, -n, n * 2 + 1, n * 2 + 1)
	astar.cell_size = Vector2.ONE
	astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	astar.default_compute_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	astar.default_estimate_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	astar.update()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.62
	shape.height = 2.2
	var q := PhysicsShapeQueryParameters3D.new()
	q.shape = shape
	q.collision_mask = 1
	var free := {}
	var count := 0
	for ix in range(-n, n + 1):
		for iz in range(-n, n + 1):
			q.transform = Transform3D(Basis(), Vector3(ix, 1.2, iz))
			if main.get_world_3d().direct_space_state.intersect_shape(q, 1).is_empty():
				free[Vector2i(ix, iz)] = true
			else:
				astar.set_point_solid(Vector2i(ix, iz), true)
			count += 1
			if count % 2500 == 0:
				await main.get_tree().process_frame
	cells.clear()
	var s := Vector2i(roundi(start.x), roundi(start.z))
	var stack := [s]
	cells[s] = true
	while not stack.is_empty():
		var c: Vector2i = stack.pop_back()
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var nb: Vector2i = c + d
			if free.has(nb) and not cells.has(nb):
				cells[nb] = true
				stack.append(nb)
	cell_list = cells.keys()
	for k in free:
		if not cells.has(k):
			astar.set_point_solid(k, true)

func reset() -> void:
	m_state = 0
	m_target = -999
	m_path = []
	m_i = 0
	m_wait = 1.0
	m_queue = []
	m_cur_spot = -1
	m_say_t = 9.0
	m_sniff_t = 12.0
	bots.clear()
	tprev.clear()
	tvel.clear()

func nearest_cell(p: Vector3) -> Vector2i:
	var c := Vector2i(roundi(p.x), roundi(p.z))
	if cells.has(c):
		return c
	for r in range(1, 8):
		for dx in range(-r, r + 1):
			for dz in range(-r, r + 1):
				if absi(dx) != r and absi(dz) != r:
					continue
				var cc := Vector2i(c.x + dx, c.y + dz)
				if cells.has(cc):
					return cc
	return NONE

func find_path(a: Vector3, b: Vector3) -> Array:
	var ca := nearest_cell(a)
	var cb := nearest_cell(b)
	var out := []
	if ca == NONE or cb == NONE:
		return out
	for p in astar.get_point_path(ca, cb):
		out.append(Vector3(p.x, 0, p.y))
	return out

func random_point(min_d: float, max_d: float, from: Vector3) -> Vector3:
	for i in 30:
		var c: Vector2i = cell_list[randi() % cell_list.size()]
		var p := Vector3(c.x, 0, c.y)
		var d := p.distance_to(from)
		if d >= min_d and d <= max_d:
			return p
	var c2: Vector2i = cell_list[randi() % cell_list.size()]
	return Vector3(c2.x, 0, c2.y)

func pick_points(count: int, avoid: Array, min_avoid: float, sep: float) -> Array:
	var pool := cell_list.duplicate()
	pool.shuffle()
	var out: Array = []
	var relax := 1.0
	for attempt in 3:
		for c in pool:
			if out.size() >= count:
				break
			var p := Vector3(c.x, 0, c.y)
			var ok := true
			for a in avoid:
				if p.distance_to(a) < min_avoid * relax:
					ok = false
					break
			if ok:
				for o in out:
					if p.distance_to(o) < sep * relax:
						ok = false
						break
			if ok:
				out.append(p)
		if out.size() >= count:
			break
		relax *= 0.6
	return out

# ───────────── أدوات الحركة ─────────────
func _los(space: PhysicsDirectSpaceState3D, a: Vector3, b: Vector3) -> bool:
	var q := PhysicsRayQueryParameters3D.create(a, b, 1)
	return space.intersect_ray(q).is_empty()

func _steer(node, target: Vector3, speed: float, delta: float) -> void:
	var d: Vector3 = target - node.global_position
	d.y = 0.0
	if d.length() < 0.05:
		node.velocity = Vector3.ZERO
		return
	d = d.normalized()
	node.velocity = node.velocity.move_toward(d * speed, 34.0 * delta)
	node.move_and_slide()
	node.global_position.y = 0.0
	var want := atan2(-d.x, -d.z)
	node.rotation.y = lerp_angle(node.rotation.y, want, minf(1.0, 10.0 * delta))
	node.target_pos = node.global_position
	node.target_yaw = node.rotation.y

func _follow(node, path: Array, idx: int, speed: float, delta: float) -> int:
	if idx >= path.size():
		node.velocity = Vector3.ZERO
		return idx
	var wp: Vector3 = path[idx]
	var flat: Vector3 = wp - node.global_position
	flat.y = 0.0
	if flat.length() < 0.55:
		idx += 1
		if idx >= path.size():
			node.velocity = Vector3.ZERO
			return idx
		wp = path[idx]
	_steer(node, wp, speed, delta)
	return idx

func _spots_near(pos: Vector3, radius: float) -> Array:
	var out := []
	var list: Array = main.cur_map.spots
	for i in list.size():
		var d: float = (list[i]["pos"] as Vector3).distance_to(pos)
		if d < radius:
			out.append([d, i])
	out.sort_custom(func(a, b): return a[0] < b[0])
	var res := []
	for o in out:
		res.append(o[1])
	return res

func _alive_humans() -> Array:
	var out := []
	for id in main.players:
		var p = main.players[id]
		if p.kind == "human" and not p.caught and not p.underground:
			out.append(p)
	return out

func _update_vel(delta: float) -> void:
	for id in main.players:
		var p = main.players[id]
		var pos: Vector3 = p.global_position
		if tprev.has(id) and delta > 0.0:
			var v: Vector3 = (pos - tprev[id]) / delta
			v.y = 0.0
			tvel[id] = (tvel[id] as Vector3).lerp(v, 0.25) if tvel.has(id) else v
		tprev[id] = pos

# ───────────── الوحش ─────────────
func tick_monster(delta: float, active: bool) -> void:
	var mon = main.players.get(0)
	if mon == null:
		return
	if not active:
		mon.velocity = Vector3.ZERO
		return
	var dd := D()
	_update_vel(delta)
	var space: PhysicsDirectSpaceState3D = main.get_world_3d().direct_space_state
	var mp: Vector3 = mon.global_position
	var fwd: Vector3 = -mon.global_transform.basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	var best := -999
	var bd := 1e9
	var heard := Vector3.ZERO
	var has_heard := false
	for id in main.players:
		var p = main.players[id]
		if p.is_monster or p.caught or p.hidden or p.underground:
			continue
		var to: Vector3 = p.global_position - mp
		to.y = 0.0
		var d := to.length()
		var cone := 0.4 if main.diff < 3 else 0.1
		if d < float(dd["vision"]) and (d < 5.0 or fwd.dot(to / maxf(d, 0.01)) > cone):
			if _los(space, mp + Vector3(0, 1.8, 0), p.global_position + Vector3(0, 1.2, 0)):
				if d < bd:
					bd = d
					best = id
		if p.speed_est > 5.0 and d < float(dd["hear"]):
			has_heard = true
			heard = p.global_position
	if best != -999:
		if m_state != 1 and m_state != 4:
			main.on_monster_chase()
		if m_state != 4:
			m_state = 1
			m_target = best
			m_last_seen = main.players[best].global_position
			m_lose_t = 0.0
	elif m_state == 1:
		m_lose_t += delta
		if m_lose_t > float(dd["lose"]):
			m_state = 2
			m_queue = _spots_near(m_last_seen, float(dd["radius"]))
			m_path = []
			m_wait = 0.0
			m_cur_spot = -1
	elif has_heard and (m_state == 0 or m_state == 3):
		m_state = 3
		if m_path.is_empty() or m_repath <= 0.0:
			m_path = find_path(mp, heard)
			m_i = 0
			m_repath = 1.0
	# شمّ الرائحة (الجحيم): يعرف مكان أحد اللاعبين كل فترة
	if float(dd["sniff"]) > 0.0 and (m_state == 0 or m_state == 3):
		m_sniff_t -= delta
		if m_sniff_t <= 0.0:
			m_sniff_t = float(dd["sniff"])
			var hs := _alive_humans()
			if not hs.is_empty():
				var tgt = hs[randi() % hs.size()]
				m_state = 3
				m_path = find_path(mp, tgt.global_position)
				m_i = 0
	mon.mstate = 1 if m_state == 1 else (2 if (m_state == 2 or m_state == 3) else 0)
	m_repath -= delta
	m_say_t -= delta
	m_stuck += delta
	if m_stuck > 1.0:
		if mp.distance_to(m_last_pos) < 0.4 and m_state != 4 and m_wait <= 0.0 and mon.velocity.length() > 0.5:
			m_path = []
			m_repath = 0.0
		m_last_pos = mp
		m_stuck = 0.0
	match m_state:
		0:
			# الصعب فما فوق: يفتش الأماكن المشغولة القريبة
			if main.diff >= 3:
				for si in main.occupied.keys():
					var sp: Vector3 = main.cur_map.spots[si]["pos"]
					if sp.distance_to(mp) < 6.0 and randf() < delta * (0.5 if main.diff == 3 else 1.0):
						m_state = 2
						m_queue = [si]
						m_path = []
						m_wait = 0.0
						m_cur_spot = -1
						return
			if m_wait > 0.0:
				m_wait -= delta
				mon.velocity = Vector3.ZERO
			elif m_path.is_empty() or m_i >= m_path.size():
				m_wait = randf_range(0.8, 2.0)
				var goal: Vector3
				var hs2 := _alive_humans()
				if main.diff >= 3 and not hs2.is_empty() and randf() < 0.55:
					var tgt2 = hs2[randi() % hs2.size()]
					goal = tgt2.global_position + Vector3(randf_range(-14, 14), 0, randf_range(-14, 14))
				else:
					goal = random_point(15.0, 60.0, mp)
				m_path = find_path(mp, goal)
				m_i = 0
			else:
				m_i = _follow(mon, m_path, m_i, float(dd["patrol"]), delta)
		1:
			var tp = main.players.get(m_target)
			if tp == null or tp.caught or tp.underground:
				m_state = 2
				m_queue = _spots_near(m_last_seen, float(dd["radius"]))
				m_path = []
				m_wait = 0.0
				return
			var tpos: Vector3 = tp.global_position
			var vv: Vector3 = tvel.get(m_target, Vector3.ZERO)
			var aim: Vector3 = tpos + vv * float(dd["predict"])
			var flat: Vector3 = tpos - mp
			flat.y = 0.0
			if flat.length() < float(dd["catch"]):
				main.server_monster_catch(m_target)
				m_state = 4
				m_wait = 3.9 if main.monster_type == "scary" else 2.3
				mon.velocity = Vector3.ZERO
				return
			if flat.length() < 10.0 and _los(space, mp + Vector3(0, 1.6, 0), tpos + Vector3(0, 1.0, 0)):
				_steer(mon, aim, float(dd["chase"]), delta)
			else:
				if m_repath <= 0.0 or m_path.is_empty():
					m_path = find_path(mp, aim)
					m_i = 0
					m_repath = 0.3
				m_i = _follow(mon, m_path, m_i, float(dd["chase"]), delta)
		2:
			if m_wait > 0.0:
				m_wait -= delta
				mon.velocity = Vector3.ZERO
				if m_wait <= 0.0 and m_cur_spot >= 0:
					main.server_check_spot(m_cur_spot)
					m_cur_spot = -1
			elif m_path.is_empty() or m_i >= m_path.size():
				if m_queue.is_empty():
					m_state = 0
					m_path = []
					m_wait = 0.5
				else:
					m_cur_spot = m_queue.pop_front()
					m_path = find_path(mp, main.cur_map.spots[m_cur_spot]["pos"])
					m_i = 0
			else:
				m_i = _follow(mon, m_path, m_i, float(dd["search"]), delta)
				if m_i >= m_path.size():
					m_wait = 1.2
			if m_say_t <= 0.0:
				m_say_t = randf_range(10.0, 16.0)
				main.on_monster_say(main.ms_sound("where"))
		3:
			if m_path.is_empty() or m_i >= m_path.size():
				m_state = 2
				m_queue = _spots_near(mp, float(dd["radius"]) * 0.8)
				m_path = []
				m_wait = 0.6
				m_cur_spot = -1
			else:
				m_i = _follow(mon, m_path, m_i, float(dd["invest"]), delta)
		4:
			m_wait -= delta
			mon.velocity = Vector3.ZERO
			if m_wait <= 0.0:
				m_state = 2
				m_queue = _spots_near(mp, float(dd["radius"]))
				m_path = []
				m_wait = 0.0
				m_cur_spot = -1

func pick_from(cands: Array, count: int, sep: float) -> Array:
	var pool := []
	for c in cands:
		var cc := nearest_cell(c)
		if cc != NONE and Vector2(cc.x - c.x, cc.y - c.z).length() < 1.6:
			pool.append(c)
	pool.shuffle()
	var out := []
	for c in pool:
		if out.size() >= count:
			break
		var ok := true
		for o in out:
			if c.distance_to(o) < sep:
				ok = false
		if ok:
			out.append(c)
	for c in pool:
		if out.size() >= count:
			break
		if not out.has(c):
			out.append(c)
	return out

func hear(pos: Vector3, radius: float) -> void:
	var mon = main.players.get(0)
	if mon == null or m_state == 1 or m_state == 4:
		return
	if mon.global_position.distance_to(pos) < radius:
		m_state = 3
		m_path = find_path(mon.global_position, pos)
		m_i = 0
		m_repath = 1.5

# ───────────── البوتات ─────────────
func tick_bot(id: int, delta: float, left: Array, car_ready: bool, car_pos: Vector3) -> void:
	var b = main.players.get(id)
	var mon = main.players.get(0)
	if b == null or mon == null or b.caught or b.hidden or b.underground:
		return
	if not bots.has(id):
		bots[id] = {"mode": "part", "path": [], "i": 0, "repath": 0.0, "spot": -1, "goal_k": -1}
	var st: Dictionary = bots[id]
	var bp: Vector3 = b.global_position
	var md := bp.distance_to(mon.global_position)
	var threat: bool = md < 9.0 or (md < 18.0 and mon.mstate == 1)
	if threat and st["mode"] != "hide" and main.can_hide(id):
		var best := -1
		var bd := 1e9
		var list: Array = main.cur_map.spots
		for i in list.size():
			if main.occupied.has(i):
				continue
			var sp: Vector3 = list[i]["pos"]
			var d := sp.distance_to(bp)
			var away := sp.distance_to(mon.global_position)
			if d < 25.0 and away > 5.0 and d < bd:
				bd = d
				best = i
		if best >= 0:
			st["mode"] = "hide"
			st["spot"] = best
			st["path"] = find_path(bp, list[best]["pos"])
			st["i"] = 0
	var speed := BOT_RUN if threat else BOT_WALK
	st["repath"] = float(st["repath"]) - delta
	match st["mode"]:
		"hide":
			var sp2: Vector3 = main.cur_map.spots[st["spot"]]["pos"]
			if bp.distance_to(sp2) < 2.7:
				main.do_hide_req(id, st["spot"])
				st["mode"] = "part"
				st["path"] = []
			else:
				st["i"] = _follow(b, st["path"], st["i"], speed, delta)
				if st["i"] >= st["path"].size():
					st["mode"] = "part"
		_:
			var goal := Vector3.ZERO
			var have := false
			var gk := -1
			if not left.is_empty():
				var bdp := 1e9
				for e in left:
					var hp: Vector3 = e[1]
					var d2: float = hp.distance_to(bp)
					if d2 < bdp:
						bdp = d2
						goal = hp
						gk = e[0]
						have = true
			elif car_ready:
				goal = car_pos + Vector3(0, 0, 4.0)
				have = true
			if have:
				if gk >= 0 and main.is_pit_part(gk) and Vector2(bp.x - goal.x, bp.z - goal.z).length() < 2.6:
					main.do_dive(id, gk)
					st["path"] = []
					return
				if st["path"].is_empty() or st["i"] >= st["path"].size() or float(st["repath"]) <= 0.0:
					st["path"] = find_path(bp, goal)
					st["i"] = 0
					st["repath"] = 2.0
				st["i"] = _follow(b, st["path"], st["i"], speed, delta)
			else:
				b.velocity = Vector3.ZERO
