extends CharacterBody3D
# لاعب أو وحش: مجسّم بشري متحرك + كاميرا منظور أول + كشاف + أصوات

const SHIRTS := [Color(0.25, 0.55, 0.95), Color(0.3, 0.8, 0.4), Color(0.95, 0.75, 0.2), Color(0.8, 0.4, 0.9)]

var pid := 0
var is_seeker := false
var caught := false
var hidden := false
var hide_spot := -1
var ret_pos := Vector3.ZERO
var target_pos := Vector3.ZERO
var target_yaw := 0.0
var target_pitch := 0.0
var is_local := false
var eye_h := 1.55
var model: Node3D
var head: Node3D
var larm: Node3D
var rarm: Node3D
var lleg: Node3D
var rleg: Node3D
var cam: Camera3D
var flash: SpotLight3D
var voice: AudioStreamPlayer3D
var stepper: AudioStreamPlayer3D
var snd := {}
var anim_t := 0.0
var step_acc := 0.0
var bob_t := 0.0
var last_pos := Vector3.ZERO
var speed_est := 0.0
var pitch := 0.0

func _bmesh(parent: Node3D, size: Vector3, col: Color, pos: Vector3, emissive: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 0.85
	if emissive:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = 2.5
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi

func _smesh(parent: Node3D, r: float, col: Color, pos: Vector3, emissive: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	sm.radial_segments = 10
	sm.rings = 5
	mi.mesh = sm
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 0.8
	if emissive:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = 6.0
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi

func _cone(parent: Node3D, r: float, h: float, col: Color, pos: Vector3, rot: Vector3) -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0
	cm.bottom_radius = r
	cm.height = h
	cm.radial_segments = 6
	cm.rings = 1
	mi.mesh = cm
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)

func _pivot(parent: Node3D, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	parent.add_child(n)
	return n

func setup(id: int, nm: String, idx: int, monster: bool, sounds: Dictionary, font: Font) -> void:
	pid = id
	is_seeker = monster
	snd = sounds
	name = str(id)
	collision_layer = 2
	collision_mask = 1
	var rad := 0.6 if monster else 0.38
	var hgt := 3.0 if monster else 1.7
	eye_h = 2.8 if monster else 1.55
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = rad
	cap.height = hgt
	cs.shape = cap
	cs.position.y = hgt * 0.5
	add_child(cs)
	model = Node3D.new()
	add_child(model)
	if monster:
		_build_monster()
		model.scale = Vector3.ONE * 1.8
	else:
		_build_human(idx)
	# صوت
	voice = AudioStreamPlayer3D.new()
	voice.unit_size = 8.0
	voice.max_distance = 70.0
	voice.volume_db = 6.0
	voice.position.y = 1.6
	add_child(voice)
	stepper = AudioStreamPlayer3D.new()
	stepper.stream = snd.get("step")
	stepper.unit_size = 5.0
	stepper.max_distance = 28.0
	stepper.volume_db = 8.0 if monster else -2.0
	add_child(stepper)
	if not monster:
		var tag := Label3D.new()
		tag.text = nm
		tag.font = font
		tag.font_size = 48
		tag.pixel_size = 0.005
		tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		tag.position.y = 2.05
		tag.outline_size = 10
		tag.visibility_range_end = 12.0
		add_child(tag)

func _build_human(idx: int) -> void:
	var skin := Color(0.85, 0.65, 0.5)
	var pants := Color(0.15, 0.17, 0.25)
	var shirt: Color = SHIRTS[idx % SHIRTS.size()]
	lleg = _pivot(model, Vector3(-0.13, 0.8, 0))
	rleg = _pivot(model, Vector3(0.13, 0.8, 0))
	_bmesh(lleg, Vector3(0.18, 0.8, 0.2), pants, Vector3(0, -0.4, 0))
	_bmesh(rleg, Vector3(0.18, 0.8, 0.2), pants, Vector3(0, -0.4, 0))
	_bmesh(model, Vector3(0.5, 0.62, 0.28), shirt, Vector3(0, 1.11, 0))
	larm = _pivot(model, Vector3(-0.33, 1.38, 0))
	rarm = _pivot(model, Vector3(0.33, 1.38, 0))
	_bmesh(larm, Vector3(0.13, 0.6, 0.15), shirt, Vector3(0, -0.3, 0))
	_bmesh(rarm, Vector3(0.13, 0.6, 0.15), shirt, Vector3(0, -0.3, 0))
	head = _pivot(model, Vector3(0, 1.45, 0))
	_smesh(head, 0.16, skin, Vector3(0, 0.17, 0))
	_bmesh(head, Vector3(0.33, 0.1, 0.34), Color(0.1, 0.08, 0.06), Vector3(0, 0.3, 0))
	# كشاف الآخرين
	var f := SpotLight3D.new()
	f.spot_range = 14.0
	f.spot_angle = 28.0
	f.light_energy = 2.0
	f.light_color = Color(1, 0.95, 0.8)
	f.position = Vector3(0.12, 0.1, -0.15)
	head.add_child(f)
	flash = f

func _build_monster() -> void:
	var skin := Color(0.18, 0.1, 0.13)
	var dark := Color(0.07, 0.04, 0.05)
	lleg = _pivot(model, Vector3(-0.17, 0.8, 0))
	rleg = _pivot(model, Vector3(0.17, 0.8, 0))
	_bmesh(lleg, Vector3(0.24, 0.8, 0.26), skin, Vector3(0, -0.4, 0))
	_bmesh(rleg, Vector3(0.24, 0.8, 0.26), skin, Vector3(0, -0.4, 0))
	var torso := _bmesh(model, Vector3(0.7, 0.75, 0.38), skin, Vector3(0, 1.15, 0.04))
	torso.rotation.x = 0.18
	larm = _pivot(model, Vector3(-0.46, 1.45, 0))
	rarm = _pivot(model, Vector3(0.46, 1.45, 0))
	_bmesh(larm, Vector3(0.16, 1.0, 0.18), skin, Vector3(0, -0.5, 0))
	_bmesh(rarm, Vector3(0.16, 1.0, 0.18), skin, Vector3(0, -0.5, 0))
	_cone(larm, 0.1, 0.35, Color(0.8, 0.8, 0.7), Vector3(0, -1.1, 0), Vector3(PI, 0, 0))
	_cone(rarm, 0.1, 0.35, Color(0.8, 0.8, 0.7), Vector3(0, -1.1, 0), Vector3(PI, 0, 0))
	head = _pivot(model, Vector3(0, 1.58, 0.06))
	_smesh(head, 0.2, dark, Vector3(0, 0.16, 0))
	_cone(head, 0.07, 0.3, Color(0.75, 0.7, 0.6), Vector3(-0.13, 0.4, 0), Vector3(0, 0, 0.35))
	_cone(head, 0.07, 0.3, Color(0.75, 0.7, 0.6), Vector3(0.13, 0.4, 0), Vector3(0, 0, -0.35))
	_smesh(head, 0.055, Color(1, 0.08, 0.04), Vector3(-0.085, 0.2, -0.205), true)
	_smesh(head, 0.055, Color(1, 0.08, 0.04), Vector3(0.085, 0.2, -0.205), true)
	_bmesh(head, Vector3(0.2, 0.035, 0.03), Color(0.7, 0.02, 0.02), Vector3(0, 0.08, -0.2), true)
	for tx in [-0.07, -0.025, 0.025, 0.07]:
		_cone(head, 0.015, 0.05, Color(0.95, 0.95, 0.85), Vector3(tx, 0.065, -0.205), Vector3(PI, 0, 0))
	var eyes := OmniLight3D.new()
	eyes.light_color = Color(1, 0.15, 0.1)
	eyes.light_energy = 1.2
	eyes.omni_range = 5.0
	eyes.position = Vector3(0, 0.2, -0.25)
	head.add_child(eyes)

func make_local() -> void:
	is_local = true
	model.visible = false
	cam = Camera3D.new()
	cam.position = Vector3(0, eye_h, 0)
	cam.fov = 78.0
	cam.near = 0.06
	cam.far = 100.0
	add_child(cam)
	cam.current = true
	flash = SpotLight3D.new()
	flash.spot_range = 30.0
	flash.spot_angle = 32.0
	flash.spot_attenuation = 0.9
	flash.light_energy = 4.5 if not is_seeker else 2.5
	flash.light_color = Color(1, 0.96, 0.85) if not is_seeker else Color(1, 0.35, 0.3)
	flash.position = Vector3(0.15, -0.12, 0)
	cam.add_child(flash)

func set_caught() -> void:
	caught = true
	hidden = false
	if flash:
		flash.visible = false
	if not is_local:
		model.rotation_degrees.x = -85.0
		model.position.y = 0.25

func step_now(vol_boost: float = 0.0) -> void:
	if stepper == null or stepper.stream == null:
		return
	stepper.pitch_scale = (randf_range(0.55, 0.7) if is_seeker else randf_range(0.9, 1.15))
	stepper.volume_db = (8.0 if is_seeker else -2.0) + vol_boost
	stepper.play()

func say(stream_name: String, db: float = 6.0, pitch_s: float = 1.0) -> void:
	if not snd.has(stream_name):
		return
	voice.stream = snd[stream_name]
	voice.volume_db = db
	voice.pitch_scale = pitch_s
	voice.play()

func _process(delta: float) -> void:
	if delta <= 0.0:
		return
	var sp := (global_position - last_pos).length() / delta
	last_pos = global_position
	speed_est = lerpf(speed_est, sp, minf(1.0, delta * 10.0))
	if not is_local:
		if head:
			head.rotation.x = lerpf(head.rotation.x, target_pitch, minf(1.0, delta * 12.0))
	if caught or hidden:
		return
	# تحريك الأطراف
	if speed_est > 0.4 and larm:
		anim_t += delta * speed_est * (1.5 if not is_seeker else 1.0)
		var amt := clampf(speed_est / 4.0, 0.0, 1.0) * 0.85
		var sw := sin(anim_t) * amt
		lleg.rotation.x = sw
		rleg.rotation.x = -sw
		larm.rotation.x = -sw
		rarm.rotation.x = sw
		step_acc += speed_est * delta
		var stride := 2.6 if is_seeker else 1.9
		if speed_est > 4.8 and not is_seeker:
			stride = 1.5
		if step_acc >= stride:
			step_acc = 0.0
			step_now()
		if is_local:
			bob_t += delta * speed_est * 1.6
			cam.position.y = eye_h + sin(bob_t * 2.0) * 0.03 * clampf(speed_est / 4.0, 0.0, 1.5)
	elif larm:
		lleg.rotation.x = lerpf(lleg.rotation.x, 0.0, minf(1.0, delta * 8.0))
		rleg.rotation.x = lerpf(rleg.rotation.x, 0.0, minf(1.0, delta * 8.0))
		larm.rotation.x = lerpf(larm.rotation.x, 0.0, minf(1.0, delta * 8.0))
		rarm.rotation.x = lerpf(rarm.rotation.x, 0.0, minf(1.0, delta * 8.0))
		if is_local:
			cam.position.y = lerpf(cam.position.y, eye_h, minf(1.0, delta * 8.0))
