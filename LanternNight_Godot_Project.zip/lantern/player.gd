extends CharacterBody3D
# لاعب بشري أو بوت أو الوحش "سكيري": مجسم بهيكل عظمي + تحريك + كاميرا منظور أول + كشاف + أصوات + ظل

const RigS := preload("res://rig.gd")

const SKINS := [
	{"name": "الجندي البرتقالي", "accent": Color(1.0, 0.5, 0.08), "suit": Color(0.14, 0.14, 0.16), "trim": Color(0.86, 0.86, 0.9)},
	{"name": "الجندي الأزرق", "accent": Color(0.15, 0.55, 1.0), "suit": Color(0.12, 0.15, 0.2), "trim": Color(0.8, 0.88, 0.95)},
	{"name": "الجندي الأخضر", "accent": Color(0.3, 0.9, 0.35), "suit": Color(0.14, 0.17, 0.13), "trim": Color(0.85, 0.9, 0.8)},
	{"name": "الجندي الأحمر", "accent": Color(0.95, 0.15, 0.15), "suit": Color(0.17, 0.12, 0.12), "trim": Color(0.92, 0.85, 0.85)},
]

static var _mc := {}
static var _shadow_tex: ImageTexture

var pid := 0
var kind := "human"       # human | bot | monster
var is_monster := false
var is_local := false
var skin_i := 0
var caught := false
var hidden := false
var underground := false
var mtype := "scary"
var eat_t := 0.0
var eat_victim = null
var blood: CPUParticles3D
var vm_l: Node3D
var vm_r: Node3D
var hide_spot := -1
var ret_pos := Vector3.ZERO
var target_pos := Vector3.ZERO
var target_yaw := 0.0
var target_pitch := 0.0
var eye_h := 1.55
var mstate := 0           # 0 دورية 1 مطاردة 2 بحث
var attack_t := 0.0
var fake_speed := -1.0    # للمعاينة
var model: Node3D
var rig
var cam: Camera3D
var flash: SpotLight3D
var voice: AudioStreamPlayer3D
var stepper: AudioStreamPlayer3D
var rustler: AudioStreamPlayer3D
var breath: AudioStreamPlayer3D
var snd := {}
var step_name := "step"
var gfx
var anim_t := 0.0
var idle_t := 0.0
var step_acc := 0.0
var bob_t := 0.0
var last_pos := Vector3.ZERO
var speed_est := 0.0
var eyelight: OmniLight3D

# ───────────── أدوات المجسمات ─────────────
func _m(col: Color, emissive: bool = false, energy: float = 2.0) -> StandardMaterial3D:
	var key := "%s_%s_%s" % [col.to_html(), emissive, energy]
	if _mc.has(key):
		return _mc[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 0.75
	if emissive:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = energy
	_mc[key] = m
	return m

func _mesh(r, bone_name: String, mesh: Mesh, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.scale = scl
	r.attach(bone_name, mi, pos, rot)
	return mi

func _box(r, b: String, size: Vector3, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	return _mesh(r, b, bm, mat, pos, rot)

func _cap(r, b: String, rad: float, h: float, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var cm := CapsuleMesh.new()
	cm.radius = rad
	cm.height = maxf(h, rad * 2.0 + 0.01)
	cm.radial_segments = 8
	cm.rings = 3
	return _mesh(r, b, cm, mat, pos, rot, scl)

func _sph(r, b: String, rad: float, mat: Material, pos: Vector3, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var sm := SphereMesh.new()
	sm.radius = rad
	sm.height = rad * 2.0
	sm.radial_segments = 10
	sm.rings = 5
	return _mesh(r, b, sm, mat, pos, Vector3.ZERO, scl)

func _cyl(r, b: String, rad: float, h: float, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO, top: float = -1.0) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.bottom_radius = rad
	cm.top_radius = rad if top < 0.0 else top
	cm.height = h
	cm.radial_segments = 8
	cm.rings = 1
	return _mesh(r, b, cm, mat, pos, rot)

func _claw(r, b: String, pos: Vector3, rot: Vector3, length: float = 0.2) -> void:
	_cyl(r, b, 0.018, length, _m(Color(0.85, 0.82, 0.7)), pos, rot, 0.0)

# ───────────── الإعداد ─────────────
func setup(id: int, nm: String, skin: int, k: String, sounds: Dictionary, font: Font, g, stepn: String = "step", mt: String = "scary") -> void:
	pid = id
	kind = k
	is_monster = (k == "monster")
	mtype = mt
	skin_i = skin
	snd = sounds
	gfx = g
	step_name = stepn
	name = "p%d" % id if id >= 0 else "n%d" % -id
	collision_layer = 2
	collision_mask = 1
	var granny := is_monster and mtype == "granny"
	var rad := 0.65 if (is_monster and not granny) else (0.42 if granny else 0.38)
	var hgt := 2.5 if (is_monster and not granny) else 1.7
	eye_h = 2.5 if (is_monster and not granny) else 1.5 if granny else 1.55
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = rad
	cap.height = hgt
	cs.shape = cap
	cs.position.y = hgt * 0.5
	add_child(cs)
	model = Node3D.new()
	add_child(model)
	if is_monster and granny:
		_build_granny()
	elif is_monster:
		_build_monster()
		model.scale = Vector3.ONE * 1.25
	else:
		_build_human(SKINS[skin % SKINS.size()])
	# ظل دائري تحت الشخصية (يعمل في كل مستويات الجودة)
	var sh := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(3.0, 3.0) if is_monster else Vector2(1.2, 1.2)
	sh.mesh = qm
	var sm := StandardMaterial3D.new()
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.albedo_texture = _get_shadow_tex()
	sm.cull_mode = BaseMaterial3D.CULL_DISABLED
	sh.material_override = sm
	sh.rotation.x = -PI * 0.5
	sh.position.y = 0.03
	sh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(sh)
	# أصوات
	voice = AudioStreamPlayer3D.new()
	voice.bus = "World"
	voice.unit_size = 10.0
	voice.max_distance = 80.0
	voice.volume_db = 6.0
	voice.position.y = 1.6
	add_child(voice)
	stepper = AudioStreamPlayer3D.new()
	stepper.bus = "World"
	stepper.stream = snd.get("monster_step") if is_monster else snd.get(step_name)
	stepper.unit_size = 7.0 if is_monster else 5.0
	stepper.max_distance = 40.0 if is_monster else 26.0
	stepper.volume_db = 10.0 if is_monster else -2.0
	add_child(stepper)
	rustler = AudioStreamPlayer3D.new()
	rustler.bus = "World"
	rustler.stream = snd.get("rustle")
	rustler.unit_size = 3.0
	rustler.max_distance = 14.0
	rustler.volume_db = -6.0
	add_child(rustler)
	if is_monster:
		breath = AudioStreamPlayer3D.new()
		breath.bus = "World"
		breath.stream = snd.get("granny_hum") if granny else snd.get("monster_breath")
		breath.unit_size = 10.0 if granny else 9.0
		breath.max_distance = 45.0
		breath.volume_db = 4.0
		breath.position.y = 1.3
		add_child(breath)
	else:
		var tag := Label3D.new()
		tag.text = nm
		tag.font = font
		tag.font_size = 48
		tag.pixel_size = 0.005
		tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		tag.position.y = 2.1
		tag.outline_size = 10
		tag.visibility_range_end = 12.0
		add_child(tag)

func _get_shadow_tex() -> ImageTexture:
	if _shadow_tex != null:
		return _shadow_tex
	var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	for y in 64:
		for x in 64:
			var d := Vector2(x - 31.5, y - 31.5).length() / 32.0
			var a := clampf(1.0 - d, 0.0, 1.0)
			img.set_pixel(x, y, Color(0, 0, 0, a * a * 0.7))
	_shadow_tex = ImageTexture.create_from_image(img)
	return _shadow_tex

# ───────────── الجندي ─────────────
func _build_human(sk: Dictionary) -> void:
	var accent: Color = sk["accent"]
	var suit: Color = sk["suit"]
	var trim: Color = sk["trim"]
	var R = RigS.new(model)
	rig = R
	R.bone("root", "", Vector3.ZERO)
	R.bone("hips", "root", Vector3(0, 0.92, 0))
	R.bone("spine", "hips", Vector3(0, 0.10, 0))
	R.bone("chest", "spine", Vector3(0, 0.18, 0))
	R.bone("neck", "chest", Vector3(0, 0.22, 0))
	R.bone("head", "neck", Vector3(0, 0.08, 0))
	for s in [-1, 1]:
		var d := "l" if s < 0 else "r"
		R.bone("uarm_" + d, "chest", Vector3(0.27 * s, 0.20, 0))
		R.bone("farm_" + d, "uarm_" + d, Vector3(0, -0.30, 0))
		R.bone("hand_" + d, "farm_" + d, Vector3(0, -0.28, 0))
		R.bone("thigh_" + d, "hips", Vector3(0.13 * s, -0.04, 0))
		R.bone("shin_" + d, "thigh_" + d, Vector3(0, -0.42, 0))
		R.bone("foot_" + d, "shin_" + d, Vector3(0, -0.42, 0))
	R.finish()
	var jacket := _m(suit.lightened(0.1))
	var pants := _m(suit.darkened(0.3))
	var boot := _m(Color(0.06, 0.06, 0.07))
	var white := _m(trim)
	var acc := _m(accent)
	var acc_e := _m(accent, true, 1.6)
	var gray := _m(Color(0.55, 0.57, 0.6))
	var can := _m(Color(0.35, 0.42, 0.5))
	var glove := _m(Color(0.08, 0.08, 0.09))
	_box(R, "hips", Vector3(0.42, 0.24, 0.27), pants, Vector3(0, -0.02, 0))
	_box(R, "hips", Vector3(0.17, 0.21, 0.08), acc, Vector3(0.27, -0.1, -0.04))
	_box(R, "spine", Vector3(0.41, 0.2, 0.27), jacket, Vector3(0, 0.05, 0))
	for cx in [-0.12, -0.04, 0.04, 0.12]:
		_cyl(R, "spine", 0.034, 0.16, can, Vector3(cx, 0.06, -0.15))
	_box(R, "chest", Vector3(0.52, 0.34, 0.29), jacket, Vector3(0, 0.1, 0))
	_box(R, "chest", Vector3(0.36, 0.25, 0.06), pants, Vector3(0, 0.1, -0.16))
	_box(R, "chest", Vector3(0.16, 0.03, 0.31), white, Vector3(-0.23, 0.26, 0), Vector3(0, 0, -0.35))
	_box(R, "chest", Vector3(0.16, 0.03, 0.31), white, Vector3(0.23, 0.26, 0), Vector3(0, 0, 0.35))
	_cyl(R, "neck", 0.17, 0.09, pants, Vector3(0, 0.03, 0))
	_sph(R, "head", 0.165, _m(Color(0.22, 0.23, 0.26)), Vector3(0, 0.11, 0), Vector3(1, 1.05, 1.1))
	_box(R, "head", Vector3(0.05, 0.02, 0.3), white, Vector3(0, 0.275, -0.02))
	_box(R, "head", Vector3(0.15, 0.1, 0.09), _m(Color(0.04, 0.04, 0.05)), Vector3(0, 0.07, -0.15))
	_box(R, "head", Vector3(0.22, 0.035, 0.03), acc_e, Vector3(0, 0.15, -0.165))
	for d2 in ["l", "r"]:
		_cap(R, "uarm_" + d2, 0.066, 0.34, jacket, Vector3(0, -0.15, 0))
		_cyl(R, "uarm_" + d2, 0.072, 0.035, white, Vector3(0, -0.06, 0))
		_cap(R, "farm_" + d2, 0.056, 0.32, jacket, Vector3(0, -0.14, 0))
		_cyl(R, "farm_" + d2, 0.062, 0.05, acc, Vector3(0, -0.2, 0))
		_sph(R, "hand_" + d2, 0.065, glove, Vector3(0, -0.04, 0))
		_cap(R, "thigh_" + d2, 0.09, 0.44, pants, Vector3(0, -0.2, 0))
		_cap(R, "shin_" + d2, 0.072, 0.42, pants, Vector3(0, -0.2, 0))
		_box(R, "shin_" + d2, Vector3(0.15, 0.24, 0.2), boot, Vector3(0, -0.28, -0.01))
		_sph(R, "shin_" + d2, 0.075, gray, Vector3(0, -0.02, -0.075))
		_box(R, "foot_" + d2, Vector3(0.15, 0.09, 0.27), boot, Vector3(0, -0.03, -0.05))
	# كشاف اللاعبين الآخرين
	var f := SpotLight3D.new()
	f.spot_range = 14.0
	f.spot_angle = 28.0
	f.light_energy = 2.0
	f.light_color = Color(1, 0.95, 0.8)
	f.position = Vector3(0.12, 0.12, -0.18)
	R.attach("head", f)
	flash = f

# ───────────── سكيري (الوحش) ─────────────
func _build_monster() -> void:
	var R = RigS.new(model)
	rig = R
	R.bone("root", "", Vector3.ZERO)
	R.bone("hips", "root", Vector3(0, 0.95, 0.7))
	R.bone("spine", "hips", Vector3(0, 0.06, -0.5))
	R.bone("chest", "spine", Vector3(0, 0.1, -0.5))
	R.bone("neck", "chest", Vector3(0, 0.04, -0.42))
	R.bone("head", "neck", Vector3(0, -0.04, -0.28))
	R.bone("jaw", "head", Vector3(0, -0.1, -0.1))
	for s in [-1, 1]:
		var d := "l" if s < 0 else "r"
		R.bone("uarm_" + d, "chest", Vector3(0.33 * s, 0.0, -0.05))
		R.bone("farm_" + d, "uarm_" + d, Vector3(0, -0.58, 0))
		R.bone("hand_" + d, "farm_" + d, Vector3(0, -0.58, 0))
		R.bone("thigh_" + d, "hips", Vector3(0.27 * s, -0.05, 0))
		R.bone("shin_" + d, "thigh_" + d, Vector3(0, -0.45, 0))
		R.bone("foot_" + d, "shin_" + d, Vector3(0, -0.45, 0))
	R.finish()
	var skin: Material = gfx.get_mat("monster_skin") if gfx != null else _m(Color(0.5, 0.1, 0.08))
	var dark := _m(Color(0.12, 0.03, 0.03))
	var eye_m := _m(Color(1.0, 0.45, 0.05), true, 8.0)
	var tooth := _m(Color(0.9, 0.88, 0.75))
	_cap(R, "hips", 0.3, 0.95, skin, Vector3(0, 0, -0.25), Vector3(PI * 0.5, 0, 0))
	_cap(R, "chest", 0.35, 1.0, skin, Vector3(0, 0, -0.15), Vector3(PI * 0.5, 0, 0))
	_cap(R, "spine", 0.26, 0.8, skin, Vector3(0, 0, -0.25), Vector3(PI * 0.5, 0, 0))
	for i in 6:
		_cyl(R, "spine", 0.04, 0.2, tooth, Vector3(0, 0.27, 0.1 - i * 0.2), Vector3.ZERO, 0.0)
	_cap(R, "neck", 0.15, 0.5, skin, Vector3(0, -0.02, -0.18), Vector3(PI * 0.42, 0, 0))
	_sph(R, "head", 0.27, skin, Vector3(0, 0.0, -0.1), Vector3(0.95, 0.9, 1.2))
	_sph(R, "head", 0.075, eye_m, Vector3(-0.17, 0.07, -0.27))
	_sph(R, "head", 0.045, _m(Color(0.7, 0.25, 0.03), true, 3.0), Vector3(0.17, 0.07, -0.27))
	_box(R, "jaw", Vector3(0.3, 0.07, 0.34), skin, Vector3(0, -0.02, -0.12))
	_box(R, "jaw", Vector3(0.24, 0.02, 0.28), _m(Color(0.85, 0.05, 0.02), true, 2.2), Vector3(0, 0.035, -0.12))
	for tx in [-0.1, -0.035, 0.035, 0.1]:
		_cyl(R, "jaw", 0.018, 0.09, tooth, Vector3(tx, 0.06, -0.26), Vector3.ZERO, 0.0)
		_cyl(R, "head", 0.018, 0.09, tooth, Vector3(tx, -0.2, -0.27), Vector3(PI, 0, 0), 0.0)
	for d2 in ["l", "r"]:
		_cap(R, "uarm_" + d2, 0.1, 0.62, skin, Vector3(0, -0.29, 0))
		_cap(R, "farm_" + d2, 0.075, 0.62, skin, Vector3(0, -0.29, 0))
		_box(R, "hand_" + d2, Vector3(0.14, 0.05, 0.2), skin, Vector3(0, -0.02, -0.08))
		for cx in [-0.045, 0.0, 0.045]:
			_claw(R, "hand_" + d2, Vector3(cx, -0.03, -0.24), Vector3(-PI * 0.5, 0, 0), 0.22)
		_cap(R, "thigh_" + d2, 0.14, 0.52, skin, Vector3(0, -0.22, 0))
		_cap(R, "shin_" + d2, 0.1, 0.5, skin, Vector3(0, -0.22, 0.02))
		_box(R, "foot_" + d2, Vector3(0.16, 0.06, 0.24), skin, Vector3(0, -0.02, -0.06))
		for cx2 in [-0.05, 0.0, 0.05]:
			_claw(R, "foot_" + d2, Vector3(cx2, -0.03, -0.2), Vector3(-PI * 0.5, 0, 0), 0.16)
	eyelight = OmniLight3D.new()
	eyelight.light_color = Color(1.0, 0.45, 0.1)
	eyelight.light_energy = 1.6
	eyelight.omni_range = 7.0
	R.attach("head", eyelight, Vector3(-0.1, 0.07, -0.4))

func make_local() -> void:
	is_local = true
	model.visible = false
	cam = Camera3D.new()
	cam.position = Vector3(0, eye_h, 0)
	cam.fov = 74.0
	cam.near = 0.05
	cam.far = 100.0
	add_child(cam)
	cam.current = true
	if flash != null:
		flash.get_parent().remove_child(flash)
		flash.queue_free()
		flash = null
	if is_monster:
		flash = SpotLight3D.new()
		flash.spot_range = 30.0
		flash.spot_angle = 36.0
		flash.spot_attenuation = 0.9
		flash.light_energy = 2.6
		flash.light_color = Color(1, 0.35, 0.3)
		flash.position = Vector3(0.15, -0.12, 0)
		cam.add_child(flash)
		if breath != null:
			breath.volume_db = -16.0
	else:
		_build_vm()

# ───────────── الأيدي بالمنظور الأول ─────────────
func _vm_arm(side: int, sk: Dictionary) -> Node3D:
	var suit: Color = sk["suit"]
	var accent: Color = sk["accent"]
	var pivot := Node3D.new()
	pivot.position = Vector3(0.30 * side, -0.34, -0.12)
	var jacket := _m(suit.lightened(0.12))
	var glove := _m(Color(0.07, 0.07, 0.08))
	var acc := _m(accent, true, 1.2)
	var parts := []
	var fa := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.058
	cm.height = 0.5
	cm.radial_segments = 8
	cm.rings = 2
	fa.mesh = cm
	fa.material_override = jacket
	fa.rotation.x = PI * 0.5
	fa.position = Vector3(0, 0, -0.26)
	pivot.add_child(fa)
	var cuff := MeshInstance3D.new()
	var cc := CylinderMesh.new()
	cc.top_radius = 0.064
	cc.bottom_radius = 0.064
	cc.height = 0.05
	cc.radial_segments = 8
	cuff.mesh = cc
	cuff.material_override = acc
	cuff.rotation.x = PI * 0.5
	cuff.position = Vector3(0, 0, -0.5)
	pivot.add_child(cuff)
	var hand := MeshInstance3D.new()
	var hs := SphereMesh.new()
	hs.radius = 0.075
	hs.height = 0.15
	hs.radial_segments = 8
	hs.rings = 4
	hand.mesh = hs
	hand.material_override = glove
	hand.position = Vector3(0, 0, -0.58)
	pivot.add_child(hand)
	for fx in [-0.035, -0.012, 0.012, 0.035]:
		var f := MeshInstance3D.new()
		var fb := BoxMesh.new()
		fb.size = Vector3(0.02, 0.025, 0.07)
		f.mesh = fb
		f.material_override = glove
		f.position = Vector3(fx, -0.01, -0.66)
		pivot.add_child(f)
	for m in pivot.get_children():
		(m as GeometryInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return pivot

func _build_vm() -> void:
	var sk: Dictionary = SKINS[skin_i % SKINS.size()]
	vm_l = _vm_arm(-1, sk)
	vm_r = _vm_arm(1, sk)
	cam.add_child(vm_l)
	cam.add_child(vm_r)
	# كشاف في اليد اليمنى
	var body := MeshInstance3D.new()
	var bc := CylinderMesh.new()
	bc.top_radius = 0.04
	bc.bottom_radius = 0.034
	bc.height = 0.26
	bc.radial_segments = 8
	body.mesh = bc
	body.material_override = _m(Color(0.2, 0.2, 0.22))
	body.rotation.x = PI * 0.5
	body.position = Vector3(0, 0.0, -0.64)
	body.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	vm_r.add_child(body)
	var lens := MeshInstance3D.new()
	var lc := CylinderMesh.new()
	lc.top_radius = 0.046
	lc.bottom_radius = 0.046
	lc.height = 0.01
	lc.radial_segments = 8
	lens.mesh = lc
	lens.material_override = _m(Color(1, 0.95, 0.8), true, 3.0)
	lens.rotation.x = PI * 0.5
	lens.position = Vector3(0, 0.0, -0.78)
	lens.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	vm_r.add_child(lens)
	flash = SpotLight3D.new()
	flash.spot_range = 30.0
	flash.spot_angle = 32.0
	flash.spot_attenuation = 0.9
	flash.light_energy = 4.5
	flash.light_color = Color(1, 0.96, 0.85)
	flash.position = Vector3(0, 0, -0.8)
	vm_r.add_child(flash)

func _anim_vm(delta: float, sp: float) -> void:
	if vm_l == null:
		return
	var a := clampf(sp / 4.0, 0.0, 1.4)
	var run := sp > 4.8
	var t := anim_t
	var amp := 0.5 if run else 0.28
	var sw := sin(t) * amp * a
	var bobv := absf(sin(t)) * 0.04 * a
	var sway := sin(idle_t * 1.4) * 0.012
	var lean := 0.26 if run else 0.0
	vm_l.rotation = Vector3(-0.16 + lean + sw * 0.6, 0.12, 0.10 + sw * 0.25)
	vm_r.rotation = Vector3(-0.16 + lean - sw * 0.6, -0.12, -0.10 - sw * 0.25)
	vm_l.position = Vector3(-0.30, -0.34 - bobv + sway - (0.04 if run else 0.0), -0.12 + sw * 0.35)
	vm_r.position = Vector3(0.30, -0.34 - bobv - sway - (0.04 if run else 0.0), -0.12 - sw * 0.35)

func set_caught() -> void:
	caught = true
	hidden = false
	if flash != null:
		flash.visible = false
	if not is_local and not is_monster and rig != null:
		rig.rot("root", Vector3(1.5, 0, 0))
		rig.shift("root", Vector3(0, 0.12, 0))
		for b in ["thigh_l", "thigh_r", "uarm_l", "uarm_r", "shin_l", "shin_r", "farm_l", "farm_r"]:
			rig.rot(b, Vector3.ZERO)

func lunge() -> void:
	attack_t = 0.8

func step_now(boost: float = 0.0) -> void:
	if stepper == null or stepper.stream == null:
		return
	stepper.pitch_scale = randf_range(0.8, 1.0) if is_monster else randf_range(0.92, 1.12)
	stepper.volume_db = (10.0 if is_monster else -2.0) + boost
	stepper.play()
	if not is_monster and randf() < 0.35 and rustler != null and rustler.stream != null:
		rustler.pitch_scale = randf_range(0.8, 1.2)
		rustler.play()

func say(stream_name: String, db: float = 6.0, pitch_s: float = 1.0) -> void:
	if not snd.has(stream_name) or voice == null:
		return
	voice.stream = snd[stream_name]
	voice.volume_db = db
	voice.pitch_scale = pitch_s
	voice.play()

# ───────────── التحريك ─────────────
func _process(delta: float) -> void:
	if delta <= 0.0 or rig == null:
		return
	var sp := (global_position - last_pos).length() / delta
	last_pos = global_position
	if fake_speed >= 0.0:
		sp = fake_speed
	speed_est = lerpf(speed_est, sp, minf(1.0, delta * 10.0))
	if is_monster and mtype == "granny":
		_anim_granny(delta)
	elif is_monster:
		_anim_monster(delta)
	else:
		_anim_human(delta)

func _anim_human(delta: float) -> void:
	if caught:
		return
	var R = rig
	idle_t += delta
	var sp := speed_est
	if is_local:
		_anim_vm(delta, sp)
	if not is_local:
		R.rot("head", Vector3(target_pitch * 0.8, 0, 0))
	if sp > 0.4:
		anim_t += delta * sp * 1.7
		var a := clampf(sp / 4.0, 0.0, 1.4)
		var run := sp > 4.8
		var s1 := sin(anim_t)
		var c1 := cos(anim_t)
		R.rot("thigh_l", Vector3(s1 * 0.7 * a, 0, 0))
		R.rot("thigh_r", Vector3(-s1 * 0.7 * a, 0, 0))
		R.rot("shin_l", Vector3(-(0.5 + 0.5 * c1) * 0.9 * a, 0, 0))
		R.rot("shin_r", Vector3(-(0.5 - 0.5 * c1) * 0.9 * a, 0, 0))
		R.rot("uarm_l", Vector3(-s1 * 0.6 * a, 0, 0))
		R.rot("uarm_r", Vector3(s1 * 0.6 * a, 0, 0))
		R.rot("farm_l", Vector3(0.5 * a, 0, 0))
		R.rot("farm_r", Vector3(0.5 * a, 0, 0))
		R.rot("spine", Vector3(0.05 + (0.2 if run else 0.0), s1 * 0.06, 0))
		R.shift("hips", Vector3(0, -absf(s1) * 0.045 * a, 0))
		step_acc += sp * delta
		var stride := 1.5 if run else 1.9
		if step_acc >= stride:
			step_acc = 0.0
			step_now()
		if is_local and cam != null:
			bob_t += delta * sp * 1.6
			cam.position.y = eye_h + sin(bob_t * 2.0) * 0.03 * clampf(sp / 4.0, 0.0, 1.5)
	else:
		for b in ["thigh_l", "thigh_r", "shin_l", "shin_r", "uarm_l", "uarm_r", "farm_l", "farm_r"]:
			R.rot(b, Vector3.ZERO)
		R.rot("spine", Vector3(sin(idle_t * 1.6) * 0.02, 0, 0))
		R.shift("hips", Vector3.ZERO)
		if is_local and cam != null:
			cam.position.y = lerpf(cam.position.y, eye_h, minf(1.0, delta * 8.0))

func _anim_monster(delta: float) -> void:
	var R = rig
	idle_t += delta
	if attack_t > 0.0:
		attack_t -= delta
	var chase := mstate == 1
	var sp := speed_est
	var mv := sp > 0.3
	if mv:
		anim_t += delta * sp * (1.15 if chase else 1.0)
	var s1 := sin(anim_t)
	var c1 := cos(anim_t)
	var amp := clampf(sp / 3.0, 0.0, 2.0) if mv else 0.0
	# أطراف أمامية طويلة تتبادل المد، وخلفية تدفع
	R.rot("uarm_l", Vector3(s1 * 0.85 * amp - 0.35, 0, 0.1))
	R.rot("uarm_r", Vector3(-s1 * 0.85 * amp - 0.35, 0, -0.1))
	R.rot("farm_l", Vector3(0.35 + maxf(0.0, c1) * 0.7 * amp, 0, 0))
	R.rot("farm_r", Vector3(0.35 + maxf(0.0, -c1) * 0.7 * amp, 0, 0))
	R.rot("thigh_l", Vector3(-s1 * 0.7 * amp + 0.25, 0, 0))
	R.rot("thigh_r", Vector3(s1 * 0.7 * amp + 0.25, 0, 0))
	R.rot("shin_l", Vector3(-(0.5 + 0.5 * c1) * 0.9 * amp - 0.3, 0, 0))
	R.rot("shin_r", Vector3(-(0.5 - 0.5 * c1) * 0.9 * amp - 0.3, 0, 0))
	# العمود الفقري يتلوّى والرأس يرتعش بشكل مخيف
	R.rot("spine", Vector3(0.05, s1 * 0.2 * amp + sin(idle_t * 0.9) * 0.04, 0))
	R.rot("chest", Vector3(0.1, -s1 * 0.25 * amp, 0))
	var twitch := 1.0 if (sin(idle_t * 23.0) * sin(idle_t * 3.3) > 0.88) else 0.0
	var scan := sin(idle_t * 0.8) * (0.55 if not chase else 0.1)
	R.rot("neck", Vector3(0.25 + (0.3 if chase else 0.0), scan, sin(idle_t * 1.3) * 0.2))
	R.rot("head", Vector3(sin(idle_t * 2.1) * 0.06, twitch * 0.5 * sin(idle_t * 60.0), twitch * 0.35))
	var jaw_open := 0.1 + 0.08 * sin(idle_t * 2.0)
	if chase:
		jaw_open = 0.45 + 0.2 * sin(idle_t * 14.0)
	R.rot("jaw", Vector3(jaw_open, 0, 0))
	var low := -0.16 if chase else 0.0
	R.shift("hips", Vector3(0, low + sin(anim_t * 2.0) * 0.05 * amp - sin(idle_t * 1.7) * 0.01, 0))
	R.rot("hips", Vector3(-0.05 + (0.12 if chase else 0.0), 0, 0))
	if attack_t > 0.0:
		var k := sin(clampf(attack_t / 0.8, 0.0, 1.0) * PI)
		R.rot("neck", Vector3(-0.6 * k, 0, 0))
		R.rot("jaw", Vector3(0.9 * k, 0, 0))
		R.rot("uarm_l", Vector3(-1.9 * k, 0, 0.3))
		R.rot("uarm_r", Vector3(-1.9 * k, 0, -0.3))
		R.rot("farm_l", Vector3(-0.4 * k, 0, 0))
		R.rot("farm_r", Vector3(-0.4 * k, 0, 0))
	if mv:
		step_acc += sp * delta
		if step_acc >= (2.2 if not chase else 2.6):
			step_acc = 0.0
			step_now()
	if eyelight != null:
		eyelight.light_energy = 1.2 + 0.5 * sin(idle_t * 7.0) + (1.2 if chase else 0.0)
	if eat_t > 0.0:
		eat_t -= delta
		_eat_update(delta)
	if breath != null and not breath.playing and breath.stream != null:
		breath.play()

# ───────────── جراني ─────────────
func _build_granny() -> void:
	var R = RigS.new(model)
	rig = R
	R.bone("root", "", Vector3.ZERO)
	R.bone("hips", "root", Vector3(0, 0.86, 0))
	R.bone("spine", "hips", Vector3(0, 0.10, 0))
	R.bone("chest", "spine", Vector3(0, 0.17, 0))
	R.bone("neck", "chest", Vector3(0, 0.2, 0))
	R.bone("head", "neck", Vector3(0, 0.07, 0))
	for s in [-1, 1]:
		var d := "l" if s < 0 else "r"
		R.bone("uarm_" + d, "chest", Vector3(0.23 * s, 0.18, 0))
		R.bone("farm_" + d, "uarm_" + d, Vector3(0, -0.27, 0))
		R.bone("hand_" + d, "farm_" + d, Vector3(0, -0.25, 0))
		R.bone("thigh_" + d, "hips", Vector3(0.1 * s, -0.04, 0))
		R.bone("shin_" + d, "thigh_" + d, Vector3(0, -0.4, 0))
		R.bone("foot_" + d, "shin_" + d, Vector3(0, -0.4, 0))
	R.finish()
	var dress: Material = gfx.get_mat("granny_dress") if gfx != null else _m(Color(0.5, 0.3, 0.4))
	var skin: Material = gfx.get_mat("granny_skin") if gfx != null else _m(Color(0.8, 0.65, 0.55))
	var cardigan := _m(Color(0.42, 0.42, 0.45))
	var hair := _m(Color(0.82, 0.82, 0.84))
	var shoe := _m(Color(0.1, 0.07, 0.07))
	var stock := _m(Color(0.62, 0.55, 0.52))
	var wood := _m(Color(0.55, 0.38, 0.22))
	var dark := _m(Color(0.05, 0.05, 0.06))
	# تنورة وصدر
	_cyl(R, "hips", 0.36, 0.95, dress, Vector3(0, -0.32, 0), Vector3.ZERO, 0.2)
	_box(R, "spine", Vector3(0.36, 0.2, 0.24), dress, Vector3(0, 0.05, 0))
	_box(R, "chest", Vector3(0.42, 0.3, 0.26), cardigan, Vector3(0, 0.1, 0))
	_box(R, "chest", Vector3(0.26, 0.4, 0.05), _m(Color(0.85, 0.82, 0.75)), Vector3(0, 0.02, -0.14))
	_cyl(R, "neck", 0.07, 0.12, skin, Vector3(0, 0.03, 0))
	# الرأس والشعر والنظارة
	_sph(R, "head", 0.145, skin, Vector3(0, 0.12, -0.01), Vector3(0.95, 1.1, 1.0))
	_sph(R, "head", 0.15, hair, Vector3(0, 0.19, 0.04), Vector3(1.0, 0.7, 1.0))
	_sph(R, "head", 0.09, hair, Vector3(0, 0.3, 0.1))
	_box(R, "head", Vector3(0.05, 0.05, 0.05), skin, Vector3(0, 0.1, -0.15))
	for ex in [-0.05, 0.05]:
		_cyl(R, "head", 0.035, 0.012, _m(Color(0.7, 0.8, 0.9), true, 0.8), Vector3(ex, 0.14, -0.135), Vector3(PI * 0.5, 0, 0))
	_box(R, "head", Vector3(0.18, 0.02, 0.02), dark, Vector3(0, 0.14, -0.14))
	_box(R, "head", Vector3(0.09, 0.015, 0.02), _m(Color(0.5, 0.1, 0.1)), Vector3(0, 0.05, -0.14))
	for d2 in ["l", "r"]:
		_cap(R, "uarm_" + d2, 0.05, 0.3, cardigan, Vector3(0, -0.13, 0))
		_cap(R, "farm_" + d2, 0.042, 0.28, cardigan, Vector3(0, -0.12, 0))
		_sph(R, "hand_" + d2, 0.052, skin, Vector3(0, -0.03, 0))
		_cap(R, "thigh_" + d2, 0.06, 0.4, stock, Vector3(0, -0.18, 0))
		_cap(R, "shin_" + d2, 0.05, 0.4, stock, Vector3(0, -0.18, 0))
		_box(R, "foot_" + d2, Vector3(0.1, 0.07, 0.22), shoe, Vector3(0, -0.03, -0.04))
	# مضرب البيسبول في اليد اليمنى
	var bat := MeshInstance3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 0.055
	bm.bottom_radius = 0.025
	bm.height = 0.95
	bm.radial_segments = 8
	bat.mesh = bm
	bat.material_override = wood
	R.attach("hand_r", bat, Vector3(0, -0.2, -0.28), Vector3(PI * 0.5 + 0.3, 0, 0))
	for nx in [-0.04, 0.04, 0.0]:
		var nail := MeshInstance3D.new()
		var nm_ := CylinderMesh.new()
		nm_.top_radius = 0.0
		nm_.bottom_radius = 0.012
		nm_.height = 0.07
		nm_.radial_segments = 4
		nail.mesh = nm_
		nail.material_override = _m(Color(0.7, 0.7, 0.72))
		R.attach("hand_r", nail, Vector3(nx, -0.2 + nx * 2.0, -0.62), Vector3(PI * 0.5, 0, 0))
	eyelight = OmniLight3D.new()
	eyelight.light_color = Color(1.0, 0.85, 0.6)
	eyelight.light_energy = 0.7
	eyelight.omni_range = 5.0
	R.attach("head", eyelight, Vector3(0, 0.15, -0.3))

func _anim_granny(delta: float) -> void:
	var R = rig
	idle_t += delta
	if attack_t > 0.0:
		attack_t -= delta
	var chase := mstate == 1
	var sp := speed_est
	var mv := sp > 0.3
	if mv:
		anim_t += delta * sp * 1.4
	var s1 := sin(anim_t)
	var c1 := cos(anim_t)
	var amp := clampf(sp / 3.5, 0.0, 1.3) if mv else 0.0
	R.rot("thigh_l", Vector3(s1 * 0.5 * amp, 0, 0))
	R.rot("thigh_r", Vector3(-s1 * 0.5 * amp, 0, 0))
	R.rot("shin_l", Vector3(-(0.5 + 0.5 * c1) * 0.6 * amp, 0, 0))
	R.rot("shin_r", Vector3(-(0.5 - 0.5 * c1) * 0.6 * amp, 0, 0))
	R.rot("uarm_l", Vector3(-s1 * 0.3 * amp - 0.1, 0, 0.06))
	R.rot("uarm_r", Vector3(-0.9 - (0.55 if chase else 0.0) + s1 * 0.08 * amp, 0, -0.1))
	R.rot("farm_l", Vector3(0.2 * amp, 0, 0))
	R.rot("farm_r", Vector3(0.9, 0, 0))
	var twitch := 1.0 if (sin(idle_t * 19.0) * sin(idle_t * 2.7) > 0.9) else 0.0
	R.rot("spine", Vector3(0.38 + sin(idle_t * 1.2) * 0.03, s1 * 0.1 * amp, 0))
	R.rot("neck", Vector3(0.28, sin(idle_t * 0.7) * (0.5 if not chase else 0.1), sin(idle_t * 0.9) * 0.12 + twitch * 0.3))
	R.rot("head", Vector3(-0.1, twitch * 0.4 * sin(idle_t * 50.0), 0))
	R.shift("hips", Vector3(0, -absf(s1) * 0.03 * amp, 0))
	if attack_t > 0.0:
		var el := 1.2 - attack_t
		var wind := clampf(el / 0.4, 0.0, 1.0)
		var swing := clampf((el - 0.4) / 0.25, 0.0, 1.0)
		R.rot("uarm_r", Vector3(lerpf(-0.9, 2.4, wind) - swing * 3.7, 0, -0.1))
		R.rot("farm_r", Vector3(0.4, 0, 0))
		R.rot("spine", Vector3(0.38 - wind * 0.35 + swing * 0.8, 0, 0))
	if mv:
		step_acc += sp * delta
		if step_acc >= (1.6 if not chase else 2.0):
			step_acc = 0.0
			step_now(2.0)
	if eyelight != null:
		eyelight.light_energy = 0.6 + 0.2 * sin(idle_t * 3.0) + (0.8 if chase else 0.0)
	if breath != null and not breath.playing and breath.stream != null:
		breath.play()

# ───────────── التهام الضحية ─────────────
func head_world_pos() -> Vector3:
	if rig == null:
		return global_position + Vector3(0, 1.5, 0)
	return rig.skel.global_transform * rig.skel.get_bone_global_pose(rig.idx["head"]).origin

func sfx_at(sname: String, delay: float, db: float = 6.0) -> void:
	if not snd.has(sname):
		return
	await get_tree().create_timer(delay).timeout
	if not is_inside_tree():
		return
	var pl := AudioStreamPlayer3D.new()
	pl.stream = snd[sname]
	pl.bus = "World"
	pl.volume_db = db
	pl.unit_size = 8.0
	pl.max_distance = 70.0
	add_child(pl)
	pl.finished.connect(pl.queue_free)
	pl.play()

func _make_blood() -> void:
	blood = CPUParticles3D.new()
	blood.amount = 40
	blood.lifetime = 0.9
	blood.emitting = false
	blood.direction = Vector3(0, -1, -0.3)
	blood.spread = 38.0
	blood.initial_velocity_min = 1.2
	blood.initial_velocity_max = 3.2
	blood.gravity = Vector3(0, -9.0, 0)
	var sm := SphereMesh.new()
	sm.radius = 0.035
	sm.height = 0.07
	sm.radial_segments = 6
	sm.rings = 3
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.6, 0.02, 0.02)
	mat.emission_enabled = true
	mat.emission = Color(0.35, 0.0, 0.0)
	sm.material = mat
	blood.mesh = sm
	rig.attach("jaw" if mtype == "scary" else "head", blood, Vector3(0, -0.05, -0.22))

func start_eat(victim) -> void:
	if not is_monster:
		return
	var d: Vector3 = victim.global_position - global_position
	d.y = 0.0
	if d.length() > 0.05:
		rotation.y = atan2(-d.x, -d.z)
		target_yaw = rotation.y
	velocity = Vector3.ZERO
	if mtype == "granny":
		attack_t = 1.2
		sfx_at("bat_swing", 0.4, 4.0)
		sfx_at("bat_hit", 0.62, 8.0)
		return
	eat_t = 3.4
	eat_victim = victim
	if blood == null and rig != null:
		_make_blood()
	sfx_at("bite_snap", 0.25, 8.0)
	sfx_at("eat_crunch", 0.9, 10.0)
	sfx_at("swallow", 3.0, 8.0)

func _eat_update(delta: float) -> void:
	var R = rig
	var T := 3.4
	var el := T - eat_t
	var chew := absf(sin(el * 9.0))
	if el < 0.5:
		var k := el / 0.5
		R.rot("neck", Vector3(-0.5 * k, 0, 0))
		R.rot("jaw", Vector3(0.95 * k, 0, 0))
		R.rot("uarm_l", Vector3(-1.7 * k, 0, 0.3))
		R.rot("uarm_r", Vector3(-1.7 * k, 0, -0.3))
	else:
		R.rot("neck", Vector3(-0.35, 0, sin(el * 14.0) * 0.18))
		R.rot("jaw", Vector3(0.12 + 0.55 * chew, 0, 0))
		R.rot("uarm_l", Vector3(-2.0, 0, 0.25))
		R.rot("uarm_r", Vector3(-2.0, 0, -0.25))
		R.rot("farm_l", Vector3(-0.6, 0, 0))
		R.rot("farm_r", Vector3(-0.6, 0, 0))
	R.rot("hips", Vector3(-0.45, 0, 0))
	R.rot("head", Vector3(0, sin(el * 17.0) * 0.12, sin(el * 13.0) * 0.28))
	if blood != null:
		blood.emitting = el > 1.0 and el < 3.0
	if eat_victim != null and is_instance_valid(eat_victim):
		var mouth := head_world_pos() + (-global_transform.basis.z) * 0.3 - Vector3(0, 0.5, 0)
		var v = eat_victim
		if el < 1.0:
			v.global_position = v.global_position.lerp(mouth, minf(1.0, delta * 6.0))
		else:
			v.global_position = mouth + Vector3(sin(el * 20.0) * 0.04, 0, 0)
		if el > 1.4 and v.model != null:
			v.model.scale = Vector3.ONE * clampf(1.0 - (el - 1.4) / 1.7, 0.0, 1.0)
		if eat_t <= delta * 1.5:
			if v.model != null:
				v.model.visible = false
				v.model.scale = Vector3.ONE
			eat_victim = null
			if blood != null:
				blood.emitting = false
