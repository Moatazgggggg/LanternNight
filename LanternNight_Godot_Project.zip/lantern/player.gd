extends CharacterBody3D
# لاعب بشري أو بوت أو الوحش "سكيري": مجسم بهيكل عظمي + تحريك + كاميرا منظور أول + كشاف + أصوات + ظل

const RigS := preload("res://rig.gd")

const SKINS := [
	{"name": "الجندي البرتقالي", "accent": Color(1.0, 0.5, 0.08), "suit": Color(0.14, 0.14, 0.16), "trim": Color(0.86, 0.86, 0.9)},
	{"name": "الجندي الأزرق", "accent": Color(0.15, 0.55, 1.0), "suit": Color(0.12, 0.15, 0.2), "trim": Color(0.8, 0.88, 0.95)},
	{"name": "الجندي الأخضر", "accent": Color(0.3, 0.9, 0.35), "suit": Color(0.14, 0.17, 0.13), "trim": Color(0.85, 0.9, 0.8)},
	{"name": "الجندي الأحمر", "accent": Color(0.95, 0.15, 0.15), "suit": Color(0.17, 0.12, 0.12), "trim": Color(0.92, 0.85, 0.85)},
]

static var _mc := {}
static var _shadow_tex: ImageTexture

var pid := 0
var kind := "human"       # human | bot | monster
var is_monster := false
var is_local := false
var skin_i := 0
var caught := false
var hidden := false
var hide_spot := -1
var ret_pos := Vector3.ZERO
var target_pos := Vector3.ZERO
var target_yaw := 0.0
var target_pitch := 0.0
var eye_h := 1.55
var mstate := 0           # 0 دورية 1 مطاردة 2 بحث
var attack_t := 0.0
var fake_speed := -1.0    # للمعاينة
var model: Node3D
var rig
var cam: Camera3D
var flash: SpotLight3D
var voice: AudioStreamPlayer3D
var stepper: AudioStreamPlayer3D
var rustler: AudioStreamPlayer3D
var breath: AudioStreamPlayer3D
var snd := {}
var step_name := "step"
var gfx
var anim_t := 0.0
var idle_t := 0.0
var step_acc := 0.0
var bob_t := 0.0
var last_pos := Vector3.ZERO
var speed_est := 0.0
var eyelight: OmniLight3D

# ───────────── أدوات المجسمات ─────────────
func _m(col: Color, emissive: bool = false, energy: float = 2.0) -> StandardMaterial3D:
	var key := "%s_%s_%s" % [col.to_html(), emissive, energy]
	if _mc.has(key):
		return _mc[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 0.75
	if emissive:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = energy
	_mc[key] = m
	return m

func _mesh(r, bone_name: String, mesh: Mesh, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.scale = scl
	r.attach(bone_name, mi, pos, rot)
	return mi

func _box(r, b: String, size: Vector3, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	return _mesh(r, b, bm, mat, pos, rot)

func _cap(r, b: String, rad: float, h: float, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var cm := CapsuleMesh.new()
	cm.radius = rad
	cm.height = maxf(h, rad * 2.0 + 0.01)
	cm.radial_segments = 8
	cm.rings = 3
	return _mesh(r, b, cm, mat, pos, rot, scl)

func _sph(r, b: String, rad: float, mat: Material, pos: Vector3, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var sm := SphereMesh.new()
	sm.radius = rad
	sm.height = rad * 2.0
	sm.radial_segments = 10
	sm.rings = 5
	return _mesh(r, b, sm, mat, pos, Vector3.ZERO, scl)

func _cyl(r, b: String, rad: float, h: float, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO, top: float = -1.0) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.bottom_radius = rad
	cm.top_radius = rad if top < 0.0 else top
	cm.height = h
	cm.radial_segments = 8
	cm.rings = 1
	return _mesh(r, b, cm, mat, pos, rot)

func _claw(r, b: String, pos: Vector3, rot: Vector3, length: float = 0.2) -> void:
	_cyl(r, b, 0.018, length, _m(Color(0.85, 0.82, 0.7)), pos, rot, 0.0)

# ───────────── الإعداد ─────────────
func setup(id: int, nm: String, skin: int, k: String, sounds: Dictionary, font: Font, g, stepn: String = "step") -> void:
	pid = id
	kind = k
	is_monster = (k == "monster")
	skin_i = skin
	snd = sounds
	gfx = g
	step_name = stepn
	name = "p%d" % id if id >= 0 else "n%d" % -id
	collision_layer = 2
	collision_mask = 1
	var rad := 0.65 if is_monster else 0.38
	var hgt := 2.5 if is_monster else 1.7
	eye_h = 1.55
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = rad
	cap.height = hgt
	cs.shape = cap
	cs.position.y = hgt * 0.5
	add_child(cs)
	model = Node3D.new()
	add_child(model)
	if is_monster:
		_build_monster()
		model.scale = Vector3.ONE * 1.25
	else:
		_build_human(SKINS[skin % SKINS.size()])
	# ظل دائري تحت الشخصية (يعمل في كل مستويات الجودة)
	var sh := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(3.0, 3.0) if is_monster else Vector2(1.2, 1.2)
	sh.mesh = qm
	var sm := StandardMaterial3D.new()
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.albedo_texture = _get_shadow_tex()
	sm.cull_mode = BaseMaterial3D.CULL_DISABLED
	sh.material_override = sm
	sh.rotation.x = -PI * 0.5
	sh.position.y = 0.03
	sh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(sh)
	# أصوات
	voice = AudioStreamPlayer3D.new()
	voice.unit_size = 10.0
	voice.max_distance = 80.0
	voice.volume_db = 6.0
	voice.position.y = 1.6
	add_child(voice)
	stepper = AudioStreamPlayer3D.new()
	stepper.stream = snd.get("monster_step") if is_monster else snd.get(step_name)
	stepper.unit_size = 7.0 if is_monster else 5.0
	stepper.max_distance = 40.0 if is_monster else 26.0
	stepper.volume_db = 10.0 if is_monster else -2.0
	add_child(stepper)
	rustler = AudioStreamPlayer3D.new()
	rustler.stream = snd.get("rustle")
	rustler.unit_size = 3.0
	rustler.max_distance = 14.0
	rustler.volume_db = -6.0
	add_child(rustler)
	if is_monster:
		breath = AudioStreamPlayer3D.new()
		breath.stream = snd.get("monster_breath")
		breath.unit_size = 9.0
		breath.max_distance = 45.0
		breath.volume_db = 4.0
		breath.position.y = 1.3
		add_child(breath)
	else:
		var tag := Label3D.new()
		tag.text = nm
		tag.font = font
		tag.font_size = 48
		tag.pixel_size = 0.005
		tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		tag.position.y = 2.1
		tag.outline_size = 10
		tag.visibility_range_end = 12.0
		add_child(tag)

func _get_shadow_tex() -> ImageTexture:
	if _shadow_tex != null:
		return _shadow_tex
	var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	for y in 64:
		for x in 64:
			var d := Vector2(x - 31.5, y - 31.5).length() / 32.0
			var a := clampf(1.0 - d, 0.0, 1.0)
			img.set_pixel(x, y, Color(0, 0, 0, a * a * 0.7))
	_shadow_tex = ImageTexture.create_from_image(img)
	return _shadow_tex

# ───────────── الجندي ─────────────
func _build_human(sk: Dictionary) -> void:
	var accent: Color = sk["accent"]
	var suit: Color = sk["suit"]
	var trim: Color = sk["trim"]
	var R = RigS.new(model)
	rig = R
	R.bone("root", "", Vector3.ZERO)
	R.bone("hips", "root", Vector3(0, 0.92, 0))
	R.bone("spine", "hips", Vector3(0, 0.10, 0))
	R.bone("chest", "spine", Vector3(0, 0.18, 0))
	R.bone("neck", "chest", Vector3(0, 0.22, 0))
	R.bone("head", "neck", Vector3(0, 0.08, 0))
	for s in [-1, 1]:
		var d := "l" if s < 0 else "r"
		R.bone("uarm_" + d, "chest", Vector3(0.27 * s, 0.20, 0))
		R.bone("farm_" + d, "uarm_" + d, Vector3(0, -0.30, 0))
		R.bone("hand_" + d, "farm_" + d, Vector3(0, -0.28, 0))
		R.bone("thigh_" + d, "hips", Vector3(0.13 * s, -0.04, 0))
		R.bone("shin_" + d, "thigh_" + d, Vector3(0, -0.42, 0))
		R.bone("foot_" + d, "shin_" + d, Vector3(0, -0.42, 0))
	R.finish()
	var jacket := _m(suit.lightened(0.1))
	var pants := _m(suit.darkened(0.3))
	var boot := _m(Color(0.06, 0.06, 0.07))
	var white := _m(trim)
	var acc := _m(accent)
	var acc_e := _m(accent, true, 1.6)
	var gray := _m(Color(0.55, 0.57, 0.6))
	var can := _m(Color(0.35, 0.42, 0.5))
	var glove := _m(Color(0.08, 0.08, 0.09))
	_box(R, "hips", Vector3(0.42, 0.24, 0.27), pants, Vector3(0, -0.02, 0))
	_box(R, "hips", Vector3(0.17, 0.21, 0.08), acc, Vector3(0.27, -0.1, -0.04))
	_box(R, "spine", Vector3(0.41, 0.2, 0.27), jacket, Vector3(0, 0.05, 0))
	for cx in [-0.12, -0.04, 0.04, 0.12]:
		_cyl(R, "spine", 0.034, 0.16, can, Vector3(cx, 0.06, -0.15))
	_box(R, "chest", Vector3(0.52, 0.34, 0.29), jacket, Vector3(0, 0.1, 0))
	_box(R, "chest", Vector3(0.36, 0.25, 0.06), pants, Vector3(0, 0.1, -0.16))
	_box(R, "chest", Vector3(0.16, 0.03, 0.31), white, Vector3(-0.23, 0.26, 0), Vector3(0, 0, -0.35))
	_box(R, "chest", Vector3(0.16, 0.03, 0.31), white, Vector3(0.23, 0.26, 0), Vector3(0, 0, 0.35))
	_cyl(R, "neck", 0.17, 0.09, pants, Vector3(0, 0.03, 0))
	_sph(R, "head", 0.165, _m(Color(0.22, 0.23, 0.26)), Vector3(0, 0.11, 0), Vector3(1, 1.05, 1.1))
	_box(R, "head", Vector3(0.05, 0.02, 0.3), white, Vector3(0, 0.275, -0.02))
	_box(R, "head", Vector3(0.15, 0.1, 0.09), _m(Color(0.04, 0.04, 0.05)), Vector3(0, 0.07, -0.15))
	_box(R, "head", Vector3(0.22, 0.035, 0.03), acc_e, Vector3(0, 0.15, -0.165))
	for d2 in ["l", "r"]:
		_cap(R, "uarm_" + d2, 0.066, 0.34, jacket, Vector3(0, -0.15, 0))
		_cyl(R, "uarm_" + d2, 0.072, 0.035, white, Vector3(0, -0.06, 0))
		_cap(R, "farm_" + d2, 0.056, 0.32, jacket, Vector3(0, -0.14, 0))
		_cyl(R, "farm_" + d2, 0.062, 0.05, acc, Vector3(0, -0.2, 0))
		_sph(R, "hand_" + d2, 0.065, glove, Vector3(0, -0.04, 0))
		_cap(R, "thigh_" + d2, 0.09, 0.44, pants, Vector3(0, -0.2, 0))
		_cap(R, "shin_" + d2, 0.072, 0.42, pants, Vector3(0, -0.2, 0))
		_box(R, "shin_" + d2, Vector3(0.15, 0.24, 0.2), boot, Vector3(0, -0.28, -0.01))
		_sph(R, "shin_" + d2, 0.075, gray, Vector3(0, -0.02, -0.075))
		_box(R, "foot_" + d2, Vector3(0.15, 0.09, 0.27), boot, Vector3(0, -0.03, -0.05))
	# كشاف اللاعبين الآخرين
	var f := SpotLight3D.new()
	f.spot_range = 14.0
	f.spot_angle = 28.0
	f.light_energy = 2.0
	f.light_color = Color(1, 0.95, 0.8)
	f.position = Vector3(0.12, 0.12, -0.18)
	R.attach("head", f)
	flash = f

# ───────────── سكيري (الوحش) ─────────────
func _build_monster() -> void:
	var R = RigS.new(model)
	rig = R
	R.bone("root", "", Vector3.ZERO)
	R.bone("hips", "root", Vector3(0, 0.95, 0.7))
	R.bone("spine", "hips", Vector3(0, 0.06, -0.5))
	R.bone("chest", "spine", Vector3(0, 0.1, -0.5))
	R.bone("neck", "chest", Vector3(0, 0.04, -0.42))
	R.bone("head", "neck", Vector3(0, -0.04, -0.28))
	R.bone("jaw", "head", Vector3(0, -0.1, -0.1))
	for s in [-1, 1]:
		var d := "l" if s < 0 else "r"
		R.bone("uarm_" + d, "chest", Vector3(0.33 * s, 0.0, -0.05))
		R.bone("farm_" + d, "uarm_" + d, Vector3(0, -0.58, 0))
		R.bone("hand_" + d, "farm_" + d, Vector3(0, -0.58, 0))
		R.bone("thigh_" + d, "hips", Vector3(0.27 * s, -0.05, 0))
		R.bone("shin_" + d, "thigh_" + d, Vector3(0, -0.45, 0))
		R.bone("foot_" + d, "shin_" + d, Vector3(0, -0.45, 0))
	R.finish()
	var skin: Material = gfx.get_mat("monster_skin") if gfx != null else _m(Color(0.5, 0.1, 0.08))
	var dark := _m(Color(0.12, 0.03, 0.03))
	var eye_m := _m(Color(1.0, 0.45, 0.05), true, 8.0)
	var tooth := _m(Color(0.9, 0.88, 0.75))
	_cap(R, "hips", 0.3, 0.95, skin, Vector3(0, 0, -0.25), Vector3(PI * 0.5, 0, 0))
	_cap(R, "chest", 0.35, 1.0, skin, Vector3(0, 0, -0.15), Vector3(PI * 0.5, 0, 0))
	_cap(R, "spine", 0.26, 0.8, skin, Vector3(0, 0, -0.25), Vector3(PI * 0.5, 0, 0))
	for i in 6:
		_cyl(R, "spine", 0.04, 0.2, tooth, Vector3(0, 0.27, 0.1 - i * 0.2), Vector3.ZERO, 0.0)
	_cap(R, "neck", 0.15, 0.5, skin, Vector3(0, -0.02, -0.18), Vector3(PI * 0.42, 0, 0))
	_sph(R, "head", 0.27, skin, Vector3(0, 0.0, -0.1), Vector3(0.95, 0.9, 1.2))
	_sph(R, "head", 0.075, eye_m, Vector3(-0.17, 0.07, -0.27))
	_sph(R, "head", 0.045, _m(Color(0.7, 0.25, 0.03), true, 3.0), Vector3(0.17, 0.07, -0.27))
	_box(R, "jaw", Vector3(0.3, 0.07, 0.34), skin, Vector3(0, -0.02, -0.12))
	_box(R, "jaw", Vector3(0.24, 0.02, 0.28), _m(Color(0.85, 0.05, 0.02), true, 2.2), Vector3(0, 0.035, -0.12))
	for tx in [-0.1, -0.035, 0.035, 0.1]:
		_cyl(R, "jaw", 0.018, 0.09, tooth, Vector3(tx, 0.06, -0.26), Vector3.ZERO, 0.0)
		_cyl(R, "head", 0.018, 0.09, tooth, Vector3(tx, -0.2, -0.27), Vector3(PI, 0, 0), 0.0)
	for d2 in ["l", "r"]:
		_cap(R, "uarm_" + d2, 0.1, 0.62, skin, Vector3(0, -0.29, 0))
		_cap(R, "farm_" + d2, 0.075, 0.62, skin, Vector3(0, -0.29, 0))
		_box(R, "hand_" + d2, Vector3(0.14, 0.05, 0.2), skin, Vector3(0, -0.02, -0.08))
		for cx in [-0.045, 0.0, 0.045]:
			_claw(R, "hand_" + d2, Vector3(cx, -0.03, -0.24), Vector3(-PI * 0.5, 0, 0), 0.22)
		_cap(R, "thigh_" + d2, 0.14, 0.52, skin, Vector3(0, -0.22, 0))
		_cap(R, "shin_" + d2, 0.1, 0.5, skin, Vector3(0, -0.22, 0.02))
		_box(R, "foot_" + d2, Vector3(0.16, 0.06, 0.24), skin, Vector3(0, -0.02, -0.06))
		for cx2 in [-0.05, 0.0, 0.05]:
			_claw(R, "foot_" + d2, Vector3(cx2, -0.03, -0.2), Vector3(-PI * 0.5, 0, 0), 0.16)
	eyelight = OmniLight3D.new()
	eyelight.light_color = Color(1.0, 0.45, 0.1)
	eyelight.light_energy = 1.6
	eyelight.omni_range = 7.0
	R.attach("head", eyelight, Vector3(-0.1, 0.07, -0.4))

func make_local() -> void:
	is_local = true
	model.visible = false
	cam = Camera3D.new()
	cam.position = Vector3(0, eye_h, 0)
	cam.fov = 74.0
	cam.near = 0.06
	cam.far = 100.0
	add_child(cam)
	cam.current = true
	if flash != null:
		flash.get_parent().remove_child(flash)
		flash.queue_free()
	flash = SpotLight3D.new()
	flash.spot_range = 30.0
	flash.spot_angle = 32.0
	flash.spot_attenuation = 0.9
	flash.light_energy = 4.5
	flash.light_color = Color(1, 0.96, 0.85)
	flash.position = Vector3(0.15, -0.12, 0)
	cam.add_child(flash)

func set_caught() -> void:
	caught = true
	hidden = false
	if flash != null:
		flash.visible = false
	if not is_local and not is_monster and rig != null:
		rig.rot("root", Vector3(1.5, 0, 0))
		rig.shift("root", Vector3(0, 0.12, 0))
		for b in ["thigh_l", "thigh_r", "uarm_l", "uarm_r", "shin_l", "shin_r", "farm_l", "farm_r"]:
			rig.rot(b, Vector3.ZERO)

func lunge() -> void:
	attack_t = 0.8

func step_now(boost: float = 0.0) -> void:
	if stepper == null or stepper.stream == null:
		return
	stepper.pitch_scale = randf_range(0.8, 1.0) if is_monster else randf_range(0.92, 1.12)
	stepper.volume_db = (10.0 if is_monster else -2.0) + boost
	stepper.play()
	if not is_monster and randf() < 0.35 and rustler != null and rustler.stream != null:
		rustler.pitch_scale = randf_range(0.8, 1.2)
		rustler.play()

func say(stream_name: String, db: float = 6.0, pitch_s: float = 1.0) -> void:
	if not snd.has(stream_name) or voice == null:
		return
	voice.stream = snd[stream_name]
	voice.volume_db = db
	voice.pitch_scale = pitch_s
	voice.play()

# ───────────── التحريك ─────────────
func _process(delta: float) -> void:
	if delta <= 0.0 or rig == null:
		return
	var sp := (global_position - last_pos).length() / delta
	last_pos = global_position
	if fake_speed >= 0.0:
		sp = fake_speed
	speed_est = lerpf(speed_est, sp, minf(1.0, delta * 10.0))
	if is_monster:
		_anim_monster(delta)
	else:
		_anim_human(delta)

func _anim_human(delta: float) -> void:
	if caught:
		return
	var R = rig
	idle_t += delta
	var sp := speed_est
	if not is_local:
		R.rot("head", Vector3(target_pitch * 0.8, 0, 0))
	if sp > 0.4:
		anim_t += delta * sp * 1.7
		var a := clampf(sp / 4.0, 0.0, 1.4)
		var run := sp > 4.8
		var s1 := sin(anim_t)
		var c1 := cos(anim_t)
		R.rot("thigh_l", Vector3(s1 * 0.7 * a, 0, 0))
		R.rot("thigh_r", Vector3(-s1 * 0.7 * a, 0, 0))
		R.rot("shin_l", Vector3(-(0.5 + 0.5 * c1) * 0.9 * a, 0, 0))
		R.rot("shin_r", Vector3(-(0.5 - 0.5 * c1) * 0.9 * a, 0, 0))
		R.rot("uarm_l", Vector3(-s1 * 0.6 * a, 0, 0))
		R.rot("uarm_r", Vector3(s1 * 0.6 * a, 0, 0))
		R.rot("farm_l", Vector3(0.5 * a, 0, 0))
		R.rot("farm_r", Vector3(0.5 * a, 0, 0))
		R.rot("spine", Vector3(0.05 + (0.2 if run else 0.0), s1 * 0.06, 0))
		R.shift("hips", Vector3(0, -absf(s1) * 0.045 * a, 0))
		step_acc += sp * delta
		var stride := 1.5 if run else 1.9
		if step_acc >= stride:
			step_acc = 0.0
			step_now()
		if is_local and cam != null:
			bob_t += delta * sp * 1.6
			cam.position.y = eye_h + sin(bob_t * 2.0) * 0.03 * clampf(sp / 4.0, 0.0, 1.5)
	else:
		for b in ["thigh_l", "thigh_r", "shin_l", "shin_r", "uarm_l", "uarm_r", "farm_l", "farm_r"]:
			R.rot(b, Vector3.ZERO)
		R.rot("spine", Vector3(sin(idle_t * 1.6) * 0.02, 0, 0))
		R.shift("hips", Vector3.ZERO)
		if is_local and cam != null:
			cam.position.y = lerpf(cam.position.y, eye_h, minf(1.0, delta * 8.0))

func _anim_monster(delta: float) -> void:
	var R = rig
	idle_t += delta
	if attack_t > 0.0:
		attack_t -= delta
	var chase := mstate == 1
	var sp := speed_est
	var mv := sp > 0.3
	if mv:
		anim_t += delta * sp * (1.15 if chase else 1.0)
	var s1 := sin(anim_t)
	var c1 := cos(anim_t)
	var amp := clampf(sp / 3.0, 0.0, 2.0) if mv else 0.0
	# أطراف أمامية طويلة تتبادل المد، وخلفية تدفع
	R.rot("uarm_l", Vector3(s1 * 0.85 * amp - 0.35, 0, 0.1))
	R.rot("uarm_r", Vector3(-s1 * 0.85 * amp - 0.35, 0, -0.1))
	R.rot("farm_l", Vector3(0.35 + maxf(0.0, c1) * 0.7 * amp, 0, 0))
	R.rot("farm_r", Vector3(0.35 + maxf(0.0, -c1) * 0.7 * amp, 0, 0))
	R.rot("thigh_l", Vector3(-s1 * 0.7 * amp + 0.25, 0, 0))
	R.rot("thigh_r", Vector3(s1 * 0.7 * amp + 0.25, 0, 0))
	R.rot("shin_l", Vector3(-(0.5 + 0.5 * c1) * 0.9 * amp - 0.3, 0, 0))
	R.rot("shin_r", Vector3(-(0.5 - 0.5 * c1) * 0.9 * amp - 0.3, 0, 0))
	# العمود الفقري يتلوّى والرأس يرتعش بشكل مخيف
	R.rot("spine", Vector3(0.05, s1 * 0.2 * amp + sin(idle_t * 0.9) * 0.04, 0))
	R.rot("chest", Vector3(0.1, -s1 * 0.25 * amp, 0))
	var twitch := 1.0 if (sin(idle_t * 23.0) * sin(idle_t * 3.3) > 0.88) else 0.0
	var scan := sin(idle_t * 0.8) * (0.55 if not chase else 0.1)
	R.rot("neck", Vector3(0.25 + (0.3 if chase else 0.0), scan, sin(idle_t * 1.3) * 0.2))
	R.rot("head", Vector3(sin(idle_t * 2.1) * 0.06, twitch * 0.5 * sin(idle_t * 60.0), twitch * 0.35))
	var jaw_open := 0.1 + 0.08 * sin(idle_t * 2.0)
	if chase:
		jaw_open = 0.45 + 0.2 * sin(idle_t * 14.0)
	R.rot("jaw", Vector3(jaw_open, 0, 0))
	var low := -0.16 if chase else 0.0
	R.shift("hips", Vector3(0, low + sin(anim_t * 2.0) * 0.05 * amp - sin(idle_t * 1.7) * 0.01, 0))
	R.rot("hips", Vector3(-0.05 + (0.12 if chase else 0.0), 0, 0))
	if attack_t > 0.0:
		var k := sin(clampf(attack_t / 0.8, 0.0, 1.0) * PI)
		R.rot("neck", Vector3(-0.6 * k, 0, 0))
		R.rot("jaw", Vector3(0.9 * k, 0, 0))
		R.rot("uarm_l", Vector3(-1.9 * k, 0, 0.3))
		R.rot("uarm_r", Vector3(-1.9 * k, 0, -0.3))
		R.rot("farm_l", Vector3(-0.4 * k, 0, 0))
		R.rot("farm_r", Vector3(-0.4 * k, 0, 0))
	if mv:
		step_acc += sp * delta
		if step_acc >= (2.2 if not chase else 2.6):
			step_acc = 0.0
			step_now()
	if eyelight != null:
		eyelight.light_energy = 1.2 + 0.5 * sin(idle_t * 7.0) + (1.2 if chase else 0.0)
	if breath != null and not breath.playing and breath.stream != null:
		breath.play()
