extends MultiplayerPeerExtension
# اتصال أونلاين عبر خادم الغرف (Relay) بدل الاتصال المباشر.
# يعمل مع RPC العادية في اللعبة بدون أي تغيير.

signal room_created(code: String)
signal relay_error(msg: String)
signal room_closed()

var ws := WebSocketPeer.new()
var is_host := false
var my_id := 0
var status: MultiplayerPeer.ConnectionStatus = MultiplayerPeer.CONNECTION_DISCONNECTED
var target := 0
var queue: Array = []
var room_code := ""
var room_name := ""
var room_max := 4
var last_error := ""
var refuse := false
var _pending := {}
var _opened := false
var _channel := 0
var _mode: MultiplayerPeer.TransferMode = MultiplayerPeer.TRANSFER_MODE_RELIABLE
var connecting_since := 0.0

func host_room(url: String, rname: String, rmax: int) -> Error:
	is_host = true
	room_name = rname
	room_max = rmax
	_pending = {"t": "create", "name": rname, "max": rmax}
	return _open(url)

func join_room(url: String, code: String) -> Error:
	is_host = false
	room_code = code
	_pending = {"t": "join", "code": code}
	return _open(url)

func _open(url: String) -> Error:
	status = MultiplayerPeer.CONNECTION_CONNECTING
	connecting_since = Time.get_ticks_msec() / 1000.0
	_opened = false
	var err := ws.connect_to_url(url)
	if err != OK:
		status = MultiplayerPeer.CONNECTION_DISCONNECTED
	return err

func _on_text(txt: String) -> void:
	var d = JSON.parse_string(txt)
	if typeof(d) != TYPE_DICTIONARY:
		return
	match str(d.get("t", "")):
		"created":
			room_code = str(d["code"])
			my_id = 1
			status = MultiplayerPeer.CONNECTION_CONNECTED
			room_created.emit(room_code)
		"joined":
			my_id = int(d["id"])
			room_name = str(d.get("name", ""))
			room_max = int(d.get("max", 4))
			status = MultiplayerPeer.CONNECTION_CONNECTED
			peer_connected.emit(1)
		"peer_in":
			peer_connected.emit(int(d["id"]))
		"peer_out":
			peer_disconnected.emit(int(d["id"]))
		"closed":
			_lost("closed")
		"err":
			last_error = str(d.get("msg", "error"))
			relay_error.emit(last_error)
			status = MultiplayerPeer.CONNECTION_DISCONNECTED
			ws.close()

func _lost(why: String) -> void:
	if status == MultiplayerPeer.CONNECTION_DISCONNECTED:
		return
	var was_joined := status == MultiplayerPeer.CONNECTION_CONNECTED and not is_host
	status = MultiplayerPeer.CONNECTION_DISCONNECTED
	if was_joined:
		peer_disconnected.emit(1)
	last_error = why
	room_closed.emit()

# ───────────── واجهة MultiplayerPeerExtension ─────────────
func _poll() -> void:
	ws.poll()
	var st := ws.get_ready_state()
	if st == WebSocketPeer.STATE_OPEN:
		if not _opened:
			_opened = true
			ws.send_text(JSON.stringify(_pending))
		while ws.get_available_packet_count() > 0:
			var pkt := ws.get_packet()
			if ws.was_string_packet():
				_on_text(pkt.get_string_from_utf8())
			elif pkt.size() >= 4:
				queue.append([pkt.decode_s32(0), pkt.slice(4)])
	elif st == WebSocketPeer.STATE_CLOSED:
		if status == MultiplayerPeer.CONNECTION_CONNECTING:
			status = MultiplayerPeer.CONNECTION_DISCONNECTED
			last_error = "connect_failed"
			relay_error.emit("connect_failed")
		else:
			_lost("disconnected")

func _get_packet_script() -> PackedByteArray:
	if queue.is_empty():
		return PackedByteArray()
	var e = queue.pop_front()
	return e[1]

func _put_packet_script(p_buffer: PackedByteArray) -> Error:
	if status != MultiplayerPeer.CONNECTION_CONNECTED:
		return ERR_UNCONFIGURED
	var out := PackedByteArray()
	out.resize(4)
	out.encode_s32(0, target if is_host else 1)
	out.append_array(p_buffer)
	return ws.send(out, WebSocketPeer.WRITE_MODE_BINARY)

func _get_available_packet_count() -> int:
	return queue.size()

func _get_max_packet_size() -> int:
	return 60000

func _set_transfer_channel(p_channel: int) -> void:
	_channel = p_channel

func _get_transfer_channel() -> int:
	return _channel

func _set_transfer_mode(p_mode: MultiplayerPeer.TransferMode) -> void:
	_mode = p_mode

func _get_transfer_mode() -> MultiplayerPeer.TransferMode:
	return _mode

func _set_target_peer(p_peer: int) -> void:
	target = p_peer

func _get_packet_peer() -> int:
	if queue.is_empty():
		return 0
	return queue[0][0]

func _get_packet_mode() -> MultiplayerPeer.TransferMode:
	return MultiplayerPeer.TRANSFER_MODE_RELIABLE

func _get_packet_channel() -> int:
	return 0

func _is_server() -> bool:
	return is_host

func _close() -> void:
	ws.close()
	queue.clear()
	status = MultiplayerPeer.CONNECTION_DISCONNECTED

func _disconnect_peer(p_peer: int, p_force: bool) -> void:
	pass

func _get_unique_id() -> int:
	return my_id

func _set_refuse_new_connections(p_enable: bool) -> void:
	refuse = p_enable

func _is_refusing_new_connections() -> bool:
	return refuse

func _is_server_relay_supported() -> bool:
	return true

func _get_connection_status() -> MultiplayerPeer.ConnectionStatus:
	return status
