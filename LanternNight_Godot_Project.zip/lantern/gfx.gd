extends RefCounted
# خامات وتكسيرات تُولَّد بالكود (بدون ملفات صور) لمظهر أقرب للواقعية

var cache := {}
var tcache := {}

func _noise(seed_v: int, freq: float, size: int = 256, octaves: int = 4) -> Image:
	var n := FastNoiseLite.new()
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.seed = seed_v
	n.frequency = freq
	n.fractal_octaves = octaves
	var img := n.get_image(size, size, false, false, true)
	img.convert(Image.FORMAT_RGB8)
	return img

func _tex(img: Image) -> ImageTexture:
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)

func _normal_from(bump: Image, strength: float) -> ImageTexture:
	var nm := bump.duplicate() as Image
	nm.bump_map_to_normal_map(strength)
	return _tex(nm)

func _pattern(kind: String) -> Array:
	# يرجع [ألبيدو, نورمال]
	if tcache.has(kind):
		return tcache[kind]
	var res: Array = []
	var s := 128
	if kind == "brick" or kind == "planks" or kind == "tile":
		var alb := Image.create(s, s, false, Image.FORMAT_RGB8)
		var bump := Image.create(s, s, false, Image.FORMAT_RGB8)
		var nz := _noise(11, 0.09, s, 3)
		for y in s:
			for x in s:
				var g := nz.get_pixel(x, y).r
				var v := 0.7
				var h := 0.8
				if kind == "brick":
					var row := y / 16
					var off := 16 if (row % 2 == 1) else 0
					var col := (x + off) / 32
					var mortar := (y % 16) < 2 or ((x + off) % 32) < 2
					var shade := float(((row * 73856093) ^ (col * 19349663)) % 100) / 100.0
					if mortar:
						v = 0.45 + g * 0.15
						h = 0.15
					else:
						v = 0.62 + shade * 0.3 + g * 0.12
						h = 0.7 + g * 0.2
				elif kind == "planks":
					var px := x % 20
					var gap := px < 2
					var grain := sin(float(y) * 0.35 + float(x / 20) * 3.1 + g * 6.0) * 0.5 + 0.5
					var shade2 := float(((x / 20) * 2654435761) % 100) / 100.0
					v = 0.4 + shade2 * 0.25 + grain * 0.12 if not gap else 0.12
					h = 0.2 if gap else 0.7 + grain * 0.1
				else:
					var tx := x % 32
					var ty := y % 32
					var grout := tx < 2 or ty < 2
					var sh := float(((x / 32) * 31 + (y / 32) * 17) % 7) / 7.0
					v = 0.32 if grout else (0.62 + sh * 0.18 + g * 0.1)
					h = 0.1 if grout else 0.7
				alb.set_pixel(x, y, Color(v, v, v))
				bump.set_pixel(x, y, Color(h, h, h))
		res = [_tex(alb), _normal_from(bump, 3.0)]
	else:
		var seed_v := 3
		var freq := 0.03
		match kind:
			"dirt": seed_v = 21; freq = 0.04
			"grass": seed_v = 33; freq = 0.08
			"concrete": seed_v = 5; freq = 0.05
			"plaster": seed_v = 8; freq = 0.025
			"rock": seed_v = 71; freq = 0.05
			"bark": seed_v = 91; freq = 0.12
			"cloth": seed_v = 12; freq = 0.15
		var img := _noise(seed_v, freq, 256, 5)
		var fine := _noise(seed_v + 100, 0.35, 256, 2)
		var contrast := 0.32
		var base := 0.74
		if kind == "grass" or kind == "dirt" or kind == "bark" or kind == "rock":
			contrast = 0.55
			base = 0.62
		var bump := img.duplicate() as Image
		for y in 256:
			for x in 256:
				var c := img.get_pixel(x, y).r
				var f := fine.get_pixel(x, y).r
				var v := clampf(base + (c - 0.5) * contrast + (f - 0.5) * 0.18, 0.05, 1.0)
				img.set_pixel(x, y, Color(v, v, v))
				var hb := clampf(0.5 + (c - 0.5) * 0.6 + (f - 0.5) * 0.5, 0.0, 1.0)
				bump.set_pixel(x, y, Color(hb, hb, hb))
		res = [_tex(img), _normal_from(bump, 2.0)]
	tcache[kind] = res
	return res

func _mk(color: Color, pattern: String, scale_v: float, rough: float = 0.9, metal: float = 0.0, world: bool = true) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	if pattern != "":
		var t: Array = _pattern(pattern)
		m.albedo_texture = t[0]
		m.normal_enabled = true
		m.normal_texture = t[1]
		m.normal_scale = 0.8
		m.uv1_triplanar = true
		m.uv1_world_triplanar = world
		m.uv1_scale = Vector3(scale_v, scale_v, scale_v)
	return m

func get_mat(key: String) -> StandardMaterial3D:
	if cache.has(key):
		return cache[key]
	var m: StandardMaterial3D
	match key:
		"plaster_a": m = _mk(Color(0.86, 0.72, 0.5), "plaster", 0.22)
		"plaster_b": m = _mk(Color(0.78, 0.45, 0.33), "plaster", 0.22)
		"plaster_c": m = _mk(Color(0.62, 0.68, 0.7), "plaster", 0.22)
		"brick": m = _mk(Color(0.85, 0.45, 0.36), "brick", 0.3)
		"wood": m = _mk(Color(0.8, 0.55, 0.32), "planks", 0.35)
		"wood_dark": m = _mk(Color(0.5, 0.32, 0.2), "planks", 0.35)
		"concrete": m = _mk(Color(0.72, 0.72, 0.7), "concrete", 0.2)
		"school_wall": m = _mk(Color(0.72, 0.8, 0.72), "plaster", 0.25)
		"ceiling": m = _mk(Color(0.55, 0.57, 0.55), "concrete", 0.2)
		"metal": m = _mk(Color(0.35, 0.5, 0.6), "concrete", 0.4, 0.45, 0.6)
		"metal_dark": m = _mk(Color(0.25, 0.25, 0.27), "concrete", 0.4, 0.5, 0.6)
		"tile": m = _mk(Color(0.8, 0.85, 0.8), "tile", 0.3, 0.55)
		"dirt": m = _mk(Color(0.55, 0.45, 0.35), "dirt", 0.12)
		"grass": m = _mk(Color(0.32, 0.5, 0.25), "grass", 0.14)
		"bark": m = _mk(Color(0.4, 0.3, 0.24), "bark", 0.5)
		"leaves": m = _mk(Color(0.12, 0.3, 0.14), "grass", 0.3)
		"leaves2": m = _mk(Color(0.16, 0.36, 0.16), "grass", 0.3)
		"rock": m = _mk(Color(0.5, 0.5, 0.52), "rock", 0.3)
		"cloth": m = _mk(Color(0.55, 0.2, 0.18), "cloth", 0.8)
		"hay": m = _mk(Color(0.85, 0.7, 0.3), "cloth", 0.7)
		"roof": m = _mk(Color(0.4, 0.2, 0.15), "brick", 0.3)
		"window_lit":
			m = StandardMaterial3D.new()
			m.albedo_color = Color(1, 0.62, 0.3)
			m.emission_enabled = true
			m.emission = Color(1, 0.55, 0.2)
			m.emission_energy_multiplier = 1.1
		"window_dark":
			m = StandardMaterial3D.new()
			m.albedo_color = Color(0.03, 0.04, 0.06)
			m.roughness = 0.3
		"lamp":
			m = StandardMaterial3D.new()
			m.albedo_color = Color(1, 0.85, 0.55)
			m.emission_enabled = true
			m.emission = Color(1, 0.75, 0.35)
			m.emission_energy_multiplier = 2.5
		"tube":
			m = StandardMaterial3D.new()
			m.albedo_color = Color(0.85, 1, 0.9)
			m.emission_enabled = true
			m.emission = Color(0.7, 1, 0.8)
			m.emission_energy_multiplier = 1.8
		"monster_skin": m = _mk(Color(0.46, 0.08, 0.07), "bark", 1.2, 0.8, 0.0, false)
		"suit": m = _mk(Color(0.55, 0.55, 0.58), "cloth", 1.5, 0.8, 0.0, false)
		"board":
			m = _mk(Color(0.08, 0.2, 0.15), "plaster", 0.3)
		_:
			m = _mk(Color(0.6, 0.6, 0.6), "", 1.0)
	cache[key] = m
	return m
