extends RefCounted
# هيكل عظمي (Skeleton3D) بسيط: عظام + مجسمات مربوطة بالعظام + تحريك بالكود

var skel: Skeleton3D
var idx := {}
var rest := {}

func _init(parent: Node3D) -> void:
	skel = Skeleton3D.new()
	parent.add_child(skel)

func bone(nm: String, parent_name: String, pos: Vector3) -> void:
	var i := skel.add_bone(nm)
	if parent_name != "":
		skel.set_bone_parent(i, idx[parent_name])
	skel.set_bone_rest(i, Transform3D(Basis(), pos))
	idx[nm] = i
	rest[nm] = pos

func finish() -> void:
	skel.reset_bone_poses()

func attach(nm: String, node: Node3D, pos: Vector3 = Vector3.ZERO, rot: Vector3 = Vector3.ZERO) -> Node3D:
	var ba := BoneAttachment3D.new()
	skel.add_child(ba)
	ba.bone_name = nm
	node.position = pos
	node.rotation = rot
	ba.add_child(node)
	return node

func rot(nm: String, euler: Vector3) -> void:
	skel.set_bone_pose_rotation(idx[nm], Quaternion.from_euler(euler))

func shift(nm: String, offset: Vector3) -> void:
	skel.set_bone_pose_position(idx[nm], rest[nm] + offset)
