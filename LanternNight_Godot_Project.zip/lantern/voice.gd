extends Node
# دردشة صوتية (مايك) للأونلاين: التقاط → 8kHz → ضغط μ-law → إرسال، والاستقبال يشغّل الصوت

const RATE := 8000
const CHUNK := 160
var main
var enabled := false
var capture: AudioEffectCapture
var mic_player: AudioStreamPlayer
var out_buf := PackedFloat32Array()
var sum := 0.0
var cnt := 0
var pos := 0.0
var talk_hold := 0.0
var gens := {}
var talking := false

func setup() -> void:
	AudioServer.add_bus()
	var idx := AudioServer.bus_count - 1
	AudioServer.set_bus_name(idx, "Mic")
	AudioServer.set_bus_mute(idx, true)
	capture = AudioEffectCapture.new()
	capture.buffer_length = 0.25
	AudioServer.add_bus_effect(idx, capture)
	mic_player = AudioStreamPlayer.new()
	mic_player.stream = AudioStreamMicrophone.new()
	mic_player.bus = "Mic"
	add_child(mic_player)

func set_enabled(on: bool) -> void:
	enabled = on
	if on:
		if OS.get_name() == "Android":
			OS.request_permissions()
		if not mic_player.playing:
			mic_player.play()
		capture.clear_buffer()
	else:
		mic_player.stop()
		talking = false

static func enc(x: float) -> int:
	var s := 0 if x >= 0.0 else 128
	var a := minf(absf(x), 1.0)
	var u := log(1.0 + 255.0 * a) / log(256.0)
	return int(u * 127.0 + 0.5) | s

static func dec(b: int) -> float:
	var s := -1.0 if (b & 128) != 0 else 1.0
	var u := float(b & 127) / 127.0
	return s * (pow(256.0, u) - 1.0) / 255.0

func encode_chunk(samples: PackedFloat32Array) -> PackedByteArray:
	var out := PackedByteArray()
	out.resize(samples.size())
	for i in samples.size():
		out[i] = enc(samples[i])
	return out

func _process(delta: float) -> void:
	if not enabled or capture == null:
		return
	var n := capture.get_frames_available()
	if n <= 0:
		return
	var buf := capture.get_buffer(n)
	var step := AudioServer.get_mix_rate() / float(RATE)
	for i in buf.size():
		sum += (buf[i].x + buf[i].y) * 0.5
		cnt += 1
		pos += 1.0
		if pos >= step:
			out_buf.append(sum / float(cnt))
			sum = 0.0
			cnt = 0
			pos -= step
	while out_buf.size() >= CHUNK:
		var chunk := out_buf.slice(0, CHUNK)
		out_buf = out_buf.slice(CHUNK)
		var e := 0.0
		for v in chunk:
			e += v * v
		var rms := sqrt(e / float(CHUNK))
		if rms > 0.012:
			talk_hold = 0.4
		talking = talk_hold > 0.0
		talk_hold = maxf(0.0, talk_hold - float(CHUNK) / float(RATE))
		if talking and main != null:
			main.send_voice(encode_chunk(chunk))

func receive(id: int, data: PackedByteArray) -> void:
	if not gens.has(id):
		var p := AudioStreamPlayer.new()
		var g := AudioStreamGenerator.new()
		g.mix_rate = RATE
		g.buffer_length = 0.5
		p.stream = g
		p.volume_db = 4.0
		add_child(p)
		p.play()
		gens[id] = p
	var pl: AudioStreamPlayer = gens[id]
	var pb := pl.get_stream_playback() as AudioStreamGeneratorPlayback
	if pb == null:
		return
	var frames := PackedVector2Array()
	frames.resize(data.size())
	for i in data.size():
		var v := dec(data[i])
		frames[i] = Vector2(v, v)
	if pb.get_frames_available() >= frames.size():
		pb.push_buffer(frames)

func remove_peer(id: int) -> void:
	if gens.has(id):
		gens[id].queue_free()
		gens.erase(id)
