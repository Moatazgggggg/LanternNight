extends Node3D
# ليلة الفانوس — استغماية عبر نقطة الاتصال (Hotspot) بدون إنترنت

const PORT := 9797
const MAX_CLIENTS := 3          # المضيف + 3 أصدقاء = 4 لاعبين
const HIDE_TIME := 15.0
const ROUND_TIME := 150.0
const CATCH_DIST := 2.6
const VIS_DIST := 9.0
const SPEED := 6.0
const HALF := 22.0
const STICK_R := 90.0
const SPAWNS := [Vector3(-20.5, 0, -20.5), Vector3(20.5, 0, -20.5), Vector3(-20.5, 0, 20.5), Vector3(20.5, 0, 20.5)]
const COLORS := [Color(0.35, 0.7, 1.0), Color(0.4, 0.9, 0.5), Color(0.95, 0.8, 0.3), Color(0.8, 0.5, 0.95)]
const STORY := "في حارة قديمة من حارات القاهرة، كان هناك فانوس سحري ينير الدرب لأهل الحارة كل ليلة.\n\nوفي ليلة بلا قمر، استيقظ عفريت الحارة الغيور، وأقسم أن يطفئ نور الفانوس بالقبض على كل من يتجوّل في الظلام.\n\nاختبئوا في الأزقة وخلف البيوت والصناديق، وصمدوا حتى يطلع الفجر وينكسر سحر العفريت.\n\nأما العفريت، فعليه أن يجدهم جميعاً قبل أن تشرق الشمس!"

enum Phase { MENU, LOBBY, COUNT, PLAY, END }

class Player extends CharacterBody3D:
	var pid := 0
	var is_seeker := false
	var caught := false
	var target_pos := Vector3.ZERO
	var body: MeshInstance3D
	var lamp: OmniLight3D

class Stick extends Control:
	var origin := Vector2.ZERO
	var knob := Vector2.ZERO
	var active := false
	func _draw() -> void:
		if not active:
			return
		draw_circle(origin, 90.0, Color(1, 1, 1, 0.10))
		draw_arc(origin, 90.0, 0.0, TAU, 40, Color(1, 1, 1, 0.35), 3.0)
		draw_circle(origin + knob, 38.0, Color(1, 0.85, 0.5, 0.55))

var phase := Phase.MENU
var font: Font
var pnames := {}
var players := {}
var seeker_id := 0
var time_left := 0.0
var local: Player = null
var cam: Camera3D
var map_root: Node3D
var actors: Node3D
var mats := []
var stick_idx := -1
var stick_origin := Vector2.ZERO
var stick_vec := Vector2.ZERO
var last_sent := 0.0
var banner_id := 0

# UI
var root: Control
var panels := {}
var name_edit: LineEdit
var ip_edit: LineEdit
var status_lbl: Label
var lobby_ip: Label
var lobby_list: Label
var lobby_start: Button
var lobby_wait: Label
var end_lbl: Label
var end_btn: Button
var end_wait: Label
var hud: Control
var top_lbl: Label
var catch_btn: Button
var banner_lbl: Label
var overlay: ColorRect
var overlay_lbl: Label
var stick: Stick

func _ready() -> void:
	Engine.max_fps = 60
	DisplayServer.screen_set_keep_on(true)
	font = load("res://fonts/Cairo_700Bold.ttf")
	build_world()
	build_ui()
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_conn_failed)
	multiplayer.server_disconnected.connect(_on_server_lost)
	show_panel("menu")

# ───────────────────────── العالم ─────────────────────────
func build_world() -> void:
	for c in [Color(0.78, 0.62, 0.4), Color(0.7, 0.45, 0.35), Color(0.85, 0.75, 0.55), Color(0.55, 0.4, 0.3), Color(0.62, 0.55, 0.45)]:
		var m := StandardMaterial3D.new()
		m.albedo_color = c
		m.roughness = 1.0
		mats.append(m)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.03, 0.04, 0.1)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.4, 0.45, 0.7)
	env.ambient_light_energy = 0.8
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, 30, 0)
	sun.light_energy = 0.4
	sun.light_color = Color(0.65, 0.72, 1.0)
	add_child(sun)
	map_root = Node3D.new()
	add_child(map_root)
	actors = Node3D.new()
	add_child(actors)
	# الأرض
	var g := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(HALF * 2 + 8, HALF * 2 + 8)
	g.mesh = pm
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Color(0.3, 0.26, 0.21)
	gm.roughness = 1.0
	g.material_override = gm
	map_root.add_child(g)
	# الأسوار
	var t := 1.0
	add_box(Vector3(0, 0, -HALF), Vector3(HALF * 2 + 2, 4, t), 3)
	add_box(Vector3(0, 0, HALF), Vector3(HALF * 2 + 2, 4, t), 3)
	add_box(Vector3(-HALF, 0, 0), Vector3(t, 4, HALF * 2 + 2), 3)
	add_box(Vector3(HALF, 0, 0), Vector3(t, 4, HALF * 2 + 2), 3)
	# البيوت (نفس التوزيع عند الجميع)
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261109
	for gx in [-15, -5, 5, 15]:
		for gz in [-15, -5, 5, 15]:
			if rng.randf() < 0.2:
				continue
			var sz := Vector3(rng.randf_range(4.0, 6.5), rng.randf_range(2.6, 4.2), rng.randf_range(4.0, 6.5))
			var p := Vector3(gx + rng.randf_range(-0.5, 0.5), 0, gz + rng.randf_range(-0.5, 0.5))
			add_box(p, sz, rng.randi() % 5)
	# صناديق وبراميل للاختباء
	for i in 18:
		var cp := Vector3(rng.randf_range(-19, 19), 0, rng.randf_range(-19, 19))
		if absf(cp.x) > 17.0 and absf(cp.z) > 17.0:
			continue
		var s := rng.randf_range(1.0, 1.6)
		add_box(cp, Vector3(s, s, s), 4)
	# فوانيس الحارة
	for fx in [-10, 0, 10]:
		for fz in [-10, 0, 10]:
			add_lantern(Vector3(fx, 0, fz))
	var big := OmniLight3D.new()
	big.position = Vector3(0, 3.0, 0)
	big.omni_range = 9.0
	big.light_energy = 0.9
	big.light_color = Color(1.0, 0.75, 0.4)
	map_root.add_child(big)
	# الكاميرا
	cam = Camera3D.new()
	cam.rotation_degrees = Vector3(-57, 0, 0)
	cam.position = Vector3(0, 18, 11)
	cam.fov = 60
	cam.far = 90
	add_child(cam)
	cam.current = true

func add_box(pos: Vector3, size: Vector3, mat_idx: int) -> void:
	var b := StaticBody3D.new()
	b.collision_layer = 1
	b.collision_mask = 0
	b.position = pos + Vector3(0, size.y / 2.0, 0)
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	b.add_child(cs)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mats[mat_idx]
	b.add_child(mi)
	map_root.add_child(b)

func add_lantern(pos: Vector3) -> void:
	var pole := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.07
	cm.bottom_radius = 0.1
	cm.height = 2.4
	cm.radial_segments = 6
	pole.mesh = cm
	pole.material_override = mats[3]
	pole.position = pos + Vector3(0, 1.2, 0)
	map_root.add_child(pole)
	var ball := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.28
	sm.height = 0.56
	sm.radial_segments = 8
	sm.rings = 4
	ball.mesh = sm
	var em := StandardMaterial3D.new()
	em.albedo_color = Color(1, 0.7, 0.3)
	em.emission_enabled = true
	em.emission = Color(1, 0.65, 0.2)
	em.emission_energy_multiplier = 2.0
	ball.material_override = em
	ball.position = pos + Vector3(0, 2.55, 0)
	map_root.add_child(ball)

func make_player(id: int, nm: String, idx: int) -> Player:
	var p := Player.new()
	p.pid = id
	p.name = str(id)
	p.collision_layer = 2
	p.collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.45
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	p.add_child(cs)
	var mi := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.45
	cm.height = 1.8
	cm.radial_segments = 10
	cm.rings = 4
	mi.mesh = cm
	mi.position.y = 0.9
	var m := StandardMaterial3D.new()
	m.albedo_color = COLORS[idx % COLORS.size()]
	mi.material_override = m
	p.add_child(mi)
	p.body = mi
	var l := OmniLight3D.new()
	l.position.y = 1.8
	l.omni_range = 4.0
	l.light_energy = 0.7
	l.light_color = Color(1, 0.85, 0.55)
	p.add_child(l)
	p.lamp = l
	var tag := Label3D.new()
	tag.text = nm
	tag.font = font
	tag.font_size = 56
	tag.pixel_size = 0.008
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tag.position.y = 2.6
	tag.outline_size = 12
	p.add_child(tag)
	return p

# ───────────────────────── الواجهة ─────────────────────────
func lbl(t: String, sz: int = 30, col: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", sz)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

func btn(t: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(0, 68)
	b.add_theme_font_size_override("font_size", 32)
	b.pressed.connect(cb)
	return b

func make_panel(key: String, width: float = 640.0) -> VBoxContainer:
	var c := CenterContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.04, 0.05, 0.12, 0.9)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	var wrap := Control.new()
	wrap.set_anchors_preset(Control.PRESET_FULL_RECT)
	wrap.add_child(bg)
	wrap.add_child(c)
	var v := VBoxContainer.new()
	v.custom_minimum_size = Vector2(width, 0)
	v.add_theme_constant_override("separation", 14)
	c.add_child(v)
	root.add_child(wrap)
	panels[key] = wrap
	return v

func show_panel(key: String) -> void:
	for k in panels:
		panels[k].visible = (k == key)
	hud.visible = false
	overlay.visible = false

func build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.layout_direction = Control.LAYOUT_DIRECTION_RTL
	var th := Theme.new()
	th.default_font = font
	th.default_font_size = 30
	root.theme = th
	layer.add_child(root)

	# --- HUD (يُضاف أولاً ليكون خلف القوائم)
	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud)
	stick = Stick.new()
	stick.set_anchors_preset(Control.PRESET_FULL_RECT)
	stick.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(stick)
	top_lbl = lbl("", 34, Color(1, 0.9, 0.6))
	top_lbl.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top_lbl.offset_top = 14
	top_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(top_lbl)
	catch_btn = btn("امسكه!", _on_catch)
	catch_btn.custom_minimum_size = Vector2(260, 130)
	catch_btn.add_theme_font_size_override("font_size", 44)
	catch_btn.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 40)
	hud.add_child(catch_btn)
	banner_lbl = lbl("", 38, Color(1, 1, 1))
	banner_lbl.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	banner_lbl.custom_minimum_size = Vector2(900, 0)
	banner_lbl.offset_top = 80
	banner_lbl.offset_left = -450
	banner_lbl.offset_right = 450
	banner_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	banner_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	banner_lbl.add_theme_constant_override("outline_size", 10)
	hud.add_child(banner_lbl)
	overlay = ColorRect.new()
	overlay.color = Color.BLACK
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(overlay)
	overlay_lbl = lbl("", 44, Color(1, 0.85, 0.5))
	overlay_lbl.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	overlay_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(overlay_lbl)

	# --- القائمة الرئيسية
	var m := make_panel("menu")
	m.add_child(lbl("ليلة الفانوس", 84, Color(1, 0.78, 0.35)))
	m.add_child(lbl("استغماية الحارة مع أصدقائك — بدون إنترنت", 28, Color(0.85, 0.9, 1)))
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "اسمك"
	name_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_edit.max_length = 12
	name_edit.custom_minimum_size = Vector2(0, 64)
	m.add_child(name_edit)
	m.add_child(btn("إنشاء غرفة (أنا المضيف)", host_game))
	ip_edit = LineEdit.new()
	ip_edit.text = "192.168.43.1"
	ip_edit.placeholder_text = "عنوان المضيف"
	ip_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	ip_edit.custom_minimum_size = Vector2(0, 64)
	ip_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_URL
	m.add_child(ip_edit)
	m.add_child(btn("انضمام لغرفة", join_game))
	m.add_child(btn("القصة", func(): show_panel("story")))
	status_lbl = lbl("شغّل نقطة الاتصال (Hotspot) على جهاز واحد وباقي الأصدقاء يتصلون بها", 24, Color(0.8, 0.8, 0.9))
	m.add_child(status_lbl)

	# --- القصة
	var s := make_panel("story", 860.0)
	s.add_child(lbl("القصة", 56, Color(1, 0.78, 0.35)))
	s.add_child(lbl(STORY, 30))
	s.add_child(btn("رجوع", func(): show_panel("menu")))

	# --- الغرفة
	var r := make_panel("lobby")
	r.add_child(lbl("غرفة اللعب", 56, Color(1, 0.78, 0.35)))
	lobby_ip = lbl("", 26, Color(0.7, 1, 0.8))
	r.add_child(lobby_ip)
	lobby_list = lbl("", 34)
	r.add_child(lobby_list)
	lobby_start = btn("ابدأ الاستغماية", _on_start_pressed)
	r.add_child(lobby_start)
	lobby_wait = lbl("في انتظار المضيف ليبدأ اللعبة...", 28, Color(0.85, 0.9, 1))
	r.add_child(lobby_wait)
	r.add_child(btn("خروج", leave_to_menu))

	# --- النهاية
	var e := make_panel("end")
	end_lbl = lbl("", 60, Color(1, 0.85, 0.4))
	e.add_child(end_lbl)
	end_btn = btn("جولة جديدة", _on_new_round)
	e.add_child(end_btn)
	end_wait = lbl("في انتظار المضيف...", 28, Color(0.85, 0.9, 1))
	e.add_child(end_wait)

func banner(t: String, secs: float = 4.0) -> void:
	banner_id += 1
	var my := banner_id
	banner_lbl.text = t
	banner_lbl.visible = true
	await get_tree().create_timer(secs).timeout
	if my == banner_id:
		banner_lbl.visible = false

func my_name() -> String:
	var n := name_edit.text.strip_edges()
	if n == "":
		n = "لاعب"
	return n

func local_ips() -> String:
	var out := []
	for a in IP.get_local_addresses():
		if a.count(".") == 3 and not a.begins_with("127.") and not a.begins_with("169.254"):
			out.append(a)
	return " — ".join(out)

# ───────────────────────── الشبكة ─────────────────────────
func host_game() -> void:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_CLIENTS)
	if err != OK:
		status_lbl.text = "تعذّر إنشاء الغرفة، جرّب مرة أخرى"
		return
	multiplayer.multiplayer_peer = peer
	pnames = {1: my_name()}
	phase = Phase.LOBBY
	refresh_lobby()
	show_panel("lobby")

func join_game() -> void:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip_edit.text.strip_edges(), PORT)
	if err != OK:
		status_lbl.text = "عنوان غير صحيح"
		return
	multiplayer.multiplayer_peer = peer
	status_lbl.text = "جاري الاتصال..."

func _on_connected() -> void:
	rpc_id(1, "net_register", my_name())

func _on_conn_failed() -> void:
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	status_lbl.text = "فشل الاتصال — تأكد أنك متصل بنقطة اتصال المضيف وأن العنوان صحيح"

func _on_server_lost() -> void:
	leave_to_menu()
	status_lbl.text = "انقطع الاتصال بالمضيف"

func leave_to_menu() -> void:
	clear_players()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	pnames = {}
	phase = Phase.MENU
	show_panel("menu")

func _on_peer_disconnected(id: int) -> void:
	if not multiplayer.is_server():
		return
	pnames.erase(id)
	if players.has(id):
		players[id].queue_free()
		players.erase(id)
	rpc("net_lobby", pnames)
	if phase == Phase.COUNT or phase == Phase.PLAY:
		if id == seeker_id or players.size() < 2:
			rpc("net_end", false)
		else:
			check_end()

@rpc("any_peer", "reliable")
func net_register(nm: String) -> void:
	var id := multiplayer.get_remote_sender_id()
	if phase != Phase.LOBBY:
		multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	pnames[id] = nm
	rpc("net_lobby", pnames)

@rpc("authority", "call_local", "reliable")
func net_lobby(d: Dictionary) -> void:
	pnames = d
	if phase == Phase.MENU or phase == Phase.LOBBY:
		phase = Phase.LOBBY
		refresh_lobby()
		show_panel("lobby")

func refresh_lobby() -> void:
	var lines := []
	for id in pnames:
		lines.append("• " + str(pnames[id]))
	lobby_list.text = "\n".join(lines)
	var is_host := multiplayer.is_server()
	lobby_ip.text = ("عنوان غرفتك: " + local_ips()) if is_host else "تم الاتصال بالغرفة"
	lobby_start.visible = is_host
	lobby_wait.visible = not is_host
	lobby_start.disabled = pnames.size() < 2

func _on_start_pressed() -> void:
	if not multiplayer.is_server() or pnames.size() < 2:
		return
	var ids := pnames.keys()
	var sk: int = ids.pick_random()
	var pts := SPAWNS.duplicate()
	pts.shuffle()
	var spawns := {}
	for i in ids.size():
		spawns[ids[i]] = pts[i]
	rpc("net_begin", sk, spawns)

@rpc("authority", "call_local", "reliable")
func net_begin(sk: int, spawns: Dictionary) -> void:
	clear_players()
	seeker_id = sk
	var i := 0
	for id in pnames:
		var p := make_player(id, str(pnames[id]), i)
		i += 1
		actors.add_child(p)
		p.global_position = spawns[id]
		p.target_pos = spawns[id]
		p.is_seeker = (id == sk)
		if p.is_seeker:
			var sm := StandardMaterial3D.new()
			sm.albedo_color = Color(0.9, 0.15, 0.2)
			p.body.material_override = sm
			p.lamp.omni_range = VIS_DIST
			p.lamp.light_color = Color(1, 0.4, 0.3)
		players[id] = p
	local = players[multiplayer.get_unique_id()]
	phase = Phase.COUNT
	time_left = HIDE_TIME
	for k in panels:
		panels[k].visible = false
	hud.visible = true
	overlay.visible = local.is_seeker
	var sname := str(pnames[sk])
	if local.is_seeker:
		banner("أنت العفريت! غمّض عينيك حتى ينتهي العدّ", 5.0)
	else:
		banner("العفريت %s يعدّ الآن.. اختبئ بسرعة!" % sname, 5.0)

@rpc("authority", "call_local", "reliable")
func net_go() -> void:
	phase = Phase.PLAY
	time_left = ROUND_TIME
	overlay.visible = false
	if local.is_seeker:
		banner("افتح عينيك! ابحث عنهم وامسكهم قبل الفجر", 4.0)
	else:
		banner("العفريت انطلق! صمدوا حتى الفجر", 4.0)

@rpc("any_peer", "unreliable")
func net_pos(pos: Vector3) -> void:
	var id := multiplayer.get_remote_sender_id()
	if players.has(id):
		players[id].target_pos = pos

@rpc("any_peer", "reliable")
func net_req_catch() -> void:
	do_catch(multiplayer.get_remote_sender_id())

func _on_catch() -> void:
	if phase != Phase.PLAY or local == null or not local.is_seeker:
		return
	if multiplayer.is_server():
		do_catch(1)
	else:
		rpc_id(1, "net_req_catch")

func do_catch(sender: int) -> void:
	if phase != Phase.PLAY or sender != seeker_id or not players.has(sender):
		return
	var sp: Vector3 = players[sender].global_position
	var best := 0
	var bd := CATCH_DIST
	for id in players:
		var p: Player = players[id]
		if id == seeker_id or p.caught:
			continue
		var d := sp.distance_to(p.global_position)
		if d < bd:
			bd = d
			best = id
	if best != 0:
		rpc("net_caught", best)
		check_end()

@rpc("authority", "call_local", "reliable")
func net_caught(id: int) -> void:
	if not players.has(id):
		return
	var p: Player = players[id]
	p.caught = true
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Color(0.4, 0.4, 0.42)
	p.body.material_override = gm
	p.lamp.visible = false
	if p == local:
		Input.vibrate_handheld(250)
		banner("مسكك العفريت! انتهت لعبتك", 4.0)
	else:
		banner("العفريت مسك %s" % str(pnames.get(id, "")), 3.0)

func check_end() -> void:
	for id in players:
		if id != seeker_id and not players[id].caught:
			return
	rpc("net_end", true)

@rpc("authority", "call_local", "reliable")
func net_end(seeker_won: bool) -> void:
	phase = Phase.END
	overlay.visible = false
	hud.visible = false
	stick_idx = -1
	stick_vec = Vector2.ZERO
	stick.active = false
	var sname := str(pnames.get(seeker_id, "العفريت"))
	if seeker_won:
		end_lbl.text = "فاز العفريت %s!\nأُطفئ الفانوس" % sname
	else:
		end_lbl.text = "طلع الفجر!\nفاز أولاد الحارة وانكسر السحر"
	var is_host := multiplayer.is_server()
	end_btn.visible = is_host
	end_wait.visible = not is_host
	show_panel("end")

func _on_new_round() -> void:
	if multiplayer.is_server():
		rpc("net_to_lobby")

@rpc("authority", "call_local", "reliable")
func net_to_lobby() -> void:
	clear_players()
	phase = Phase.LOBBY
	refresh_lobby()
	show_panel("lobby")

func clear_players() -> void:
	for id in players:
		if is_instance_valid(players[id]):
			players[id].queue_free()
	players.clear()
	local = null
	cam.position = Vector3(0, 18, 11)

# ───────────────────────── اللعب ─────────────────────────
func _input(event: InputEvent) -> void:
	if phase != Phase.COUNT and phase != Phase.PLAY:
		return
	var half := get_viewport().get_visible_rect().size.x * 0.55
	if event is InputEventScreenTouch:
		if event.pressed and stick_idx == -1 and event.position.x < half:
			stick_idx = event.index
			stick_origin = event.position
			stick.origin = event.position
			stick.knob = Vector2.ZERO
			stick.active = true
			stick.queue_redraw()
		elif not event.pressed and event.index == stick_idx:
			stick_idx = -1
			stick_vec = Vector2.ZERO
			stick.active = false
			stick.queue_redraw()
	elif event is InputEventScreenDrag and event.index == stick_idx:
		var d: Vector2 = event.position - stick_origin
		stick_vec = (d / STICK_R).limit_length(1.0)
		stick.knob = stick_vec * STICK_R
		stick.queue_redraw()

func _physics_process(delta: float) -> void:
	if local == null or (phase != Phase.COUNT and phase != Phase.PLAY):
		return
	var dir := stick_vec
	if dir == Vector2.ZERO:
		dir = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var frozen := local.caught or (phase == Phase.COUNT and local.is_seeker)
	if not frozen and dir.length() > 0.05:
		local.velocity = Vector3(dir.x, 0, dir.y) * SPEED
		local.move_and_slide()
		local.global_position.y = 0.0
	last_sent += delta
	if last_sent >= 0.05:
		last_sent = 0.0
		rpc("net_pos", local.global_position)

func _process(delta: float) -> void:
	if local == null or (phase != Phase.COUNT and phase != Phase.PLAY):
		return
	time_left = maxf(0.0, time_left - delta)
	for id in players:
		var p: Player = players[id]
		if p != local:
			p.global_position = p.global_position.lerp(p.target_pos, minf(1.0, delta * 14.0))
	update_visibility()
	var want := local.global_position + Vector3(0, 13, 8.5)
	cam.global_position = cam.global_position.lerp(want, minf(1.0, delta * 8.0))
	update_hud()
	if multiplayer.is_server():
		if phase == Phase.COUNT and time_left <= 0.0:
			rpc("net_go")
		elif phase == Phase.PLAY and time_left <= 0.0:
			rpc("net_end", false)

func update_visibility() -> void:
	var space := get_world_3d().direct_space_state
	for id in players:
		var p: Player = players[id]
		if p == local:
			continue
		if local.is_seeker and not p.caught:
			var vis := false
			if local.global_position.distance_to(p.global_position) < VIS_DIST:
				var q := PhysicsRayQueryParameters3D.create(local.global_position + Vector3(0, 1, 0), p.global_position + Vector3(0, 1, 0), 1)
				vis = space.intersect_ray(q).is_empty()
			p.visible = vis
		else:
			p.visible = true

func update_hud() -> void:
	var secs := int(ceil(time_left))
	if phase == Phase.COUNT:
		top_lbl.text = "العدّ: %d" % secs
		overlay_lbl.text = "غمّض عينيك!\nالعفريت يعدّ.. %d" % secs
	else:
		var role := "أنت العفريت" if local.is_seeker else "أنت من أولاد الحارة"
		if local.caught:
			role = "تم القبض عليك"
		top_lbl.text = "%s — حتى الفجر: %d ثانية" % [role, secs]
	catch_btn.visible = local.is_seeker and phase == Phase.PLAY
