extends Node3D
# ليلة الفانوس — رعب واستغماية بالمنظور الأول عبر نقطة الاتصال (بدون إنترنت)

const PlayerS := preload("res://player.gd")
const GfxS := preload("res://gfx.gd")
const MapS := preload("res://maps.gd")

const PORT := 9797
const MAX_CLIENTS := 3
const HIDE_TIME := 15.0
const ROUND_TIME := 180.0
const CATCH_DIST := 3.6
const SPOT_REACH := 3.2
const WALK := 3.8
const SPRINT := 6.4
const MONSTER_SPEED := 5.3
const HIDE_MAX := 12.0
const HIDE_COOLDOWN := 8.0
const IDLE_BEFORE_VOICE := 15.0
const HERE_EVERY := 3.0
const MAP_NAMES := ["الحارة القديمة", "المدرسة المهجورة", "الغابة المهجورة"]
const QUALITY_NAMES := ["منخفض", "متوسط", "عالي", "إكستريم"]
const STORY := "يقولون إن وحش الظلام يخرج في الليالي بلا قمر، يبحث عن كل من يجرؤ على التجوّل وحيداً.\n\nفي حارة قديمة، ومدرسة مهجورة، وغابة لا ينتهي ظلامها... عليك أن تختبئ.\n\nاختبئ داخل البراميل والخزائن والشجيرات، لكن لا تبقَ ساكناً طويلاً، فصوتك سيفضحك!\n\nصمدوا حتى الفجر، أو ستسمعون الوحش يهمس: I caught you."
const SETTINGS_PATH := "user://settings.cfg"

enum Phase { MENU, LOBBY, COUNT, PLAY, END }

var phase := Phase.MENU
var font: Font
var gfx
var cur_map = null
var cur_map_idx := -1
var pmap := 0
var pnames := {}
var players := {}
var seeker_id := 0
var time_left := 0.0
var local = null
var menu_cam: Camera3D
var env: Environment
var sun: DirectionalLight3D
var actors: Node3D
var snd := {}
var music: AudioStreamPlayer
var ambient: AudioStreamPlayer
var heart: AudioStreamPlayer

# إدخال وحالة اللاعب المحلي
var yaw := 0.0
var pitch := 0.0
var vel := Vector3.ZERO
var stamina := 100.0
var sprint_on := false
var sprint_idx := -1
var stick_idx := -1
var stick_origin := Vector2.ZERO
var stick_vec := Vector2.ZERO
var look_idx := -1
var last_sent := 0.0
var idle_t := 0.0
var here_t := 0.0
var hide_left := 0.0
var hide_cd := 0.0
var occupied := {}
var orbit_t := 0.0
var banner_id := 0
var flicker_t := 0.0
var s_hide_left := {}
var s_hide_cd := {}

# إعدادات
var set_quality := 1
var set_ui_scale := 1.0
var set_stick_left := true
var set_sens := 1.0
var set_vol := 1.0
var settings_open := false

# واجهة
var theme_main: Theme
var root: Control
var panels := {}
var name_edit: LineEdit
var ip_edit: LineEdit
var status_lbl: Label
var lobby_ip: Label
var lobby_list: Label
var lobby_start: Button
var lobby_wait: Label
var map_btns := []
var end_lbl: Label
var end_btn: Button
var end_wait: Label
var hud: Control
var top_lbl: Label
var stam_bar: ProgressBar
var act_btn: Button
var sprint_btn: Button
var gear_btn: Button
var banner_lbl: Label
var hint_lbl: Label
var cross: ColorRect
var overlay: ColorRect
var overlay_lbl: Label
var red_flash: ColorRect
var hide_veil: ColorRect
var stick
var settings_wrap: Control
var title_lbl: Label
var set_ui_nodes := {}

class Stick extends Control:
	var origin := Vector2.ZERO
	var knob := Vector2.ZERO
	var active := false
	var radius := 90.0
	func _draw() -> void:
		if not active:
			return
		draw_circle(origin, radius, Color(1, 1, 1, 0.10))
		draw_arc(origin, radius, 0.0, TAU, 40, Color(1, 1, 1, 0.35), 3.0)
		draw_circle(origin + knob, radius * 0.42, Color(1, 0.85, 0.5, 0.55))

# ───────────────────────── البداية ─────────────────────────
func _ready() -> void:
	Engine.max_fps = 60
	DisplayServer.screen_set_keep_on(true)
	font = load("res://fonts/Cairo_700Bold.ttf")
	gfx = GfxS.new()
	load_settings()
	load_sounds()
	build_environment()
	build_ui()
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_conn_failed)
	multiplayer.server_disconnected.connect(_on_server_lost)
	get_viewport().size_changed.connect(layout_hud)
	load_map(0)
	apply_volume()
	go_menu()

func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		set_quality = int(cf.get_value("s", "quality", 1))
		set_ui_scale = float(cf.get_value("s", "ui", 1.0))
		set_stick_left = bool(cf.get_value("s", "stick_left", true))
		set_sens = float(cf.get_value("s", "sens", 1.0))
		set_vol = float(cf.get_value("s", "vol", 1.0))

func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("s", "quality", set_quality)
	cf.set_value("s", "ui", set_ui_scale)
	cf.set_value("s", "stick_left", set_stick_left)
	cf.set_value("s", "sens", set_sens)
	cf.set_value("s", "vol", set_vol)
	cf.save(SETTINGS_PATH)

func load_sounds() -> void:
	for n in ["step", "heart", "wind", "menu", "click", "sting", "growl", "voice_caught", "voice_here"]:
		snd[n] = load("res://audio/%s.wav" % n)
	for n2 in ["heart", "wind", "menu"]:
		var s: AudioStreamWAV = (snd[n2] as AudioStreamWAV).duplicate()
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = s.data.size() / 2
		snd[n2] = s

func build_environment() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.fog_enabled = true
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, 35, 0)
	add_child(sun)
	actors = Node3D.new()
	add_child(actors)
	menu_cam = Camera3D.new()
	menu_cam.fov = 65
	menu_cam.far = 200
	add_child(menu_cam)
	menu_cam.position = Vector3(0, 22, 55)
	menu_cam.current = true
	music = AudioStreamPlayer.new()
	music.stream = snd["menu"]
	music.volume_db = -8.0
	add_child(music)
	ambient = AudioStreamPlayer.new()
	ambient.volume_db = -9.0
	add_child(ambient)
	heart = AudioStreamPlayer.new()
	heart.stream = snd["heart"]
	heart.volume_db = -80.0
	add_child(heart)

func load_map(idx: int) -> void:
	if cur_map != null and cur_map_idx == idx:
		return
	if cur_map != null:
		var old: Node3D = cur_map.root
		remove_child(old)
		old.queue_free()
	cur_map = MapS.new()
	cur_map.build(idx, self, gfx)
	cur_map_idx = idx
	var e: Dictionary = cur_map.env
	env.background_color = e["bg"]
	env.fog_light_color = e["fog"]
	env.fog_density = e["fog_d"]
	env.ambient_light_color = e["amb"]
	env.ambient_light_energy = e["amb_e"]
	sun.light_energy = e["sun_e"]
	sun.light_color = e["sun_c"]
	apply_quality()

func apply_quality() -> void:
	var q := clampi(set_quality, 0, 3)
	var vp := get_viewport()
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
	vp.scaling_3d_scale = [0.6, 0.8, 1.0, 1.0][q]
	vp.msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X][q]
	sun.shadow_enabled = q >= 2 and sun.light_energy > 0.0
	sun.directional_shadow_max_distance = 70.0
	RenderingServer.directional_shadow_atlas_set_size(4096 if q >= 3 else 2048, true)
	vp.positional_shadow_atlas_size = 4096 if q >= 3 else 2048
	env.glow_enabled = q >= 3
	if cur_map != null:
		for l in cur_map.lamps:
			l.visible = q >= 1
	if local != null and local.flash != null:
		local.flash.shadow_enabled = q >= 3
	if local != null and local.cam != null:
		local.cam.far = [45.0, 70.0, 100.0, 130.0][q]

func apply_volume() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(set_vol, 0.001)))

func play_ui(n: String, db: float = 0.0) -> void:
	var p := AudioStreamPlayer.new()
	p.stream = snd[n]
	p.volume_db = db
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()

# ───────────────────────── الواجهة ─────────────────────────
func sbox(bg: Color, border: Color, radius: int = 16, bw: int = 2, margin: float = 16.0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.content_margin_left = margin
	s.content_margin_right = margin
	s.content_margin_top = margin * 0.6
	s.content_margin_bottom = margin * 0.6
	return s

func make_theme() -> Theme:
	var th := Theme.new()
	th.default_font = font
	th.default_font_size = 30
	var amber := Color(1, 0.72, 0.3, 0.75)
	th.set_stylebox("normal", "Button", sbox(Color(0.2, 0.11, 0.05, 0.95), amber))
	th.set_stylebox("hover", "Button", sbox(Color(0.32, 0.18, 0.07, 0.98), Color(1, 0.85, 0.45, 1)))
	th.set_stylebox("pressed", "Button", sbox(Color(0.5, 0.28, 0.08, 1), Color(1, 0.92, 0.55, 1), 16, 3))
	th.set_stylebox("disabled", "Button", sbox(Color(0.12, 0.12, 0.12, 0.8), Color(0.4, 0.4, 0.4, 0.5)))
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_color("font_color", "Button", Color(1, 0.93, 0.78))
	th.set_color("font_pressed_color", "Button", Color(1, 1, 0.9))
	th.set_color("font_hover_color", "Button", Color(1, 1, 0.9))
	th.set_color("font_disabled_color", "Button", Color(0.6, 0.6, 0.6))
	th.set_stylebox("normal", "LineEdit", sbox(Color(0.05, 0.05, 0.08, 0.95), Color(0.9, 0.7, 0.4, 0.5), 14, 2, 12))
	th.set_stylebox("focus", "LineEdit", sbox(Color(0.07, 0.07, 0.1, 1), Color(1, 0.8, 0.4, 1), 14, 2, 12))
	th.set_color("font_color", "LineEdit", Color.WHITE)
	th.set_color("font_placeholder_color", "LineEdit", Color(0.6, 0.6, 0.65))
	th.set_color("caret_color", "LineEdit", Color(1, 0.8, 0.4))
	th.set_stylebox("panel", "PanelContainer", sbox(Color(0.04, 0.05, 0.09, 0.84), Color(1, 0.72, 0.3, 0.4), 28, 2, 30))
	var track := sbox(Color(0.25, 0.2, 0.15, 0.9), Color(0, 0, 0, 0), 8, 0, 0)
	track.content_margin_top = 5
	track.content_margin_bottom = 5
	th.set_stylebox("slider", "HSlider", track)
	th.set_stylebox("grabber_area", "HSlider", sbox(Color(1, 0.72, 0.3, 0.95), Color(0, 0, 0, 0), 8, 0, 0))
	th.set_stylebox("grabber_area_highlight", "HSlider", sbox(Color(1, 0.8, 0.4, 1), Color(0, 0, 0, 0), 8, 0, 0))
	var gi := Image.create(44, 44, false, Image.FORMAT_RGBA8)
	for y in 44:
		for x in 44:
			var d := Vector2(x - 21.5, y - 21.5).length()
			if d < 20.0:
				gi.set_pixel(x, y, Color(1, 0.88, 0.55, 1) if d < 17.0 else Color(0.5, 0.3, 0.1, 1))
	var gt := ImageTexture.create_from_image(gi)
	th.set_icon("grabber", "HSlider", gt)
	th.set_icon("grabber_highlight", "HSlider", gt)
	th.set_icon("grabber_disabled", "HSlider", gt)
	var pb_bg := sbox(Color(0, 0, 0, 0.5), Color(1, 1, 1, 0.3), 8, 1, 0)
	var pb_fg := sbox(Color(0.4, 0.9, 0.5, 0.95), Color(0, 0, 0, 0), 8, 0, 0)
	th.set_stylebox("background", "ProgressBar", pb_bg)
	th.set_stylebox("fill", "ProgressBar", pb_fg)
	return th

func lbl(t: String, sz: int = 30, col: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", sz)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

func btn(t: String, cb: Callable, h: float = 64.0) -> Button:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(0, h)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(cb)
	b.pressed.connect(play_ui.bind("click", -6.0))
	return b

func make_wrap(key: String, dim_alpha: float = 0.4) -> Control:
	var wrap := Control.new()
	wrap.set_anchors_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, dim_alpha)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	wrap.add_child(dim)
	root.add_child(wrap)
	panels[key] = wrap
	return wrap

func make_card(key: String, width: float) -> VBoxContainer:
	var wrap := make_wrap(key)
	var c := CenterContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	wrap.add_child(c)
	var pc := PanelContainer.new()
	c.add_child(pc)
	var v := VBoxContainer.new()
	v.custom_minimum_size = Vector2(width, 0)
	v.add_theme_constant_override("separation", 12)
	pc.add_child(v)
	return v

func show_panel(key: String) -> void:
	for k in panels:
		panels[k].visible = (k == key)
	hud.visible = false
	overlay.visible = false
	red_flash.modulate.a = 0.0

func build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.layout_direction = Control.LAYOUT_DIRECTION_RTL
	theme_main = make_theme()
	root.theme = theme_main
	layer.add_child(root)
	build_hud()
	build_menu()
	build_story()
	build_lobby()
	build_end()
	build_settings()

func build_hud() -> void:
	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud)
	hide_veil = ColorRect.new()
	hide_veil.color = Color(0, 0, 0, 0.45)
	hide_veil.set_anchors_preset(Control.PRESET_FULL_RECT)
	hide_veil.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hide_veil.visible = false
	hud.add_child(hide_veil)
	stick = Stick.new()
	stick.set_anchors_preset(Control.PRESET_FULL_RECT)
	stick.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(stick)
	top_lbl = lbl("", 32, Color(1, 0.9, 0.6))
	top_lbl.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top_lbl.offset_top = 12
	top_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	top_lbl.add_theme_constant_override("outline_size", 8)
	hud.add_child(top_lbl)
	stam_bar = ProgressBar.new()
	stam_bar.show_percentage = false
	stam_bar.max_value = 100.0
	stam_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(stam_bar)
	act_btn = Button.new()
	act_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(act_btn)
	sprint_btn = Button.new()
	sprint_btn.text = "ركض"
	sprint_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(sprint_btn)
	gear_btn = Button.new()
	gear_btn.text = "⚙"
	gear_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(gear_btn)
	cross = ColorRect.new()
	cross.color = Color(1, 1, 1, 0.55)
	cross.custom_minimum_size = Vector2(5, 5)
	cross.size = Vector2(5, 5)
	cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(cross)
	banner_lbl = lbl("", 40, Color.WHITE)
	banner_lbl.custom_minimum_size = Vector2(900, 0)
	banner_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	banner_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	banner_lbl.add_theme_constant_override("outline_size", 12)
	banner_lbl.visible = false
	hud.add_child(banner_lbl)
	hint_lbl = lbl("", 30, Color(1, 0.5, 0.4))
	hint_lbl.custom_minimum_size = Vector2(900, 0)
	hint_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hint_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	hint_lbl.add_theme_constant_override("outline_size", 8)
	hud.add_child(hint_lbl)
	red_flash = ColorRect.new()
	red_flash.color = Color(0.8, 0, 0, 0.55)
	red_flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	red_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	red_flash.modulate.a = 0.0
	root.add_child(red_flash)
	overlay = ColorRect.new()
	overlay.color = Color.BLACK
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(overlay)
	overlay_lbl = lbl("", 46, Color(1, 0.8, 0.45))
	overlay_lbl.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	overlay_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(overlay_lbl)

func layout_hud() -> void:
	if hud == null:
		return
	var s := set_ui_scale
	var vs := get_viewport().get_visible_rect().size
	var m := 34.0 * s
	var bw := 250.0 * s
	var bh := 118.0 * s
	var on_right := set_stick_left
	var ax := (vs.x - m - bw) if on_right else m
	var ay := vs.y - m - bh
	act_btn.size = Vector2(bw, bh)
	act_btn.position = Vector2(ax, ay)
	act_btn.add_theme_font_size_override("font_size", int(36.0 * s))
	var sp := 112.0 * s
	sprint_btn.size = Vector2(sp, sp)
	sprint_btn.position = Vector2(ax + (bw - sp) * 0.5, ay - sp - 16.0 * s)
	sprint_btn.add_theme_font_size_override("font_size", int(28.0 * s))
	var gs := 68.0 * s
	gear_btn.size = Vector2(gs, gs)
	gear_btn.position = Vector2(m * 0.5, m * 0.5)
	gear_btn.add_theme_font_size_override("font_size", int(34.0 * s))
	stam_bar.size = Vector2(320.0 * s, 14.0 * s)
	stam_bar.position = Vector2((vs.x - 320.0 * s) * 0.5, 62.0 * s)
	cross.position = vs * 0.5 - Vector2(2.5, 2.5)
	banner_lbl.position = Vector2((vs.x - 900.0) * 0.5, vs.y * 0.2)
	banner_lbl.size = Vector2(900, 80)
	hint_lbl.position = Vector2((vs.x - 900.0) * 0.5, vs.y * 0.66)
	hint_lbl.size = Vector2(900, 60)
	stick.radius = 90.0 * s

func build_menu() -> void:
	var wrap := make_wrap("menu", 0.3)
	var c := CenterContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	wrap.add_child(c)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 70)
	c.add_child(hb)
	var tv := VBoxContainer.new()
	tv.custom_minimum_size = Vector2(560, 0)
	tv.add_theme_constant_override("separation", 6)
	hb.add_child(tv)
	title_lbl = lbl("ليلة الفانوس", 92, Color(1, 0.78, 0.35))
	title_lbl.add_theme_color_override("font_outline_color", Color(0.25, 0.08, 0.0))
	title_lbl.add_theme_constant_override("outline_size", 14)
	tv.add_child(title_lbl)
	tv.add_child(lbl("رعب واستغماية بالمنظور الأول", 34, Color(0.9, 0.92, 1)))
	tv.add_child(lbl("العب مع أصدقائك عبر نقطة الاتصال — بدون إنترنت", 24, Color(0.75, 0.8, 0.9)))
	var tw := create_tween().set_loops()
	tw.tween_property(title_lbl, "modulate", Color(1, 0.85, 0.7, 0.8), 1.4)
	tw.tween_property(title_lbl, "modulate", Color(1, 1, 1, 1), 1.4)
	var pc := PanelContainer.new()
	hb.add_child(pc)
	var v := VBoxContainer.new()
	v.custom_minimum_size = Vector2(500, 0)
	v.add_theme_constant_override("separation", 10)
	pc.add_child(v)
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "اسمك"
	name_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_edit.max_length = 12
	name_edit.custom_minimum_size = Vector2(0, 60)
	v.add_child(name_edit)
	v.add_child(btn("إنشاء غرفة (أنا المضيف)", host_game))
	ip_edit = LineEdit.new()
	ip_edit.text = "192.168.43.1"
	ip_edit.placeholder_text = "عنوان المضيف"
	ip_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	ip_edit.custom_minimum_size = Vector2(0, 60)
	ip_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_URL
	v.add_child(ip_edit)
	v.add_child(btn("انضمام لغرفة", join_game))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var b1 := btn("القصة", func(): show_panel("story"))
	b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var b2 := btn("الإعدادات", open_settings)
	b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(b1)
	row.add_child(b2)
	v.add_child(row)
	status_lbl = lbl("شغّل نقطة الاتصال (Hotspot) على جهاز واحد وباقي الأصدقاء يتصلون بها", 22, Color(0.8, 0.8, 0.9))
	v.add_child(status_lbl)

func build_story() -> void:
	var s := make_card("story", 900.0)
	s.add_child(lbl("القصة", 56, Color(1, 0.78, 0.35)))
	s.add_child(lbl(STORY, 30))
	s.add_child(btn("رجوع", func(): show_panel("menu")))

func build_lobby() -> void:
	var r := make_card("lobby", 720.0)
	r.add_child(lbl("غرفة اللعب", 56, Color(1, 0.78, 0.35)))
	lobby_ip = lbl("", 26, Color(0.7, 1, 0.8))
	r.add_child(lobby_ip)
	r.add_child(lbl("الخريطة", 28, Color(0.9, 0.85, 0.7)))
	var mrow := HBoxContainer.new()
	mrow.add_theme_constant_override("separation", 8)
	var grp := ButtonGroup.new()
	for i in 3:
		var b := Button.new()
		b.text = MAP_NAMES[i]
		b.toggle_mode = true
		b.button_group = grp
		b.custom_minimum_size = Vector2(0, 64)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 26)
		b.pressed.connect(_on_map_pick.bind(i))
		b.pressed.connect(play_ui.bind("click", -6.0))
		mrow.add_child(b)
		map_btns.append(b)
	r.add_child(mrow)
	lobby_list = lbl("", 34)
	r.add_child(lobby_list)
	lobby_start = btn("ابدأ اللعبة", _on_start_pressed)
	r.add_child(lobby_start)
	lobby_wait = lbl("في انتظار المضيف ليبدأ اللعبة...", 28, Color(0.85, 0.9, 1))
	r.add_child(lobby_wait)
	r.add_child(btn("خروج", leave_to_menu))

func build_end() -> void:
	var e := make_card("end", 760.0)
	end_lbl = lbl("", 60, Color(1, 0.85, 0.4))
	e.add_child(end_lbl)
	end_btn = btn("جولة جديدة", _on_new_round)
	e.add_child(end_btn)
	end_wait = lbl("في انتظار المضيف...", 28, Color(0.85, 0.9, 1))
	e.add_child(end_wait)

func add_slider(parent: Control, title: String, key: String, mn: float, mx: float, step: float, val: float) -> void:
	var row := VBoxContainer.new()
	var l := lbl(title, 26, Color(0.95, 0.9, 0.8))
	row.add_child(l)
	var sl := HSlider.new()
	sl.min_value = mn
	sl.max_value = mx
	sl.step = step
	sl.value = val
	sl.custom_minimum_size = Vector2(0, 48)
	sl.value_changed.connect(_on_slider.bind(key))
	row.add_child(sl)
	parent.add_child(row)
	set_ui_nodes[key] = sl

func build_settings() -> void:
	settings_wrap = Control.new()
	settings_wrap.set_anchors_preset(Control.PRESET_FULL_RECT)
	settings_wrap.visible = false
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	settings_wrap.add_child(dim)
	var c := CenterContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	settings_wrap.add_child(c)
	var pc := PanelContainer.new()
	c.add_child(pc)
	var v := VBoxContainer.new()
	v.custom_minimum_size = Vector2(820, 0)
	v.add_theme_constant_override("separation", 8)
	pc.add_child(v)
	v.add_child(lbl("الإعدادات", 48, Color(1, 0.78, 0.35)))
	v.add_child(lbl("جودة الجرافيك", 26, Color(0.95, 0.9, 0.8)))
	var qrow := HBoxContainer.new()
	qrow.add_theme_constant_override("separation", 8)
	var qgrp := ButtonGroup.new()
	for i in 4:
		var b := Button.new()
		b.text = QUALITY_NAMES[i]
		b.toggle_mode = true
		b.button_group = qgrp
		b.button_pressed = (i == set_quality)
		b.custom_minimum_size = Vector2(0, 58)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 26)
		b.pressed.connect(_on_quality.bind(i))
		qrow.add_child(b)
	v.add_child(qrow)
	v.add_child(lbl("مكان عصا الحركة", 26, Color(0.95, 0.9, 0.8)))
	var srow := HBoxContainer.new()
	srow.add_theme_constant_override("separation", 8)
	var sgrp := ButtonGroup.new()
	for i in 2:
		var b2 := Button.new()
		b2.text = "يسار" if i == 0 else "يمين"
		b2.toggle_mode = true
		b2.button_group = sgrp
		b2.button_pressed = ((i == 0) == set_stick_left)
		b2.custom_minimum_size = Vector2(0, 58)
		b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b2.add_theme_font_size_override("font_size", 26)
		b2.pressed.connect(_on_stick_side.bind(i == 0))
		srow.add_child(b2)
	v.add_child(srow)
	add_slider(v, "حجم أزرار التحكم", "ui", 0.7, 1.5, 0.05, set_ui_scale)
	add_slider(v, "حساسية الكاميرا", "sens", 0.4, 2.5, 0.05, set_sens)
	add_slider(v, "مستوى الصوت", "vol", 0.0, 1.0, 0.05, set_vol)
	v.add_child(btn("حفظ وإغلاق", close_settings))
	root.add_child(settings_wrap)

func open_settings() -> void:
	settings_open = true
	settings_wrap.visible = true

func close_settings() -> void:
	settings_open = false
	settings_wrap.visible = false
	save_settings()
	layout_hud()

func _on_quality(i: int) -> void:
	set_quality = i
	apply_quality()
	play_ui("click", -6.0)

func _on_stick_side(left: bool) -> void:
	set_stick_left = left
	layout_hud()
	play_ui("click", -6.0)

func _on_slider(v: float, key: String) -> void:
	match key:
		"ui":
			set_ui_scale = v
			layout_hud()
		"sens":
			set_sens = v
		"vol":
			set_vol = v
			apply_volume()

func banner(t: String, secs: float = 4.0, col: Color = Color.WHITE, sz: int = 40) -> void:
	banner_id += 1
	var my := banner_id
	banner_lbl.text = t
	banner_lbl.add_theme_color_override("font_color", col)
	banner_lbl.add_theme_font_size_override("font_size", sz)
	banner_lbl.visible = true
	await get_tree().create_timer(secs).timeout
	if my == banner_id:
		banner_lbl.visible = false

func my_name() -> String:
	var n := name_edit.text.strip_edges()
	if n == "":
		n = "لاعب"
	return n

func local_ips() -> String:
	var out := []
	for a in IP.get_local_addresses():
		if a.count(".") == 3 and not a.begins_with("127.") and not a.begins_with("169.254"):
			out.append(a)
	return " — ".join(out)

func go_menu() -> void:
	phase = Phase.MENU
	menu_cam.current = true
	ambient.stop()
	heart.stop()
	if not music.playing:
		music.play()
	show_panel("menu")

# ───────────────────────── الشبكة ─────────────────────────
func host_game() -> void:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_CLIENTS)
	if err != OK:
		status_lbl.text = "تعذّر إنشاء الغرفة، جرّب مرة أخرى"
		return
	multiplayer.multiplayer_peer = peer
	pnames = {1: my_name()}
	phase = Phase.LOBBY
	refresh_lobby()
	show_panel("lobby")

func join_game() -> void:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip_edit.text.strip_edges(), PORT)
	if err != OK:
		status_lbl.text = "عنوان غير صحيح"
		return
	multiplayer.multiplayer_peer = peer
	status_lbl.text = "جاري الاتصال..."

func _on_connected() -> void:
	rpc_id(1, "net_register", my_name())

func _on_conn_failed() -> void:
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	status_lbl.text = "فشل الاتصال — تأكد أنك متصل بنقطة اتصال المضيف وأن العنوان صحيح"

func _on_server_lost() -> void:
	leave_to_menu()
	status_lbl.text = "انقطع الاتصال بالمضيف"

func leave_to_menu() -> void:
	clear_players()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	pnames = {}
	go_menu()

func _on_peer_disconnected(id: int) -> void:
	if not multiplayer.is_server():
		return
	pnames.erase(id)
	if players.has(id):
		var p = players[id]
		if p.hidden:
			occupied.erase(p.hide_spot)
		p.queue_free()
		players.erase(id)
	rpc("net_lobby", pnames, pmap)
	if phase == Phase.COUNT or phase == Phase.PLAY:
		if id == seeker_id or players.size() < 2:
			rpc("net_end", false)
		else:
			check_end()

@rpc("any_peer", "reliable")
func net_register(nm: String) -> void:
	var id := multiplayer.get_remote_sender_id()
	if phase != Phase.LOBBY:
		multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	pnames[id] = nm
	rpc("net_lobby", pnames, pmap)

@rpc("authority", "call_local", "reliable")
func net_lobby(d: Dictionary, mp: int) -> void:
	pnames = d
	pmap = mp
	if phase == Phase.MENU or phase == Phase.LOBBY:
		phase = Phase.LOBBY
		refresh_lobby()
		show_panel("lobby")

func refresh_lobby() -> void:
	var lines := []
	for id in pnames:
		lines.append("• " + str(pnames[id]))
	lobby_list.text = "\n".join(lines)
	var is_host := multiplayer.is_server()
	lobby_ip.text = ("عنوان غرفتك: " + local_ips()) if is_host else "تم الاتصال بالغرفة"
	lobby_start.visible = is_host
	lobby_wait.visible = not is_host
	lobby_start.disabled = pnames.size() < 2
	for i in map_btns.size():
		map_btns[i].button_pressed = (i == pmap)
		map_btns[i].disabled = not is_host and i != pmap

func _on_map_pick(i: int) -> void:
	if multiplayer.is_server() and phase == Phase.LOBBY:
		pmap = i
		rpc("net_lobby", pnames, pmap)
		load_map(i)

func _on_start_pressed() -> void:
	if not multiplayer.is_server() or pnames.size() < 2:
		return
	var ids := pnames.keys()
	var sk: int = ids.pick_random()
	var pts: Array = cur_map_spawns(pmap)
	pts.shuffle()
	var spawns := {}
	for i in ids.size():
		spawns[ids[i]] = pts[i]
	rpc("net_begin", sk, spawns, pmap)

func cur_map_spawns(idx: int) -> Array:
	load_map(idx)
	return cur_map.spawns.duplicate()

@rpc("authority", "call_local", "reliable")
func net_begin(sk: int, spawns: Dictionary, map_idx: int) -> void:
	pmap = map_idx
	load_map(map_idx)
	clear_players()
	occupied.clear()
	s_hide_left.clear()
	s_hide_cd.clear()
	seeker_id = sk
	var i := 0
	for id in pnames:
		var p = PlayerS.new()
		p.setup(id, str(pnames[id]), i, id == sk, snd, font)
		i += 1
		actors.add_child(p)
		p.global_position = spawns[id]
		p.target_pos = spawns[id]
		players[id] = p
	var me := multiplayer.get_unique_id()
	local = players[me]
	local.make_local()
	var sp: Vector3 = spawns[me]
	yaw = atan2(sp.x, sp.z)
	pitch = 0.0
	local.rotation.y = yaw
	vel = Vector3.ZERO
	stamina = 100.0
	sprint_on = false
	sprint_idx = -1
	stick_idx = -1
	look_idx = -1
	stick_vec = Vector2.ZERO
	stick.active = false
	hide_left = 0.0
	hide_cd = 0.0
	idle_t = 0.0
	here_t = 0.0
	phase = Phase.COUNT
	time_left = HIDE_TIME
	for k in panels:
		panels[k].visible = false
	hud.visible = true
	overlay.visible = local.is_seeker
	music.stop()
	ambient.stream = snd["wind"]
	ambient.pitch_scale = float(cur_map.env["wind"])
	ambient.play()
	heart.play()
	heart.volume_db = -80.0
	layout_hud()
	apply_quality()
	var sname := str(pnames[sk])
	if local.is_seeker:
		banner("أنت الوحش! غمّض عينيك حتى ينتهي العدّ", 5.0, Color(1, 0.4, 0.3))
	else:
		banner("%s — الوحش %s يعدّ الآن.. اختبئ!" % [MAP_NAMES[map_idx], sname], 5.0)

@rpc("authority", "call_local", "reliable")
func net_go() -> void:
	phase = Phase.PLAY
	time_left = ROUND_TIME
	overlay.visible = false
	play_ui("growl", -2.0)
	if local.is_seeker:
		banner("انطلق! ابحث عنهم وامسكهم", 4.0, Color(1, 0.4, 0.3))
	else:
		banner("الوحش انطلق! اختبئ أو اهرب", 4.0, Color(1, 0.6, 0.4))

@rpc("any_peer", "unreliable")
func net_pos(pos: Vector3, yw: float, pt: float) -> void:
	var id := multiplayer.get_remote_sender_id()
	if players.has(id):
		var p = players[id]
		p.target_pos = pos
		p.target_yaw = yw
		p.target_pitch = pt

@rpc("any_peer", "reliable")
func net_here() -> void:
	var id := multiplayer.get_remote_sender_id()
	if players.has(id) and not players[id].is_local:
		players[id].say("voice_here", 8.0)

# ── المسك
@rpc("any_peer", "reliable")
func net_req_catch() -> void:
	do_catch(multiplayer.get_remote_sender_id())

func do_catch(sender: int) -> void:
	if phase != Phase.PLAY or sender != seeker_id or not players.has(sender):
		return
	var m = players[sender]
	var fwd: Vector3 = -m.global_transform.basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	var best := 0
	var bd := CATCH_DIST
	for id in players:
		var p = players[id]
		if id == seeker_id or p.caught or p.hidden:
			continue
		var d: Vector3 = p.global_position - m.global_position
		var dist := d.length()
		if dist < bd and (dist < 1.2 or fwd.dot(d.normalized()) > 0.1):
			bd = dist
			best = id
	if best == 0 and cur_map != null:
		var bs := -1
		var bsd := CATCH_DIST
		for si in cur_map.spots.size():
			if not occupied.has(si):
				continue
			var d2: Vector3 = cur_map.spots[si]["pos"] - m.global_position
			d2.y = 0.0
			var dist2 := d2.length()
			if dist2 < bsd and (dist2 < 1.5 or fwd.dot(d2.normalized()) > 0.1):
				bsd = dist2
				bs = si
		if bs >= 0:
			best = occupied[bs]
			rpc("net_unhide", best)
	if best != 0:
		rpc("net_caught", best)
		check_end()

@rpc("authority", "call_local", "reliable")
func net_caught(id: int) -> void:
	if not players.has(id):
		return
	var p = players[id]
	p.set_caught()
	if players.has(seeker_id):
		players[seeker_id].say("voice_caught", 12.0)
	play_ui("sting", -4.0)
	if p.is_local:
		Input.vibrate_handheld(450)
		banner("I CAUGHT YOU", 4.0, Color(1, 0.1, 0.1), 84)
		var tw := create_tween()
		red_flash.modulate.a = 1.0
		tw.tween_property(red_flash, "modulate:a", 0.0, 1.4)
		hide_veil.visible = false
		heart.volume_db = -80.0
	else:
		banner("الوحش مسك %s" % str(pnames.get(id, "")), 3.0, Color(1, 0.6, 0.5))

func check_end() -> void:
	for id in players:
		if id != seeker_id and not players[id].caught:
			return
	rpc("net_end", true)

# ── الاختباء
@rpc("any_peer", "reliable")
func net_req_hide(si: int) -> void:
	do_hide_req(multiplayer.get_remote_sender_id(), si)

@rpc("any_peer", "reliable")
func net_req_unhide() -> void:
	var id := multiplayer.get_remote_sender_id()
	if players.has(id) and players[id].hidden:
		rpc("net_unhide", id)

func do_hide_req(id: int, si: int) -> void:
	if phase != Phase.COUNT and phase != Phase.PLAY:
		return
	if id == seeker_id or not players.has(id) or cur_map == null:
		return
	var p = players[id]
	if p.caught or p.hidden:
		return
	if si < 0 or si >= cur_map.spots.size() or occupied.has(si):
		return
	if float(s_hide_cd.get(id, 0.0)) > 0.0:
		return
	var spos: Vector3 = cur_map.spots[si]["pos"]
	var pp: Vector3 = p.global_position
	if Vector2(pp.x - spos.x, pp.z - spos.z).length() > SPOT_REACH + 1.0:
		return
	s_hide_left[id] = HIDE_MAX
	rpc("net_hide", id, si, pp)

@rpc("authority", "call_local", "reliable")
func net_hide(id: int, si: int, ret: Vector3) -> void:
	if not players.has(id):
		return
	var p = players[id]
	p.hidden = true
	p.hide_spot = si
	p.ret_pos = ret
	occupied[si] = id
	var spos: Vector3 = cur_map.spots[si]["pos"]
	p.global_position = spos
	p.target_pos = spos
	if p.is_local:
		hide_left = HIDE_MAX
		vel = Vector3.ZERO
		hide_veil.visible = true
		idle_t = 0.0
	else:
		p.visible = false

@rpc("authority", "call_local", "reliable")
func net_unhide(id: int) -> void:
	if not players.has(id):
		return
	var p = players[id]
	if not p.hidden:
		return
	occupied.erase(p.hide_spot)
	p.hidden = false
	p.global_position = p.ret_pos
	p.target_pos = p.ret_pos
	if p.is_local:
		hide_cd = HIDE_COOLDOWN
		hide_veil.visible = false
	else:
		p.visible = true
	if multiplayer.is_server():
		s_hide_left.erase(id)
		s_hide_cd[id] = HIDE_COOLDOWN

@rpc("authority", "call_local", "reliable")
func net_end(seeker_won: bool) -> void:
	phase = Phase.END
	overlay.visible = false
	stick_idx = -1
	stick_vec = Vector2.ZERO
	stick.active = false
	heart.volume_db = -80.0
	var sname := str(pnames.get(seeker_id, "الوحش"))
	if seeker_won:
		end_lbl.text = "فاز الوحش %s!\nأُطفئ الفانوس" % sname
	else:
		end_lbl.text = "طلع الفجر!\nنجا أولاد الحارة"
	var is_host := multiplayer.is_server()
	end_btn.visible = is_host
	end_wait.visible = not is_host
	menu_cam.current = true
	show_panel("end")

func _on_new_round() -> void:
	if multiplayer.is_server():
		rpc("net_to_lobby")

@rpc("authority", "call_local", "reliable")
func net_to_lobby() -> void:
	clear_players()
	phase = Phase.LOBBY
	ambient.stop()
	heart.stop()
	music.play()
	refresh_lobby()
	show_panel("lobby")

func clear_players() -> void:
	for id in players:
		if is_instance_valid(players[id]):
			players[id].queue_free()
	players.clear()
	local = null
	menu_cam.current = true

# ───────────────────────── الإدخال ─────────────────────────
func hud_rect(c: Control) -> Rect2:
	return c.get_global_rect().grow(14.0)

func hud_press(idx: int, pos: Vector2) -> bool:
	if gear_btn.visible and hud_rect(gear_btn).has_point(pos):
		open_settings()
		return true
	if act_btn.visible and hud_rect(act_btn).has_point(pos):
		on_act()
		return true
	if sprint_btn.visible and hud_rect(sprint_btn).has_point(pos):
		sprint_idx = idx
		sprint_on = true
		return true
	return false

func _input(event: InputEvent) -> void:
	if settings_open or local == null:
		return
	if phase != Phase.COUNT and phase != Phase.PLAY:
		return
	var vs := get_viewport().get_visible_rect().size
	if event is InputEventScreenTouch:
		var pos: Vector2 = event.position
		if event.pressed:
			if hud_press(event.index, pos):
				return
			var on_left := pos.x < vs.x * 0.5
			if on_left == set_stick_left:
				if stick_idx == -1:
					stick_idx = event.index
					stick_origin = pos
					stick.origin = pos
					stick.knob = Vector2.ZERO
					stick.active = true
					stick.queue_redraw()
			elif look_idx == -1:
				look_idx = event.index
		else:
			if event.index == sprint_idx:
				sprint_idx = -1
				sprint_on = false
			if event.index == stick_idx:
				stick_idx = -1
				stick_vec = Vector2.ZERO
				stick.active = false
				stick.queue_redraw()
			if event.index == look_idx:
				look_idx = -1
	elif event is InputEventScreenDrag:
		if event.index == stick_idx:
			var d: Vector2 = event.position - stick_origin
			stick_vec = (d / stick.radius).limit_length(1.0)
			stick.knob = stick_vec * stick.radius
			stick.queue_redraw()
		elif event.index == look_idx:
			var k := 0.0045 * set_sens
			yaw -= event.relative.x * k
			pitch = clampf(pitch - event.relative.y * k, -1.3, 1.3)

func on_act() -> void:
	if local == null or (phase != Phase.PLAY and phase != Phase.COUNT):
		return
	if local.is_seeker:
		if phase != Phase.PLAY or local.caught:
			return
		if multiplayer.is_server():
			do_catch(1)
		else:
			rpc_id(1, "net_req_catch")
		return
	if local.caught:
		return
	if local.hidden:
		if multiplayer.is_server():
			rpc("net_unhide", multiplayer.get_unique_id())
		else:
			rpc_id(1, "net_req_unhide")
		return
	var si := nearest_free_spot()
	if si < 0 or hide_cd > 0.0:
		return
	if multiplayer.is_server():
		do_hide_req(1, si)
	else:
		rpc_id(1, "net_req_hide", si)

func nearest_free_spot() -> int:
	if cur_map == null or local == null:
		return -1
	var best := -1
	var bd := SPOT_REACH
	var lp: Vector3 = local.global_position
	for si in cur_map.spots.size():
		if occupied.has(si):
			continue
		var sp: Vector3 = cur_map.spots[si]["pos"]
		var d := Vector2(lp.x - sp.x, lp.z - sp.z).length()
		if d < bd:
			bd = d
			best = si
	return best

# ───────────────────────── اللعب ─────────────────────────
func _physics_process(delta: float) -> void:
	if local == null or (phase != Phase.COUNT and phase != Phase.PLAY):
		return
	var dir := stick_vec
	if dir == Vector2.ZERO:
		dir = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var frozen: bool = local.caught or local.hidden or (phase == Phase.COUNT and local.is_seeker)
	var want := Vector3.ZERO
	var moving := false
	if not frozen and dir.length() > 0.05:
		var spd := MONSTER_SPEED
		if not local.is_seeker:
			spd = WALK
			if sprint_on and stamina > 2.0:
				spd = SPRINT
				moving = true
		want = (Basis(Vector3.UP, yaw) * Vector3(dir.x, 0, dir.y)).normalized() * spd * minf(1.0, dir.length() * 1.15)
	vel = vel.move_toward(want, 24.0 * delta)
	local.rotation.y = yaw
	if local.cam != null:
		local.cam.rotation.x = pitch
	if not local.hidden and not local.caught:
		local.velocity = vel
		local.move_and_slide()
		local.global_position.y = 0.0
	if not local.is_seeker:
		if moving and want.length() > WALK + 0.5:
			stamina = maxf(0.0, stamina - 26.0 * delta)
		else:
			stamina = minf(100.0, stamina + 11.0 * delta)
	last_sent += delta
	if last_sent >= 0.05:
		last_sent = 0.0
		rpc("net_pos", local.global_position, yaw, pitch)

func _process(delta: float) -> void:
	flicker_t += delta
	if cur_map != null:
		var i := 0
		for l in cur_map.flickers:
			var f := sin(flicker_t * 13.0 + i * 2.3) * sin(flicker_t * 7.1 + i)
			l.light_energy = float(l.get_meta("base")) * (1.0 if f > -0.55 else 0.12)
			i += 1
	if phase == Phase.MENU or phase == Phase.LOBBY or phase == Phase.END:
		orbit_t += delta * 0.1
		var r := 56.0 if cur_map == null else (float(cur_map.half) + 16.0)
		menu_cam.position = Vector3(sin(orbit_t) * r, 20.0, cos(orbit_t) * r)
		menu_cam.look_at(Vector3(0, 3, 0))
		return
	if local == null:
		return
	if phase != Phase.COUNT and phase != Phase.PLAY:
		return
	time_left = maxf(0.0, time_left - delta)
	hide_cd = maxf(0.0, hide_cd - delta)
	if hide_left > 0.0:
		hide_left = maxf(0.0, hide_left - delta)
	for id in players:
		var p = players[id]
		if p != local and not p.hidden and not p.caught:
			p.global_position = p.global_position.lerp(p.target_pos, minf(1.0, delta * 14.0))
			p.rotation.y = lerp_angle(p.rotation.y, p.target_yaw, minf(1.0, delta * 14.0))
	update_idle(delta)
	update_heart()
	update_hud()
	if multiplayer.is_server():
		server_tick(delta)

func update_idle(delta: float) -> void:
	if phase == Phase.PLAY and not local.is_seeker and not local.caught and not local.hidden:
		if local.speed_est < 0.25:
			idle_t += delta
		else:
			idle_t = 0.0
			here_t = 0.0
		if idle_t >= IDLE_BEFORE_VOICE:
			here_t -= delta
			if here_t <= 0.0:
				here_t = HERE_EVERY
				local.say("voice_here", 4.0)
				rpc("net_here")
	else:
		idle_t = 0.0

func update_heart() -> void:
	if phase != Phase.PLAY or local.is_seeker or local.caught or not players.has(seeker_id):
		heart.volume_db = -80.0
		return
	var d: float = local.global_position.distance_to(players[seeker_id].global_position)
	if d < 22.0:
		var k := d / 22.0
		heart.volume_db = lerpf(-2.0, -28.0, k)
		heart.pitch_scale = lerpf(1.5, 0.9, k)
	else:
		heart.volume_db = -80.0

func server_tick(delta: float) -> void:
	if phase == Phase.COUNT and time_left <= 0.0:
		rpc("net_go")
	elif phase == Phase.PLAY and time_left <= 0.0:
		rpc("net_end", false)
	for id in s_hide_cd.keys():
		s_hide_cd[id] = maxf(0.0, float(s_hide_cd[id]) - delta)
	for id2 in s_hide_left.keys():
		s_hide_left[id2] = float(s_hide_left[id2]) - delta
		if float(s_hide_left[id2]) <= 0.0:
			rpc("net_unhide", id2)

func update_hud() -> void:
	var secs := int(ceil(time_left))
	var is_m: bool = local.is_seeker
	if phase == Phase.COUNT:
		top_lbl.text = "العدّ: %d" % secs
		overlay_lbl.text = "غمّض عينيك!\nالوحش يعدّ.. %d" % secs
	else:
		var role := "أنت الوحش" if is_m else "أنت من أولاد الحارة"
		if local.caught:
			role = "تم القبض عليك"
		top_lbl.text = "%s — حتى الفجر: %d ثانية" % [role, secs]
	stam_bar.visible = not is_m
	stam_bar.value = stamina
	sprint_btn.visible = not is_m and not local.caught and not local.hidden
	sprint_btn.modulate = Color(1, 1, 1, 1.0 if sprint_on else 0.8)
	var act_vis := true
	act_btn.modulate.a = 1.0
	if is_m:
		act_btn.text = "امسكه!"
		act_vis = phase == Phase.PLAY and not local.caught
	elif local.caught:
		act_vis = false
	elif local.hidden:
		act_btn.text = "اخرج (%d)" % int(ceil(hide_left))
	else:
		var si := nearest_free_spot()
		if hide_cd > 0.0:
			act_btn.text = "انتظر %d" % int(ceil(hide_cd))
			act_btn.modulate.a = 0.5
		elif si >= 0:
			act_btn.text = "اختبئ: " + str(cur_map.spots[si]["name"])
		else:
			act_vis = false
	act_btn.visible = act_vis
	hint_lbl.text = ""
	if idle_t >= IDLE_BEFORE_VOICE:
		hint_lbl.text = "أنت ساكن! الوحش يسمع صوتك.. تحرّك!"
	elif local.hidden:
		hint_lbl.text = "مختبئ.. اخرج قبل أن ينتهي الوقت"
