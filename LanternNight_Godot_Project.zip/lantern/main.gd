extends Node3D
# ليلة الفانوس — رعب وهروب بالمنظور الأول (كاميرا قديمة) — فردي أو مع الأصدقاء عبر نقطة الاتصال

const PlayerS := preload("res://player.gd")
const GfxS := preload("res://gfx.gd")
const MapS := preload("res://maps.gd")
const AiS := preload("res://ai.gd")

const PORT := 9797
const MAX_CLIENTS := 3
const HIDE_TIME := 15.0
const ROUND_TIME := 300.0
const PART_COUNT := 5
const SPOT_REACH := 3.2
const WALK := 3.8
const SPRINT := 5.8
const HIDE_MAX := 5.0
const HIDE_COOLDOWN := 8.0
const IDLE_BEFORE_VOICE := 15.0
const HERE_EVERY := 3.0
const MAP_NAMES := ["الحارة القديمة", "المدرسة المهجورة", "الغابة المهجورة"]
const QUALITY_NAMES := ["منخفض", "متوسط", "عالي", "إكستريم"]
const BOT_NAMES := ["سارة", "كريم"]
const STORY := "يقولون إن «سكيري» وحش الظلام يخرج في الليالي بلا قمر، يطارد كل من يجرؤ على التجوّل وحيداً.\n\nمحرك العربية الوحيدة للنجاة تناثرت قطعه في المكان. اجمع القطع الخمس، ثم اهرب بالعربية قبل الفجر.\n\nاختبئ داخل البراميل والخزائن والشجيرات (5 ثوانٍ فقط)، ولا تبقَ ساكناً طويلاً، فصوتك سيفضحك!\n\nوإن سمعت الوحش يهمس: I caught you.. فقد فات الأوان."
const SETTINGS_PATH := "user://settings.cfg"
const AMBER := Color(1, 0.78, 0.35)
const CAMFX_SHADER := "shader_type canvas_item;
float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
void fragment(){
	vec2 uv = UV;
	float d = distance(uv, vec2(0.5));
	float vig = smoothstep(0.38, 0.9, d);
	float grain = hash(floor(uv * vec2(420.0, 240.0)) + vec2(TIME * 31.7, TIME * 13.1));
	float scan = 0.5 + 0.5 * sin(uv.y * 520.0 + TIME * 22.0);
	float flick = 0.5 + 0.5 * sin(TIME * 9.0);
	float a = vig * 0.62 + (grain - 0.5) * 0.12 + scan * 0.035 + flick * 0.012;
	COLOR = vec4(0.0, 0.02, 0.0, clamp(a, 0.0, 0.88));
}"

enum Phase { MENU, LOBBY, COUNT, PLAY, END }

var phase := Phase.MENU
var mode := "multi"
var font: Font
var gfx
var ai
var cur_map = null
var cur_map_idx := -1
var pmap := 0
var pnames := {}
var pskins := {}
var my_skin := 0
var players := {}
var time_left := 0.0
var local = null
var menu_cam: Camera3D
var env: Environment
var sun: DirectionalLight3D
var actors: Node3D
var parts_root: Node3D
var snd := {}
var music: AudioStreamPlayer
var ambient: AudioStreamPlayer
var heart: AudioStreamPlayer
var runbreath: AudioStreamPlayer

# حالة اللعب
var parts_pos: Array = []
var parts_nodes: Array = []
var parts_taken: Array = []
var parts_got := 0
var car_ready := false
var yaw := 0.0
var pitch := 0.0
var vel := Vector3.ZERO
var stamina := 100.0
var sprint_on := false
var sprint_idx := -1
var stick_idx := -1
var stick_origin := Vector2.ZERO
var stick_vec := Vector2.ZERO
var look_idx := -1
var last_sent := 0.0
var ai_sync := 0.0
var idle_t := 0.0
var here_t := 0.0
var hide_left := 0.0
var hide_cd := 0.0
var occupied := {}
var orbit_t := 0.0
var banner_id := 0
var flicker_t := 0.0
var rec_t := 0.0
var s_hide_left := {}
var s_hide_cd := {}
var roster := {}
var ending := false

# إعدادات
var set_quality := 1
var set_ui_scale := 1.0
var set_stick_left := true
var set_sens := 1.0
var set_vol := 1.0
var set_camfx := true
var settings_open := false

# واجهة
var theme_main: Theme
var root: Control
var panels := {}
var cur_panel := "menu"
var chars_back := "menu"
var name_edit: LineEdit
var ip_edit: LineEdit
var status_lbl: Label
var lobby_ip: Label
var lobby_list: Label
var lobby_start: Button
var lobby_wait: Label
var map_btns := []
var map_btns_s := []
var single_info: Label
var end_lbl: Label
var end_btn: Button
var end_wait: Label
var hud: Control
var camfx: Control
var rec_lbl: Label
var time_lbl: Label
var top_lbl: Label
var sub_lbl: Label
var stam_bar: ProgressBar
var act_btn: Button
var sprint_btn: Button
var gear_btn: Button
var banner_lbl: Label
var hint_lbl: Label
var overlay: ColorRect
var overlay_lbl: Label
var red_flash: ColorRect
var hide_veil: ColorRect
var stick
var camhud
var settings_wrap: Control
var quit_btn: Button
var title_lbl: Label
var prev_svc: SubViewportContainer
var prev_holder: Node3D
var prev_cam: Camera3D
var prev_name: Label
var prev_note: Label
var prev_pick: Button
var prev_i := 0
var camfx_btns := []
var quality_btns := []
var stick_btns := []

class Stick extends Control:
	var origin := Vector2.ZERO
	var knob := Vector2.ZERO
	var active := false
	var radius := 90.0
	func _draw() -> void:
		if not active:
			return
		draw_circle(origin, radius, Color(1, 1, 1, 0.10))
		draw_arc(origin, radius, 0.0, TAU, 40, Color(1, 1, 1, 0.35), 3.0)
		draw_circle(origin + knob, radius * 0.42, Color(1, 0.85, 0.5, 0.55))

class CamHud extends Control:
	var blink := true
	func _draw() -> void:
		var m := 26.0
		var l := 62.0
		var c := Color(1, 1, 1, 0.75)
		var w := 3.0
		var s := size
		for p in [Vector2(m, m), Vector2(s.x - m, m), Vector2(m, s.y - m), Vector2(s.x - m, s.y - m)]:
			var sx := 1.0 if p.x < s.x * 0.5 else -1.0
			var sy := 1.0 if p.y < s.y * 0.5 else -1.0
			draw_line(p, p + Vector2(l * sx, 0), c, w)
			draw_line(p, p + Vector2(0, l * sy), c, w)
		# بطارية
		var bx := s.x - 150.0
		draw_rect(Rect2(bx, 34, 62, 28), c, false, 3.0)
		draw_rect(Rect2(bx + 62, 42, 7, 12), c)
		for i in 3:
			draw_rect(Rect2(bx + 6 + i * 18, 40, 14, 16), Color(1, 1, 1, 0.8))
		draw_line(s * 0.5 + Vector2(-9, 0), s * 0.5 + Vector2(9, 0), Color(1, 1, 1, 0.5), 2.0)
		draw_line(s * 0.5 + Vector2(0, -9), s * 0.5 + Vector2(0, 9), Color(1, 1, 1, 0.5), 2.0)

# ───────────────────────── البداية ─────────────────────────
func _ready() -> void:
	Engine.max_fps = 60
	DisplayServer.screen_set_keep_on(true)
	font = load("res://fonts/Cairo_700Bold.ttf")
	gfx = GfxS.new()
	ai = AiS.new()
	ai.main = self
	load_settings()
	load_sounds()
	build_environment()
	build_ui()
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_conn_failed)
	multiplayer.server_disconnected.connect(_on_server_lost)
	get_viewport().size_changed.connect(layout_hud)
	load_map(0)
	apply_volume()
	go_menu()

func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		set_quality = int(cf.get_value("s", "quality", 1))
		set_ui_scale = float(cf.get_value("s", "ui", 1.0))
		set_stick_left = bool(cf.get_value("s", "stick_left", true))
		set_sens = float(cf.get_value("s", "sens", 1.0))
		set_vol = float(cf.get_value("s", "vol", 1.0))
		set_camfx = bool(cf.get_value("s", "camfx", true))
		my_skin = int(cf.get_value("s", "skin", 0))

func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("s", "quality", set_quality)
	cf.set_value("s", "ui", set_ui_scale)
	cf.set_value("s", "stick_left", set_stick_left)
	cf.set_value("s", "sens", set_sens)
	cf.set_value("s", "vol", set_vol)
	cf.set_value("s", "camfx", set_camfx)
	cf.set_value("s", "skin", my_skin)
	cf.save(SETTINGS_PATH)

func load_sounds() -> void:
	for n in ["step", "step_tile", "step_grass", "heart", "wind", "menu", "click", "sting", "growl", "voice_caught", "voice_here", "voice_where",
			"monster_breath", "monster_roar", "monster_step", "monster_screech", "scream", "breath_run", "rustle", "pickup", "car_ready", "engine", "hide_in"]:
		snd[n] = load("res://audio/%s.wav" % n)
	for n2 in ["heart", "wind", "menu", "monster_breath", "breath_run"]:
		var s: AudioStreamWAV = (snd[n2] as AudioStreamWAV).duplicate()
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = s.data.size() / 2
		snd[n2] = s

func build_environment() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.fog_enabled = true
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, 35, 0)
	add_child(sun)
	actors = Node3D.new()
	add_child(actors)
	parts_root = Node3D.new()
	add_child(parts_root)
	menu_cam = Camera3D.new()
	menu_cam.fov = 65
	menu_cam.far = 200
	add_child(menu_cam)
	menu_cam.position = Vector3(0, 22, 55)
	menu_cam.current = true
	music = AudioStreamPlayer.new()
	music.stream = snd["menu"]
	music.volume_db = -8.0
	add_child(music)
	ambient = AudioStreamPlayer.new()
	ambient.volume_db = -9.0
	add_child(ambient)
	heart = AudioStreamPlayer.new()
	heart.stream = snd["heart"]
	heart.volume_db = -80.0
	add_child(heart)
	runbreath = AudioStreamPlayer.new()
	runbreath.stream = snd["breath_run"]
	runbreath.volume_db = -80.0
	add_child(runbreath)

func load_map(idx: int) -> void:
	if cur_map != null and cur_map_idx == idx:
		return
	if cur_map != null:
		var old: Node3D = cur_map.root
		remove_child(old)
		old.queue_free()
	cur_map = MapS.new()
	cur_map.build(idx, self, gfx)
	cur_map_idx = idx
	var e: Dictionary = cur_map.env
	env.background_color = e["bg"]
	env.fog_light_color = e["fog"]
	env.fog_density = e["fog_d"]
	env.ambient_light_color = e["amb"]
	env.ambient_light_energy = e["amb_e"]
	sun.light_energy = e["sun_e"]
	sun.light_color = e["sun_c"]
	apply_quality()

func apply_quality() -> void:
	var q := clampi(set_quality, 0, 3)
	var vp := get_viewport()
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
	vp.scaling_3d_scale = [0.6, 0.8, 1.0, 1.0][q]
	vp.msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X][q]
	sun.shadow_enabled = q >= 2 and sun.light_energy > 0.0
	sun.directional_shadow_max_distance = 70.0
	RenderingServer.directional_shadow_atlas_set_size(4096 if q >= 3 else 2048, true)
	vp.positional_shadow_atlas_size = 4096 if q >= 3 else 2048
	env.glow_enabled = q >= 3
	if cur_map != null:
		for l in cur_map.lamps:
			l.visible = q >= 1
	if local != null and local.flash != null:
		local.flash.shadow_enabled = q >= 3
	if local != null and local.cam != null:
		local.cam.far = [45.0, 70.0, 100.0, 130.0][q]

func apply_volume() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(set_vol, 0.001)))

func play_ui(n: String, db: float = 0.0) -> void:
	var p := AudioStreamPlayer.new()
	p.stream = snd[n]
	p.volume_db = db
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()

# ───────────────────────── الواجهة ─────────────────────────
func sbox(bg: Color, border: Color, radius: int = 16, bw: int = 2, margin: float = 16.0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.content_margin_left = margin
	s.content_margin_right = margin
	s.content_margin_top = margin * 0.6
	s.content_margin_bottom = margin * 0.6
	return s

func make_theme() -> Theme:
	var th := Theme.new()
	th.default_font = font
	th.default_font_size = 30
	var amber := Color(1, 0.72, 0.3, 0.75)
	th.set_stylebox("normal", "Button", sbox(Color(0.2, 0.11, 0.05, 0.95), amber))
	th.set_stylebox("hover", "Button", sbox(Color(0.32, 0.18, 0.07, 0.98), Color(1, 0.85, 0.45, 1)))
	th.set_stylebox("pressed", "Button", sbox(Color(0.5, 0.28, 0.08, 1), Color(1, 0.92, 0.55, 1), 16, 3))
	th.set_stylebox("disabled", "Button", sbox(Color(0.12, 0.12, 0.12, 0.8), Color(0.4, 0.4, 0.4, 0.5)))
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_color("font_color", "Button", Color(1, 0.93, 0.78))
	th.set_color("font_pressed_color", "Button", Color(1, 1, 0.9))
	th.set_color("font_hover_color", "Button", Color(1, 1, 0.9))
	th.set_color("font_disabled_color", "Button", Color(0.6, 0.6, 0.6))
	th.set_stylebox("normal", "LineEdit", sbox(Color(0.05, 0.05, 0.08, 0.95), Color(0.9, 0.7, 0.4, 0.5), 14, 2, 12))
	th.set_stylebox("focus", "LineEdit", sbox(Color(0.07, 0.07, 0.1, 1), Color(1, 0.8, 0.4, 1), 14, 2, 12))
	th.set_color("font_color", "LineEdit", Color.WHITE)
	th.set_color("font_placeholder_color", "LineEdit", Color(0.6, 0.6, 0.65))
	th.set_color("caret_color", "LineEdit", Color(1, 0.8, 0.4))
	th.set_stylebox("panel", "PanelContainer", sbox(Color(0.04, 0.05, 0.09, 0.88), Color(1, 0.72, 0.3, 0.4), 28, 2, 26))
	var track := sbox(Color(0.25, 0.2, 0.15, 0.9), Color(0, 0, 0, 0), 8, 0, 0)
	track.content_margin_top = 5
	track.content_margin_bottom = 5
	th.set_stylebox("slider", "HSlider", track)
	th.set_stylebox("grabber_area", "HSlider", sbox(Color(1, 0.72, 0.3, 0.95), Color(0, 0, 0, 0), 8, 0, 0))
	th.set_stylebox("grabber_area_highlight", "HSlider", sbox(Color(1, 0.8, 0.4, 1), Color(0, 0, 0, 0), 8, 0, 0))
	var gi := Image.create(44, 44, false, Image.FORMAT_RGBA8)
	for y in 44:
		for x in 44:
			var d := Vector2(x - 21.5, y - 21.5).length()
			if d < 20.0:
				gi.set_pixel(x, y, Color(1, 0.88, 0.55, 1) if d < 17.0 else Color(0.5, 0.3, 0.1, 1))
	var gt := ImageTexture.create_from_image(gi)
	th.set_icon("grabber", "HSlider", gt)
	th.set_icon("grabber_highlight", "HSlider", gt)
	th.set_icon("grabber_disabled", "HSlider", gt)
	th.set_stylebox("background", "ProgressBar", sbox(Color(0, 0, 0, 0.5), Color(1, 1, 1, 0.3), 8, 1, 0))
	th.set_stylebox("fill", "ProgressBar", sbox(Color(0.4, 0.9, 0.5, 0.95), Color(0, 0, 0, 0), 8, 0, 0))
	return th

func lbl(t: String, sz: int = 30, col: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", sz)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

func btn(t: String, cb: Callable, h: float = 64.0) -> Button:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(0, h)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(cb)
	b.pressed.connect(play_ui.bind("click", -6.0))
	return b

func make_wrap(key: String, dim_alpha: float = 0.4) -> Control:
	var wrap := Control.new()
	wrap.set_anchors_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, dim_alpha)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	wrap.add_child(dim)
	root.add_child(wrap)
	panels[key] = wrap
	return wrap

# بطاقة قابلة للتمرير + عنوان + زر إغلاق ✕ ثابت دائماً
func make_card_in(wrap: Control, width: float, title: String, close_cb: Callable, scroll_h: float = 430.0) -> VBoxContainer:
	var c := CenterContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	wrap.add_child(c)
	var pc := PanelContainer.new()
	c.add_child(pc)
	var outer := VBoxContainer.new()
	outer.custom_minimum_size = Vector2(width, 0)
	outer.add_theme_constant_override("separation", 8)
	pc.add_child(outer)
	var head := HBoxContainer.new()
	outer.add_child(head)
	var t := lbl(title, 44, AMBER)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(t)
	if close_cb.is_valid():
		var x := btn("✕", close_cb, 62.0)
		x.custom_minimum_size = Vector2(76, 62)
		head.add_child(x)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, scroll_h)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(sc)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 10)
	sc.add_child(v)
	return v

func make_card(key: String, width: float, title: String, close_cb: Callable, scroll_h: float = 430.0) -> VBoxContainer:
	return make_card_in(make_wrap(key), width, title, close_cb, scroll_h)

func show_panel(key: String) -> void:
	cur_panel = key
	for k in panels:
		panels[k].visible = (k == key)
	hud.visible = false
	overlay.visible = false
	red_flash.modulate.a = 0.0
	if key == "chars":
		set_preview(prev_i)

func build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.layout_direction = Control.LAYOUT_DIRECTION_RTL
	theme_main = make_theme()
	root.theme = theme_main
	layer.add_child(root)
	build_hud()
	build_menu()
	build_story()
	build_single()
	build_lobby()
	build_chars()
	build_end()
	build_settings()

func build_hud() -> void:
	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud)
	hide_veil = ColorRect.new()
	hide_veil.color = Color(0, 0, 0, 0.45)
	hide_veil.set_anchors_preset(Control.PRESET_FULL_RECT)
	hide_veil.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hide_veil.visible = false
	hud.add_child(hide_veil)
	# تأثير الكاميرا القديمة
	camfx = Control.new()
	camfx.set_anchors_preset(Control.PRESET_FULL_RECT)
	camfx.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(camfx)
	var grain := ColorRect.new()
	grain.set_anchors_preset(Control.PRESET_FULL_RECT)
	grain.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = CAMFX_SHADER
	var smat := ShaderMaterial.new()
	smat.shader = sh
	grain.material = smat
	camfx.add_child(grain)
	camhud = CamHud.new()
	camhud.set_anchors_preset(Control.PRESET_FULL_RECT)
	camhud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	camfx.add_child(camhud)
	rec_lbl = lbl("● REC", 34, Color(1, 0.15, 0.1))
	rec_lbl.layout_direction = Control.LAYOUT_DIRECTION_LTR
	rec_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rec_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	rec_lbl.add_theme_constant_override("outline_size", 6)
	camfx.add_child(rec_lbl)
	time_lbl = lbl("00:00:00", 28, Color(1, 1, 1, 0.85))
	time_lbl.layout_direction = Control.LAYOUT_DIRECTION_LTR
	time_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	time_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	time_lbl.add_theme_constant_override("outline_size", 6)
	camfx.add_child(time_lbl)
	stick = Stick.new()
	stick.set_anchors_preset(Control.PRESET_FULL_RECT)
	stick.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(stick)
	top_lbl = lbl("", 30, Color(1, 0.9, 0.6))
	top_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	top_lbl.add_theme_constant_override("outline_size", 8)
	hud.add_child(top_lbl)
	sub_lbl = lbl("", 26, Color(0.7, 1, 0.8))
	sub_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sub_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	sub_lbl.add_theme_constant_override("outline_size", 7)
	hud.add_child(sub_lbl)
	stam_bar = ProgressBar.new()
	stam_bar.show_percentage = false
	stam_bar.max_value = 100.0
	stam_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(stam_bar)
	act_btn = Button.new()
	act_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(act_btn)
	sprint_btn = Button.new()
	sprint_btn.text = "ركض"
	sprint_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(sprint_btn)
	gear_btn = Button.new()
	gear_btn.text = "⚙"
	gear_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(gear_btn)
	banner_lbl = lbl("", 40, Color.WHITE)
	banner_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	banner_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	banner_lbl.add_theme_constant_override("outline_size", 12)
	banner_lbl.visible = false
	hud.add_child(banner_lbl)
	hint_lbl = lbl("", 30, Color(1, 0.5, 0.4))
	hint_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hint_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	hint_lbl.add_theme_constant_override("outline_size", 8)
	hud.add_child(hint_lbl)
	red_flash = ColorRect.new()
	red_flash.color = Color(0.8, 0, 0, 0.55)
	red_flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	red_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	red_flash.modulate.a = 0.0
	root.add_child(red_flash)
	overlay = ColorRect.new()
	overlay.color = Color.BLACK
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(overlay)
	overlay_lbl = lbl("", 46, Color(1, 0.8, 0.45))
	overlay_lbl.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	overlay_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(overlay_lbl)

func layout_hud() -> void:
	if hud == null:
		return
	var s := set_ui_scale
	var vs := get_viewport().get_visible_rect().size
	var m := 34.0 * s
	var bw := 250.0 * s
	var bh := 118.0 * s
	var ax := (vs.x - m - bw) if set_stick_left else m
	var ay := vs.y - m - bh
	act_btn.size = Vector2(bw, bh)
	act_btn.position = Vector2(ax, ay)
	act_btn.add_theme_font_size_override("font_size", int(34.0 * s))
	var sp := 112.0 * s
	sprint_btn.size = Vector2(sp, sp)
	sprint_btn.position = Vector2(ax + (bw - sp) * 0.5, ay - sp - 16.0 * s)
	sprint_btn.add_theme_font_size_override("font_size", int(28.0 * s))
	var gs := 66.0 * s
	gear_btn.size = Vector2(gs, gs)
	gear_btn.position = Vector2(vs.x - 40.0 - gs, 76.0)
	gear_btn.add_theme_font_size_override("font_size", int(34.0 * s))
	top_lbl.size = Vector2(900, 44)
	top_lbl.position = Vector2((vs.x - 900.0) * 0.5, 30)
	sub_lbl.size = Vector2(900, 36)
	sub_lbl.position = Vector2((vs.x - 900.0) * 0.5, 76)
	stam_bar.size = Vector2(300.0 * s, 12.0 * s)
	stam_bar.position = Vector2((vs.x - 300.0 * s) * 0.5, 122.0)
	banner_lbl.size = Vector2(900, 80)
	banner_lbl.position = Vector2((vs.x - 900.0) * 0.5, vs.y * 0.24)
	hint_lbl.size = Vector2(900, 60)
	hint_lbl.position = Vector2((vs.x - 900.0) * 0.5, vs.y * 0.66)
	rec_lbl.size = Vector2(200, 44)
	rec_lbl.position = Vector2(56, 30)
	time_lbl.size = Vector2(200, 36)
	time_lbl.position = Vector2(56, 72)
	stick.radius = 90.0 * s

func build_menu() -> void:
	var wrap := make_wrap("menu", 0.28)
	var c := CenterContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	wrap.add_child(c)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 56)
	c.add_child(hb)
	var tv := VBoxContainer.new()
	tv.custom_minimum_size = Vector2(540, 0)
	tv.add_theme_constant_override("separation", 6)
	hb.add_child(tv)
	title_lbl = lbl("ليلة الفانوس", 92, AMBER)
	title_lbl.add_theme_color_override("font_outline_color", Color(0.25, 0.08, 0.0))
	title_lbl.add_theme_constant_override("outline_size", 14)
	tv.add_child(title_lbl)
	tv.add_child(lbl("اجمع قطع المحرك.. واهرب من سكيري", 32, Color(0.9, 0.92, 1)))
	tv.add_child(lbl("فردي أو مع أصدقائك عبر نقطة الاتصال — بدون إنترنت", 22, Color(0.75, 0.8, 0.9)))
	var tw := create_tween().set_loops()
	tw.tween_property(title_lbl, "modulate", Color(1, 0.85, 0.7, 0.8), 1.4)
	tw.tween_property(title_lbl, "modulate", Color(1, 1, 1, 1), 1.4)
	var pc := PanelContainer.new()
	hb.add_child(pc)
	var v := VBoxContainer.new()
	v.custom_minimum_size = Vector2(520, 0)
	v.add_theme_constant_override("separation", 8)
	pc.add_child(v)
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "اسمك"
	name_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_edit.max_length = 12
	name_edit.custom_minimum_size = Vector2(0, 56)
	v.add_child(name_edit)
	v.add_child(btn("لعب فردي (معك بوتان)", func(): show_panel("single")))
	v.add_child(btn("إنشاء غرفة (أنا المضيف)", host_game))
	ip_edit = LineEdit.new()
	ip_edit.text = "192.168.43.1"
	ip_edit.placeholder_text = "عنوان المضيف"
	ip_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	ip_edit.custom_minimum_size = Vector2(0, 56)
	ip_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_URL
	v.add_child(ip_edit)
	v.add_child(btn("انضمام لغرفة", join_game))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	for item in [["الشخصيات", open_chars], ["القصة", func(): show_panel("story")], ["الإعدادات", open_settings]]:
		var b := btn(item[0], item[1], 58.0)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 26)
		row.add_child(b)
	v.add_child(row)
	status_lbl = lbl("شغّل نقطة الاتصال (Hotspot) على جهاز واحد وباقي الأصدقاء يتصلون بها", 20, Color(0.8, 0.8, 0.9))
	v.add_child(status_lbl)

func build_story() -> void:
	var s := make_card("story", 880.0, "القصة", func(): show_panel("menu"))
	s.add_child(lbl(STORY, 30))
	s.add_child(btn("رجوع", func(): show_panel("menu")))

func map_row(parent: Control, store: Array, cb: Callable) -> void:
	var mrow := HBoxContainer.new()
	mrow.add_theme_constant_override("separation", 8)
	var grp := ButtonGroup.new()
	for i in 3:
		var b := Button.new()
		b.text = MAP_NAMES[i]
		b.toggle_mode = true
		b.button_group = grp
		b.custom_minimum_size = Vector2(0, 62)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 26)
		b.pressed.connect(cb.bind(i))
		b.pressed.connect(play_ui.bind("click", -6.0))
		mrow.add_child(b)
		store.append(b)
	parent.add_child(mrow)

func build_single() -> void:
	var v := make_card("single", 760.0, "لعب فردي", func(): show_panel("menu"))
	v.add_child(lbl("معك بوتان (سارة وكريم) والوحش سكيري يطاردكم. اجمعوا القطع الخمس واهربوا بالعربية!", 26, Color(0.85, 0.9, 1)))
	v.add_child(lbl("الخريطة", 28, Color(0.9, 0.85, 0.7)))
	map_row(v, map_btns_s, _on_map_pick_single)
	var b := btn("اختيار الشخصية", open_chars)
	v.add_child(b)
	v.add_child(btn("ابدأ اللعبة", start_single))

func build_lobby() -> void:
	var r := make_card("lobby", 760.0, "غرفة اللعب", leave_to_menu)
	lobby_ip = lbl("", 26, Color(0.7, 1, 0.8))
	r.add_child(lobby_ip)
	r.add_child(lbl("الخريطة", 28, Color(0.9, 0.85, 0.7)))
	map_row(r, map_btns, _on_map_pick)
	r.add_child(btn("اختيار الشخصية", open_chars))
	lobby_list = lbl("", 32)
	r.add_child(lobby_list)
	lobby_start = btn("ابدأ اللعبة", _on_start_pressed)
	r.add_child(lobby_start)
	lobby_wait = lbl("في انتظار المضيف ليبدأ اللعبة...", 28, Color(0.85, 0.9, 1))
	r.add_child(lobby_wait)
	r.add_child(btn("خروج", leave_to_menu))

func build_end() -> void:
	var e := make_card("end", 760.0, "النتيجة", leave_to_menu, 330.0)
	end_lbl = lbl("", 54, AMBER)
	e.add_child(end_lbl)
	end_btn = btn("جولة جديدة", _on_new_round)
	e.add_child(end_btn)
	end_wait = lbl("في انتظار المضيف...", 28, Color(0.85, 0.9, 1))
	e.add_child(end_wait)
	e.add_child(btn("القائمة الرئيسية", leave_to_menu))

# ───────────── اختيار الشخصية (معاينة 3D) ─────────────
func build_chars() -> void:
	var v := make_card("chars", 820.0, "اختيار الشخصية", close_chars, 470.0)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var prev_btn := btn("▶", func(): step_preview(-1), 70.0)
	prev_btn.custom_minimum_size = Vector2(90, 70)
	var next_btn := btn("◀", func(): step_preview(1), 70.0)
	next_btn.custom_minimum_size = Vector2(90, 70)
	prev_svc = SubViewportContainer.new()
	prev_svc.stretch = true
	prev_svc.custom_minimum_size = Vector2(0, 250)
	prev_svc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var vp := SubViewport.new()
	vp.own_world_3d = true
	vp.msaa_3d = Viewport.MSAA_2X
	prev_svc.add_child(vp)
	row.add_child(prev_btn)
	row.add_child(prev_svc)
	row.add_child(next_btn)
	v.add_child(row)
	prev_name = lbl("", 38, AMBER)
	v.add_child(prev_name)
	prev_note = lbl("", 24, Color(0.8, 0.85, 0.95))
	v.add_child(prev_note)
	prev_pick = btn("اختيار هذه الشخصية", pick_preview)
	v.add_child(prev_pick)
	var e2 := Environment.new()
	e2.background_mode = Environment.BG_COLOR
	e2.background_color = Color(0.07, 0.03, 0.04)
	e2.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e2.ambient_light_color = Color(0.55, 0.5, 0.6)
	e2.ambient_light_energy = 0.7
	var we := WorldEnvironment.new()
	we.environment = e2
	vp.add_child(we)
	prev_cam = Camera3D.new()
	prev_cam.position = Vector3(0, 1.15, 3.8)
	prev_cam.rotation_degrees = Vector3(-7, 0, 0)
	prev_cam.fov = 40
	vp.add_child(prev_cam)
	var dl := DirectionalLight3D.new()
	dl.rotation_degrees = Vector3(-35, -25, 0)
	dl.light_energy = 1.1
	vp.add_child(dl)
	var rim := OmniLight3D.new()
	rim.position = Vector3(-1.6, 2.2, -2.0)
	rim.light_color = Color(1, 0.55, 0.25)
	rim.light_energy = 2.2
	rim.omni_range = 9.0
	vp.add_child(rim)
	var ped := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.0
	cm.bottom_radius = 1.05
	cm.height = 0.1
	ped.mesh = cm
	ped.material_override = gfx.get_mat("metal_dark")
	ped.position.y = -0.05
	vp.add_child(ped)
	prev_holder = Node3D.new()
	vp.add_child(prev_holder)

func open_chars() -> void:
	chars_back = cur_panel
	prev_i = my_skin
	show_panel("chars")

func close_chars() -> void:
	show_panel(chars_back)

func step_preview(d: int) -> void:
	prev_i = posmod(prev_i + d, PlayerS.SKINS.size() + 1)
	set_preview(prev_i)

func set_preview(i: int) -> void:
	for c in prev_holder.get_children():
		c.queue_free()
	var p = PlayerS.new()
	var monster := i >= PlayerS.SKINS.size()
	p.setup(-100, "", 0 if monster else i, "monster" if monster else "human", {}, font, gfx)
	p.fake_speed = 2.4
	prev_holder.add_child(p)
	prev_holder.scale = Vector3.ONE * (0.6 if monster else 1.0)
	prev_cam.position = Vector3(0, 1.55 if monster else 1.2, 4.6 if monster else 3.9)
	if monster:
		prev_name.text = "سكيري (الوحش)"
		prev_note.text = "يتحكم فيه الذكاء الاصطناعي دائماً.. يزحف ويطاردك!"
		prev_pick.disabled = true
	else:
		prev_name.text = PlayerS.SKINS[i]["name"]
		prev_note.text = "الشخصية الحالية" if i == my_skin else "اضغط لاختيارها"
		prev_pick.disabled = false

func pick_preview() -> void:
	if prev_i < PlayerS.SKINS.size():
		my_skin = prev_i
		save_settings()
		prev_note.text = "تم الاختيار ✓"

# ───────────── الإعدادات ─────────────
func add_slider(parent: Control, title: String, key: String, mn: float, mx: float, step: float, val: float) -> void:
	var row := VBoxContainer.new()
	row.add_child(lbl(title, 26, Color(0.95, 0.9, 0.8)))
	var sl := HSlider.new()
	sl.min_value = mn
	sl.max_value = mx
	sl.step = step
	sl.value = val
	sl.custom_minimum_size = Vector2(0, 48)
	sl.value_changed.connect(_on_slider.bind(key))
	row.add_child(sl)
	parent.add_child(row)

func toggle_row(parent: Control, title: String, names: Array, cur: int, store: Array, cb: Callable) -> void:
	parent.add_child(lbl(title, 26, Color(0.95, 0.9, 0.8)))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var grp := ButtonGroup.new()
	for i in names.size():
		var b := Button.new()
		b.text = names[i]
		b.toggle_mode = true
		b.button_group = grp
		b.button_pressed = (i == cur)
		b.custom_minimum_size = Vector2(0, 58)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 26)
		b.pressed.connect(cb.bind(i))
		row.add_child(b)
		store.append(b)
	parent.add_child(row)

func build_settings() -> void:
	settings_wrap = Control.new()
	settings_wrap.set_anchors_preset(Control.PRESET_FULL_RECT)
	settings_wrap.visible = false
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.82)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	settings_wrap.add_child(dim)
	root.add_child(settings_wrap)
	var v := make_card_in(settings_wrap, 820.0, "الإعدادات", close_settings, 440.0)
	toggle_row(v, "جودة الجرافيك", QUALITY_NAMES, set_quality, quality_btns, _on_quality)
	toggle_row(v, "مكان عصا الحركة", ["يسار", "يمين"], 0 if set_stick_left else 1, stick_btns, _on_stick_side)
	toggle_row(v, "تأثير الكاميرا القديمة", ["تشغيل", "إيقاف"], 0 if set_camfx else 1, camfx_btns, _on_camfx)
	add_slider(v, "حجم أزرار التحكم", "ui", 0.7, 1.5, 0.05, set_ui_scale)
	add_slider(v, "حساسية الكاميرا", "sens", 0.4, 2.5, 0.05, set_sens)
	add_slider(v, "مستوى الصوت", "vol", 0.0, 1.0, 0.05, set_vol)
	v.add_child(btn("حفظ وإغلاق", close_settings))
	quit_btn = btn("الخروج من المباراة", quit_match)
	v.add_child(quit_btn)

func open_settings() -> void:
	settings_open = true
	settings_wrap.visible = true
	quit_btn.visible = phase == Phase.COUNT or phase == Phase.PLAY

func close_settings() -> void:
	settings_open = false
	settings_wrap.visible = false
	save_settings()
	layout_hud()

func quit_match() -> void:
	close_settings()
	leave_to_menu()

func _on_quality(i: int) -> void:
	set_quality = i
	apply_quality()

func _on_stick_side(i: int) -> void:
	set_stick_left = (i == 0)
	layout_hud()

func _on_camfx(i: int) -> void:
	set_camfx = (i == 0)
	camfx.visible = set_camfx

func _on_slider(v: float, key: String) -> void:
	match key:
		"ui":
			set_ui_scale = v
			layout_hud()
		"sens":
			set_sens = v
		"vol":
			set_vol = v
			apply_volume()

func banner(t: String, secs: float = 4.0, col: Color = Color.WHITE, sz: int = 40) -> void:
	banner_id += 1
	var my := banner_id
	banner_lbl.text = t
	banner_lbl.add_theme_color_override("font_color", col)
	banner_lbl.add_theme_font_size_override("font_size", sz)
	banner_lbl.visible = true
	await get_tree().create_timer(secs).timeout
	if my == banner_id:
		banner_lbl.visible = false

func my_name() -> String:
	var n := name_edit.text.strip_edges()
	if n == "":
		n = "لاعب"
	return n

func local_ips() -> String:
	var out := []
	for a in IP.get_local_addresses():
		if a.count(".") == 3 and not a.begins_with("127.") and not a.begins_with("169.254"):
			out.append(a)
	return " — ".join(out)

func go_menu() -> void:
	phase = Phase.MENU
	menu_cam.current = true
	ambient.stop()
	heart.stop()
	runbreath.stop()
	if not music.playing:
		music.play()
	show_panel("menu")

# ───────────────────────── الشبكة ─────────────────────────
func online() -> bool:
	var p := multiplayer.multiplayer_peer
	return p != null and not (p is OfflineMultiplayerPeer) and p.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED

func bc(method: String, args: Array = []) -> void:
	if online():
		callv("rpc", [method] + args)
	else:
		callv(method, args)

func is_host() -> bool:
	return multiplayer.is_server()

func host_game() -> void:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_CLIENTS)
	if err != OK:
		status_lbl.text = "تعذّر إنشاء الغرفة، جرّب مرة أخرى"
		return
	multiplayer.multiplayer_peer = peer
	mode = "multi"
	pnames = {1: my_name()}
	pskins = {1: my_skin}
	phase = Phase.LOBBY
	refresh_lobby()
	show_panel("lobby")

func join_game() -> void:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip_edit.text.strip_edges(), PORT)
	if err != OK:
		status_lbl.text = "عنوان غير صحيح"
		return
	multiplayer.multiplayer_peer = peer
	mode = "multi"
	status_lbl.text = "جاري الاتصال..."

func start_single() -> void:
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	mode = "single"
	pnames = {1: my_name()}
	pskins = {1: my_skin}
	start_round()

func _on_connected() -> void:
	rpc_id(1, "net_register", my_name(), my_skin)

func _on_conn_failed() -> void:
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	status_lbl.text = "فشل الاتصال — تأكد أنك متصل بنقطة اتصال المضيف وأن العنوان صحيح"

func _on_server_lost() -> void:
	leave_to_menu()
	status_lbl.text = "انقطع الاتصال بالمضيف"

func leave_to_menu() -> void:
	if online():
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	clear_players()
	clear_parts()
	pnames = {}
	pskins = {}
	mode = "multi"
	settings_open = false
	settings_wrap.visible = false
	go_menu()

func _on_peer_disconnected(id: int) -> void:
	if not multiplayer.is_server():
		return
	pnames.erase(id)
	pskins.erase(id)
	if players.has(id):
		var p = players[id]
		if p.hidden:
			occupied.erase(p.hide_spot)
		p.queue_free()
		players.erase(id)
	bc("net_lobby", [pnames, pskins, pmap])
	if phase == Phase.COUNT or phase == Phase.PLAY:
		check_end()

@rpc("any_peer", "reliable")
func net_register(nm: String, skin: int) -> void:
	var id := multiplayer.get_remote_sender_id()
	if phase != Phase.LOBBY:
		multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	pnames[id] = nm
	pskins[id] = skin
	bc("net_lobby", [pnames, pskins, pmap])

@rpc("authority", "call_local", "reliable")
func net_lobby(d: Dictionary, sk: Dictionary, mp: int) -> void:
	pnames = d
	pskins = sk
	pmap = mp
	if phase == Phase.MENU or phase == Phase.LOBBY:
		phase = Phase.LOBBY
		refresh_lobby()
		if cur_panel != "chars":
			show_panel("lobby")

func refresh_lobby() -> void:
	var lines := []
	for id in pnames:
		lines.append("• " + str(pnames[id]))
	lobby_list.text = "\n".join(lines)
	var host := multiplayer.is_server()
	lobby_ip.text = ("عنوان غرفتك: " + local_ips()) if host else "تم الاتصال بالغرفة"
	lobby_start.visible = host
	lobby_wait.visible = not host
	lobby_start.disabled = pnames.size() < 1
	for i in map_btns.size():
		map_btns[i].button_pressed = (i == pmap)
		map_btns[i].disabled = not host and i != pmap

func _on_map_pick(i: int) -> void:
	if multiplayer.is_server() and phase == Phase.LOBBY:
		pmap = i
		bc("net_lobby", [pnames, pskins, pmap])
		load_map(i)

func _on_map_pick_single(i: int) -> void:
	pmap = i
	load_map(i)

func _on_start_pressed() -> void:
	if not multiplayer.is_server():
		return
	pskins[1] = my_skin
	start_round()

func start_round() -> void:
	# يعمل عند المضيف أو في الوضع الفردي
	load_map(pmap)
	await get_tree().physics_frame
	await get_tree().physics_frame
	ai.build_grid(get_world_3d().direct_space_state, cur_map.half, cur_map.spawns[0])
	var r := {}
	for id in pnames:
		r[id] = {"n": pnames[id], "s": int(pskins.get(id, 0)), "k": "human"}
	if mode == "single":
		var used := [my_skin]
		var bi := 0
		for s in PlayerS.SKINS.size():
			if bi < 2 and not used.has(s):
				used.append(s)
				r[-(bi + 1)] = {"n": BOT_NAMES[bi], "s": s, "k": "bot"}
				bi += 1
	r[0] = {"n": "سكيري", "s": 0, "k": "monster"}
	var pts: Array = cur_map.spawns.duplicate()
	pts.shuffle()
	var spawns := {}
	var i := 0
	for id in r:
		if id != 0:
			spawns[id] = pts[i % pts.size()]
			i += 1
	spawns[0] = Vector3.ZERO
	var avoid: Array = [cur_map.car_pos]
	for id in spawns:
		avoid.append(spawns[id])
	var parts: Array = ai.pick_points(PART_COUNT, avoid, 14.0, 16.0)
	bc("net_begin", [r, spawns, pmap, parts])

func make_part(pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos + Vector3(0, 0.9, 0)
	var glow := StandardMaterial3D.new()
	glow.albedo_color = Color(0.2, 0.9, 1.0)
	glow.emission_enabled = true
	glow.emission = Color(0.2, 0.9, 1.0)
	glow.emission_energy_multiplier = 2.5
	var metal: Material = gfx.get_mat("metal")
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.13
	cm.bottom_radius = 0.13
	cm.height = 0.5
	cm.radial_segments = 8
	mi.mesh = cm
	mi.material_override = metal
	n.add_child(mi)
	var blk := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.42, 0.26, 0.3)
	blk.mesh = bm
	blk.material_override = metal
	blk.position.y = -0.1
	n.add_child(blk)
	var gear := MeshInstance3D.new()
	var gm := CylinderMesh.new()
	gm.top_radius = 0.24
	gm.bottom_radius = 0.24
	gm.height = 0.06
	gm.radial_segments = 10
	gear.mesh = gm
	gear.material_override = glow
	gear.rotation.x = PI * 0.5
	gear.position = Vector3(0, 0.1, 0.18)
	n.add_child(gear)
	var beam := MeshInstance3D.new()
	var bcm := CylinderMesh.new()
	bcm.top_radius = 0.04
	bcm.bottom_radius = 0.04
	bcm.height = 8.0
	bcm.radial_segments = 6
	beam.mesh = bcm
	var bmat := StandardMaterial3D.new()
	bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bmat.albedo_color = Color(0.2, 0.9, 1.0, 0.28)
	beam.material_override = bmat
	beam.position.y = 4.0
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	n.add_child(beam)
	var l := OmniLight3D.new()
	l.light_color = Color(0.3, 0.9, 1.0)
	l.light_energy = 1.4
	l.omni_range = 6.0
	n.add_child(l)
	var tag := Label3D.new()
	tag.text = "قطعة محرك"
	tag.font = font
	tag.font_size = 40
	tag.pixel_size = 0.004
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tag.position.y = 0.8
	tag.outline_size = 8
	tag.visibility_range_end = 20.0
	n.add_child(tag)
	parts_root.add_child(n)
	return n

func clear_parts() -> void:
	for n in parts_nodes:
		if is_instance_valid(n):
			n.queue_free()
	parts_nodes.clear()
	parts_taken.clear()
	parts_pos.clear()
	parts_got = 0
	car_ready = false

@rpc("authority", "call_local", "reliable")
func net_begin(r: Dictionary, spawns: Dictionary, map_idx: int, parts: Array) -> void:
	pmap = map_idx
	load_map(map_idx)
	clear_players()
	clear_parts()
	occupied.clear()
	s_hide_left.clear()
	s_hide_cd.clear()
	roster = r
	ending = false
	for id in r:
		var info: Dictionary = r[id]
		var p = PlayerS.new()
		p.setup(id, str(info["n"]), int(info["s"]), str(info["k"]), snd, font, gfx, cur_map.step_name)
		actors.add_child(p)
		var sp: Vector3 = spawns[id]
		p.global_position = sp
		p.target_pos = sp
		if str(info["k"]) != "monster":
			p.rotation.y = atan2(sp.x, sp.z)
			p.target_yaw = p.rotation.y
		players[id] = p
	var me := multiplayer.get_unique_id()
	local = players[me]
	local.make_local()
	var sp0: Vector3 = spawns[me]
	yaw = atan2(sp0.x, sp0.z)
	pitch = 0.0
	local.rotation.y = yaw
	vel = Vector3.ZERO
	stamina = 100.0
	sprint_on = false
	sprint_idx = -1
	stick_idx = -1
	look_idx = -1
	stick_vec = Vector2.ZERO
	stick.active = false
	hide_left = 0.0
	hide_cd = 0.0
	idle_t = 0.0
	here_t = 0.0
	rec_t = 0.0
	for pp in parts:
		parts_pos.append(pp)
		parts_nodes.append(make_part(pp))
		parts_taken.append(false)
	phase = Phase.COUNT
	time_left = HIDE_TIME
	for k in panels:
		panels[k].visible = false
	hud.visible = true
	camfx.visible = set_camfx
	overlay.visible = false
	hide_veil.visible = false
	music.stop()
	ambient.stream = snd["wind"]
	ambient.pitch_scale = float(cur_map.env["wind"])
	ambient.play()
	heart.play()
	heart.volume_db = -80.0
	runbreath.play()
	runbreath.volume_db = -80.0
	if cur_map.car_light != null:
		cur_map.car_light.light_color = Color(1.0, 0.2, 0.15)
	if multiplayer.is_server():
		ai.reset()
	layout_hud()
	apply_quality()
	banner("%s — اختبئ وابحث عن قطع المحرك! سكيري يستيقظ بعد قليل" % MAP_NAMES[map_idx], 5.0)

@rpc("authority", "call_local", "reliable")
func net_go() -> void:
	phase = Phase.PLAY
	time_left = ROUND_TIME
	play_ui("growl", -2.0)
	if players.has(0):
		players[0].say("monster_roar", 10.0)
	banner("سكيري استيقظ! اجمع القطع واهرب", 4.0, Color(1, 0.5, 0.3))

@rpc("any_peer", "unreliable")
func net_pos(pos: Vector3, yw: float, pt: float) -> void:
	var id := multiplayer.get_remote_sender_id()
	if players.has(id):
		var p = players[id]
		p.target_pos = pos
		p.target_yaw = yw
		p.target_pitch = pt

@rpc("authority", "unreliable")
func net_ai(arr: Array) -> void:
	for e in arr:
		var id: int = e[0]
		if players.has(id):
			var p = players[id]
			p.target_pos = e[1]
			p.target_yaw = e[2]
			p.mstate = e[3]

@rpc("any_peer", "reliable")
func net_here() -> void:
	var id := multiplayer.get_remote_sender_id()
	if players.has(id) and not players[id].is_local:
		players[id].say("voice_here", 8.0)
	if multiplayer.is_server() and players.has(id):
		ai.hear(players[id].global_position, 40.0)

# ── أحداث الوحش (من الخادم)
func on_monster_chase() -> void:
	bc("net_roar")

func on_monster_say(n: String) -> void:
	bc("net_msay", [n])

@rpc("authority", "call_local", "reliable")
func net_roar() -> void:
	if players.has(0):
		players[0].say("monster_roar", 12.0)
	play_ui("sting", -9.0)

@rpc("authority", "call_local", "reliable")
func net_msay(n: String) -> void:
	if players.has(0):
		players[0].say(n, 8.0)

@rpc("authority", "call_local", "reliable")
func net_lunge() -> void:
	if players.has(0):
		players[0].lunge()

func server_monster_catch(id: int) -> void:
	if not players.has(id) or players[id].caught:
		return
	bc("net_lunge")
	bc("net_caught", [id])
	check_end()

func server_check_spot(si: int) -> void:
	if occupied.has(si):
		var occ: int = occupied[si]
		bc("net_unhide", [occ])
		server_monster_catch(occ)

@rpc("authority", "call_local", "reliable")
func net_caught(id: int) -> void:
	if not players.has(id):
		return
	var p = players[id]
	p.set_caught()
	if players.has(0):
		players[0].say("voice_caught", 13.0)
	play_ui("sting", -4.0)
	if p.is_local:
		Input.vibrate_handheld(450)
		play_ui("scream", -2.0)
		play_ui("monster_screech", -6.0)
		banner("I CAUGHT YOU", 4.0, Color(1, 0.1, 0.1), 84)
		var tw := create_tween()
		red_flash.modulate.a = 1.0
		tw.tween_property(red_flash, "modulate:a", 0.0, 1.4)
		hide_veil.visible = false
		heart.volume_db = -80.0
		runbreath.volume_db = -80.0
	else:
		p.say("scream", 6.0)
		banner("سكيري مسك %s" % str(roster[id]["n"]), 3.0, Color(1, 0.6, 0.5))

func humans_alive() -> int:
	var c := 0
	for id in players:
		var p = players[id]
		if p.kind == "human" and not p.caught:
			c += 1
	return c

func check_end() -> void:
	if ending:
		return
	if humans_alive() == 0:
		ending = true
		bc("net_end", [false, "caught"])

# ── الاختباء
@rpc("any_peer", "reliable")
func net_req_hide(si: int) -> void:
	do_hide_req(multiplayer.get_remote_sender_id(), si)

@rpc("any_peer", "reliable")
func net_req_unhide() -> void:
	var id := multiplayer.get_remote_sender_id()
	if players.has(id) and players[id].hidden:
		bc("net_unhide", [id])

func can_hide(id: int) -> bool:
	return float(s_hide_cd.get(id, 0.0)) <= 0.0 and players.has(id) and not players[id].hidden and not players[id].caught

func do_hide_req(id: int, si: int) -> void:
	if phase != Phase.COUNT and phase != Phase.PLAY:
		return
	if not players.has(id) or cur_map == null or players[id].is_monster:
		return
	var p = players[id]
	if p.caught or p.hidden:
		return
	if si < 0 or si >= cur_map.spots.size() or occupied.has(si):
		return
	if not can_hide(id):
		return
	var spos: Vector3 = cur_map.spots[si]["pos"]
	var pp: Vector3 = p.global_position
	if Vector2(pp.x - spos.x, pp.z - spos.z).length() > SPOT_REACH + 1.0:
		return
	s_hide_left[id] = HIDE_MAX
	bc("net_hide", [id, si, pp])

@rpc("authority", "call_local", "reliable")
func net_hide(id: int, si: int, ret: Vector3) -> void:
	if not players.has(id):
		return
	var p = players[id]
	p.hidden = true
	p.hide_spot = si
	p.ret_pos = ret
	occupied[si] = id
	var spos: Vector3 = cur_map.spots[si]["pos"]
	p.global_position = spos
	p.target_pos = spos
	p.say("hide_in", 0.0)
	if p.is_local:
		hide_left = HIDE_MAX
		vel = Vector3.ZERO
		hide_veil.visible = true
		idle_t = 0.0
	else:
		p.visible = false

@rpc("authority", "call_local", "reliable")
func net_unhide(id: int) -> void:
	if not players.has(id):
		return
	var p = players[id]
	if not p.hidden:
		return
	occupied.erase(p.hide_spot)
	p.hidden = false
	p.global_position = p.ret_pos
	p.target_pos = p.ret_pos
	if p.is_local:
		hide_cd = HIDE_COOLDOWN
		hide_veil.visible = false
	else:
		p.visible = true
	if multiplayer.is_server():
		s_hide_left.erase(id)
		s_hide_cd[id] = HIDE_COOLDOWN

# ── القطع والسيارة
@rpc("authority", "call_local", "reliable")
func net_part(k: int, who: int) -> void:
	if k < 0 or k >= parts_taken.size() or parts_taken[k]:
		return
	parts_taken[k] = true
	if is_instance_valid(parts_nodes[k]):
		parts_nodes[k].queue_free()
	parts_got += 1
	play_ui("pickup", -3.0)
	var who_name := str(roster[who]["n"]) if roster.has(who) else ""
	banner("%s جمع قطعة (%d/%d)" % [who_name, parts_got, parts_taken.size()], 3.0, Color(0.5, 0.95, 1.0))
	if parts_got >= parts_taken.size():
		car_ready = true
		if cur_map.car_light != null:
			cur_map.car_light.light_color = Color(0.2, 1.0, 0.3)
		play_ui("car_ready", -2.0)
		banner("اكتمل المحرك! اذهبوا إلى السيارة", 5.0, Color(0.5, 1.0, 0.6))

@rpc("authority", "call_local", "reliable")
func net_end(win: bool, why: String = "") -> void:
	phase = Phase.END
	ending = true
	overlay.visible = false
	stick_idx = -1
	stick_vec = Vector2.ZERO
	stick.active = false
	heart.volume_db = -80.0
	runbreath.volume_db = -80.0
	settings_open = false
	settings_wrap.visible = false
	if win:
		end_lbl.text = "نجوتم!\nهربتم بالسيارة قبل الفجر"
		play_ui("engine", -2.0)
	elif why == "time":
		end_lbl.text = "طلع الفجر.. ولم تهربوا\nسكيري فاز"
	else:
		end_lbl.text = "أمسك سكيري بالجميع\nانتهت اللعبة"
	var host := multiplayer.is_server()
	end_btn.visible = host
	end_wait.visible = not host
	menu_cam.current = true
	show_panel("end")

func _on_new_round() -> void:
	if multiplayer.is_server():
		if mode == "single":
			clear_players()
			clear_parts()
			start_round()
		else:
			bc("net_to_lobby")

@rpc("authority", "call_local", "reliable")
func net_to_lobby() -> void:
	clear_players()
	clear_parts()
	phase = Phase.LOBBY
	ambient.stop()
	heart.stop()
	runbreath.stop()
	music.play()
	refresh_lobby()
	show_panel("lobby")

func clear_players() -> void:
	for id in players:
		if is_instance_valid(players[id]):
			players[id].queue_free()
	players.clear()
	local = null
	menu_cam.current = true

# ───────────────────────── الإدخال ─────────────────────────
func hud_rect(c: Control) -> Rect2:
	return c.get_global_rect().grow(14.0)

func hud_press(idx: int, pos: Vector2) -> bool:
	if gear_btn.visible and hud_rect(gear_btn).has_point(pos):
		open_settings()
		return true
	if act_btn.visible and hud_rect(act_btn).has_point(pos):
		on_act()
		return true
	if sprint_btn.visible and hud_rect(sprint_btn).has_point(pos):
		sprint_idx = idx
		sprint_on = true
		return true
	return false

func _input(event: InputEvent) -> void:
	if settings_open or local == null:
		return
	if phase != Phase.COUNT and phase != Phase.PLAY:
		return
	var vs := get_viewport().get_visible_rect().size
	if event is InputEventScreenTouch:
		var pos: Vector2 = event.position
		if event.pressed:
			if hud_press(event.index, pos):
				return
			var on_left := pos.x < vs.x * 0.5
			if on_left == set_stick_left:
				if stick_idx == -1:
					stick_idx = event.index
					stick_origin = pos
					stick.origin = pos
					stick.knob = Vector2.ZERO
					stick.active = true
					stick.queue_redraw()
			elif look_idx == -1:
				look_idx = event.index
		else:
			if event.index == sprint_idx:
				sprint_idx = -1
				sprint_on = false
			if event.index == stick_idx:
				stick_idx = -1
				stick_vec = Vector2.ZERO
				stick.active = false
				stick.queue_redraw()
			if event.index == look_idx:
				look_idx = -1
	elif event is InputEventScreenDrag:
		if event.index == stick_idx:
			var d: Vector2 = event.position - stick_origin
			stick_vec = (d / stick.radius).limit_length(1.0)
			stick.knob = stick_vec * stick.radius
			stick.queue_redraw()
		elif event.index == look_idx:
			var k := 0.0045 * set_sens
			yaw -= event.relative.x * k
			pitch = clampf(pitch - event.relative.y * k, -1.3, 1.3)

func on_act() -> void:
	if local == null or (phase != Phase.PLAY and phase != Phase.COUNT) or local.caught:
		return
	if local.hidden:
		if multiplayer.is_server():
			bc("net_unhide", [multiplayer.get_unique_id()])
		else:
			rpc_id(1, "net_req_unhide")
		return
	var si := nearest_free_spot()
	if si < 0 or hide_cd > 0.0:
		return
	if multiplayer.is_server():
		do_hide_req(multiplayer.get_unique_id(), si)
	else:
		rpc_id(1, "net_req_hide", si)

func nearest_free_spot() -> int:
	if cur_map == null or local == null:
		return -1
	var best := -1
	var bd := SPOT_REACH
	var lp: Vector3 = local.global_position
	for si in cur_map.spots.size():
		if occupied.has(si):
			continue
		var sp: Vector3 = cur_map.spots[si]["pos"]
		var d := Vector2(lp.x - sp.x, lp.z - sp.z).length()
		if d < bd:
			bd = d
			best = si
	return best

# ───────────────────────── اللعب ─────────────────────────
func _physics_process(delta: float) -> void:
	if phase != Phase.COUNT and phase != Phase.PLAY:
		return
	if multiplayer.is_server() and cur_map != null:
		ai.tick_monster(delta, phase == Phase.PLAY)
		var left: Array = []
		for k in parts_taken.size():
			if not parts_taken[k]:
				left.append(parts_pos[k])
		for id in players:
			if players[id].kind == "bot":
				ai.tick_bot(id, delta, left, car_ready, cur_map.car_pos)
	if local == null:
		return
	var dir := stick_vec
	if dir == Vector2.ZERO:
		dir = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var frozen: bool = local.caught or local.hidden
	var want := Vector3.ZERO
	var sprinting := false
	if not frozen and dir.length() > 0.05:
		var spd := WALK
		if sprint_on and stamina > 2.0:
			spd = SPRINT
			sprinting = true
		want = (Basis(Vector3.UP, yaw) * Vector3(dir.x, 0, dir.y)).normalized() * spd * minf(1.0, dir.length() * 1.15)
	vel = vel.move_toward(want, 24.0 * delta)
	local.rotation.y = yaw
	if local.cam != null:
		local.cam.rotation.x = pitch
	if not local.hidden and not local.caught:
		local.velocity = vel
		local.move_and_slide()
		local.global_position.y = 0.0
	if sprinting:
		stamina = maxf(0.0, stamina - 24.0 * delta)
	else:
		stamina = minf(100.0, stamina + 11.0 * delta)
	last_sent += delta
	if last_sent >= 0.05:
		last_sent = 0.0
		if online():
			rpc("net_pos", local.global_position, yaw, pitch)

func _process(delta: float) -> void:
	flicker_t += delta
	if cur_map != null:
		var i := 0
		for l in cur_map.flickers:
			var f := sin(flicker_t * 13.0 + i * 2.3) * sin(flicker_t * 7.1 + i)
			l.light_energy = float(l.get_meta("base")) * (1.0 if f > -0.55 else 0.12)
			i += 1
	if panels.has("chars") and panels["chars"].visible and prev_holder != null:
		prev_holder.rotation.y += delta * 0.9
	if phase == Phase.MENU or phase == Phase.LOBBY or phase == Phase.END:
		orbit_t += delta * 0.1
		var r := 56.0 if cur_map == null else (float(cur_map.half) + 16.0)
		menu_cam.position = Vector3(sin(orbit_t) * r, 20.0, cos(orbit_t) * r)
		menu_cam.look_at(Vector3(0, 3, 0))
		return
	if local == null or (phase != Phase.COUNT and phase != Phase.PLAY):
		return
	time_left = maxf(0.0, time_left - delta)
	hide_cd = maxf(0.0, hide_cd - delta)
	rec_t += delta
	if hide_left > 0.0:
		hide_left = maxf(0.0, hide_left - delta)
	var host := multiplayer.is_server()
	for id in players:
		var p = players[id]
		if p == local or p.hidden or p.caught:
			continue
		if host and p.kind != "human":
			continue
		p.global_position = p.global_position.lerp(p.target_pos, minf(1.0, delta * 14.0))
		p.rotation.y = lerp_angle(p.rotation.y, p.target_yaw, minf(1.0, delta * 14.0))
	for k in parts_nodes.size():
		if is_instance_valid(parts_nodes[k]):
			parts_nodes[k].rotation.y += delta * 1.6
			parts_nodes[k].position.y = 0.95 + sin(flicker_t * 2.0 + k) * 0.12
	# اهتزاز كاميرا يدوية خفيف
	if local.cam != null and set_camfx:
		var run := 2.0 if sprint_on else 1.0
		local.cam.rotation.z = sin(flicker_t * 1.3) * 0.005 + sin(flicker_t * 6.7) * 0.0025 * run
		local.cam.rotation.x = pitch + sin(flicker_t * 1.9) * 0.003 * run
	update_idle(delta)
	update_audio_state()
	update_hud()
	if host:
		server_tick(delta)

func update_idle(delta: float) -> void:
	if phase == Phase.PLAY and not local.caught and not local.hidden:
		if local.speed_est < 0.25:
			idle_t += delta
		else:
			idle_t = 0.0
			here_t = 0.0
		if idle_t >= IDLE_BEFORE_VOICE:
			here_t -= delta
			if here_t <= 0.0:
				here_t = HERE_EVERY
				local.say("voice_here", 4.0)
				if multiplayer.is_server():
					ai.hear(local.global_position, 40.0)
				elif online():
					rpc("net_here")
	else:
		idle_t = 0.0

func update_audio_state() -> void:
	var near := 99.0
	if players.has(0) and phase == Phase.PLAY and not local.caught:
		near = local.global_position.distance_to(players[0].global_position)
	if near < 22.0:
		var k := near / 22.0
		heart.volume_db = lerpf(-2.0, -28.0, k)
		heart.pitch_scale = lerpf(1.5, 0.9, k)
	else:
		heart.volume_db = -80.0
	var tired: bool = stamina < 55.0 or (sprint_on and local.speed_est > 4.5)
	runbreath.volume_db = lerpf(runbreath.volume_db, -8.0 if (tired and not local.caught) else -80.0, 0.08)

func server_tick(delta: float) -> void:
	if phase == Phase.COUNT and time_left <= 0.0:
		bc("net_go")
	elif phase == Phase.PLAY and time_left <= 0.0 and not ending:
		ending = true
		bc("net_end", [false, "time"])
	for id in s_hide_cd.keys():
		s_hide_cd[id] = maxf(0.0, float(s_hide_cd[id]) - delta)
	for id2 in s_hide_left.keys():
		s_hide_left[id2] = float(s_hide_left[id2]) - delta
		if float(s_hide_left[id2]) <= 0.0:
			bc("net_unhide", [id2])
	if phase == Phase.PLAY and not ending:
		# التقاط القطع
		for k in parts_taken.size():
			if parts_taken[k]:
				continue
			for id in players:
				var p = players[id]
				if p.is_monster or p.caught or p.hidden:
					continue
				var d := Vector2(p.global_position.x - parts_pos[k].x, p.global_position.z - parts_pos[k].z).length()
				if d < 1.9:
					bc("net_part", [k, id])
					ai.hear(parts_pos[k], 22.0)
					break
		# الهروب بالسيارة (لاعب بشري فقط)
		if car_ready:
			for id3 in players:
				var q = players[id3]
				if q.kind == "human" and not q.caught and not q.hidden:
					var dc := Vector2(q.global_position.x - cur_map.car_pos.x, q.global_position.z - cur_map.car_pos.z).length()
					if dc < 4.0:
						ending = true
						bc("net_end", [true, ""])
						break
	# إرسال حالة الذكاء الاصطناعي
	ai_sync += delta
	if ai_sync >= 0.066 and online():
		ai_sync = 0.0
		var arr := []
		for id4 in players:
			var a = players[id4]
			if a.kind != "human":
				arr.append([id4, a.global_position, a.rotation.y, a.mstate])
		rpc("net_ai", arr)

func fmt_time(t: float) -> String:
	var s := int(ceil(t))
	return "%d:%02d" % [s / 60, s % 60]

func update_hud() -> void:
	var is_c: bool = local.caught
	if phase == Phase.COUNT:
		top_lbl.text = "سكيري يستيقظ بعد %d ثانية" % int(ceil(time_left))
	else:
		top_lbl.text = "قطع المحرك %d/%d  •  الفجر: %s" % [parts_got, parts_taken.size(), fmt_time(time_left)]
	var lp: Vector3 = local.global_position
	if is_c:
		sub_lbl.text = "تم القبض عليك.. شاهد بقية الفريق"
	elif car_ready:
		var dcar := Vector2(lp.x - cur_map.car_pos.x, lp.z - cur_map.car_pos.z).length()
		sub_lbl.text = "السيارة جاهزة! تبعد %d م" % int(dcar)
	else:
		var nd := 9999.0
		for k in parts_taken.size():
			if not parts_taken[k]:
				nd = minf(nd, Vector2(lp.x - parts_pos[k].x, lp.z - parts_pos[k].z).length())
		sub_lbl.text = "أقرب قطعة: %d م" % int(nd) if nd < 9000.0 else ""
	rec_lbl.visible = int(flicker_t * 1.6) % 2 == 0
	var rt := int(rec_t)
	time_lbl.text = "%02d:%02d:%02d" % [rt / 3600, (rt / 60) % 60, rt % 60]
	stam_bar.value = stamina
	sprint_btn.visible = not is_c and not local.hidden
	sprint_btn.modulate = Color(1, 1, 1, 1.0 if sprint_on else 0.8)
	var act_vis := true
	act_btn.modulate.a = 1.0
	if is_c:
		act_vis = false
	elif local.hidden:
		act_btn.text = "اخرج (%d)" % int(ceil(hide_left))
	else:
		var si := nearest_free_spot()
		if hide_cd > 0.0:
			act_btn.text = "انتظر %d" % int(ceil(hide_cd))
			act_btn.modulate.a = 0.5
			act_vis = si >= 0
		elif si >= 0:
			act_btn.text = "اختبئ: " + str(cur_map.spots[si]["name"])
		else:
			act_vis = false
	act_btn.visible = act_vis
	hint_lbl.text = ""
	if idle_t >= IDLE_BEFORE_VOICE:
		hint_lbl.text = "أنت ساكن! سكيري يسمع صوتك.. تحرّك!"
	elif local.hidden:
		hint_lbl.text = "مختبئ.. ستخرج بعد %d ثوانٍ" % int(ceil(hide_left))
