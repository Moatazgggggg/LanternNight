extends RefCounted
# ثلاث خرائط: الحارة القديمة / المدرسة المهجورة / الغابة المهجورة
# كل خريطة تُبنى بنفس النتيجة عند كل اللاعبين (seed ثابت)

var g
var root: Node3D
var spawns: Array = []
var spots: Array = []      # {pos, name}
var lamps: Array = []      # أضواء ثابتة (تُطفأ في الجرافيك المنخفض)
var flickers: Array = []   # أضواء ترمش
var env := {}
var half := 40.0
var rng := RandomNumberGenerator.new()
var car_pos := Vector3.ZERO
var car_yaw := 0.0
var car_light: OmniLight3D
var step_name := "step"
var monster_spawn := Vector3.ZERO
var pits: Array = []
var part_points: Array = []
var buckets := {}

func build(idx: int, parent: Node3D, gfx) -> void:
	g = gfx
	root = Node3D.new()
	root.name = "MapRoot"
	parent.add_child(root)
	match idx:
		0:
			rng.seed = 1101
			_alley()
		1:
			rng.seed = 2202
			_school()
		2:
			rng.seed = 3303
			_forest()
		_:
			rng.seed = 4404
			_granny_house()

# ───────────── أدوات ─────────────
func box(pos: Vector3, size: Vector3, mat: String, collide: bool = true, yaw: float = 0.0) -> Node3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = g.get_mat(mat)
	var holder: Node3D = mi
	if collide:
		var b := StaticBody3D.new()
		b.collision_layer = 1
		b.collision_mask = 0
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = size
		cs.shape = bs
		b.add_child(cs)
		b.add_child(mi)
		holder = b
	holder.position = pos + Vector3(0, size.y * 0.5, 0)
	holder.rotation.y = yaw
	root.add_child(holder)
	return holder

func cyl(pos: Vector3, radius: float, height: float, mat: String, collide: bool = true, segs: int = 12) -> Node3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = segs
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = g.get_mat(mat)
	var holder: Node3D = mi
	if collide:
		var b := StaticBody3D.new()
		b.collision_layer = 1
		b.collision_mask = 0
		var cs := CollisionShape3D.new()
		var sh := CylinderShape3D.new()
		sh.radius = radius
		sh.height = height
		cs.shape = sh
		b.add_child(cs)
		b.add_child(mi)
		holder = b
	holder.position = pos + Vector3(0, height * 0.5, 0)
	root.add_child(holder)
	return holder

func ground(size: float, mat: String) -> void:
	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(size, size)
	mi.mesh = pm
	mi.material_override = g.get_mat(mat)
	root.add_child(mi)

func invisible_wall(pos: Vector3, size: Vector3) -> void:
	var b := StaticBody3D.new()
	b.collision_layer = 1
	b.collision_mask = 0
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	b.add_child(cs)
	b.position = pos + Vector3(0, size.y * 0.5, 0)
	root.add_child(b)

func ring_walls(h: float, height: float, mat: String) -> void:
	var l := h * 2.0 + 2.0
	box(Vector3(0, 0, -h), Vector3(l, height, 1.0), mat)
	box(Vector3(0, 0, h), Vector3(l, height, 1.0), mat)
	box(Vector3(-h, 0, 0), Vector3(1.0, height, l), mat)
	box(Vector3(h, 0, 0), Vector3(1.0, height, l), mat)

func add_spot(pos: Vector3, nm: String) -> void:
	spots.append({"pos": Vector3(pos.x, 0, pos.z), "name": nm})

func add_light(pos: Vector3, col: Color, energy: float, rng_m: float, flicker: bool = false) -> void:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = col
	l.light_energy = energy
	l.omni_range = rng_m
	l.omni_attenuation = 1.3
	root.add_child(l)
	l.set_meta("base", energy)
	if flicker:
		flickers.append(l)
	lamps.append(l)

func multi(mesh: Mesh, mat: String, xforms: Array) -> void:
	if xforms.is_empty():
		return
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = g.get_mat(mat)
	root.add_child(mmi)

func far_from_spawns(p: Vector2, r: float) -> bool:
	for s in spawns:
		if Vector2(s.x, s.z).distance_to(p) < r:
			return false
	return true

# ───────────── الخريطة 0: الحارة القديمة ─────────────
func _alley() -> void:
	half = 72.0
	env = {"name": "الحارة القديمة", "bg": Color(0.02, 0.03, 0.07), "fog": Color(0.05, 0.06, 0.11), "fog_d": 0.012,
		"amb": Color(0.35, 0.4, 0.6), "amb_e": 0.6, "sun_e": 0.55, "sun_c": Color(0.6, 0.7, 1.0), "wind": 1.0}
	spawns = [Vector3(-69.2, 0, -69.2), Vector3(69.2, 0, -69.2), Vector3(-69.2, 0, 69.2), Vector3(69.2, 0, 69.2)]
	monster_spawn = Vector3(10, 0, 10)
	step_name = "step"
	_car(Vector3(0, 0, -69.3), 0.0)
	ground(half * 2.0 + 60.0, "dirt")
	ring_walls(half, 12.0, "brick")
	var lit: Array = []
	var dark: Array = []
	var mats := ["plaster_a", "plaster_b", "plaster_c", "brick"]
	for ci in 7:
		for cj in 7:
			var cx := -60.0 + ci * 20.0
			var cz := -60.0 + cj * 20.0
			var r := rng.randf()
			if r < 0.08:
				cyl(Vector3(cx, 0, cz), 1.5, 1.0, "concrete", true, 14)
				box(Vector3(cx + 4.0, 0, cz), Vector3(2.4, 0.5, 0.7), "wood", true)
				box(Vector3(cx - 4.0, 0, cz + 3.0), Vector3(0.7, 0.5, 2.4), "wood", true)
				continue
			elif r < 0.42:
				if rng.randf() < 0.5:
					_house(cx - 4.5, cz, 5.0, 14.0, mats[rng.randi() % 4], lit, dark)
					_house(cx + 4.5, cz, 5.0, 14.0, mats[rng.randi() % 4], lit, dark)
				else:
					_house(cx, cz - 4.5, 14.0, 5.0, mats[rng.randi() % 4], lit, dark)
					_house(cx, cz + 4.5, 14.0, 5.0, mats[rng.randi() % 4], lit, dark)
			else:
				_house(cx, cz, 14.0, 14.0, mats[rng.randi() % 4], lit, dark)
	var qm := QuadMesh.new()
	qm.size = Vector2(1.0, 1.5)
	multi(qm, "window_lit", lit)
	multi(qm, "window_dark", dark)
	var lines := [-50.0, -30.0, -10.0, 10.0, 30.0, 50.0]
	var placed: Array = []
	var plan := []
	for i in 6:
		plan.append("برميل")
	for i in 5:
		plan.append("صندوق")
	for i in 5:
		plan.append("عربة")
	for kind in plan:
		for t in 80:
			var line: float = lines[rng.randi() % 6]
			var along := rng.randf_range(-66.0, 66.0)
			var lat := 1.9 if rng.randf() < 0.5 else -1.9
			var p := Vector3(line + lat, 0, along) if rng.randf() < 0.5 else Vector3(along, 0, line + lat)
			var near_cross := false
			for l in lines:
				if absf(p.x - l) < 4.2:
					for l2 in lines:
						if absf(p.z - l2) < 4.2:
							near_cross = true
			if near_cross:
				continue
			if not far_from_spawns(Vector2(p.x, p.z), 9.0) or p.distance_to(car_pos) < 9.0:
				continue
			var far := true
			for q in placed:
				if q.distance_to(p) < 5.0:
					far = false
			if not far:
				continue
			placed.append(p)
			_alley_prop(kind, p)
			break
	for i in 70:
		var line2: float = lines[rng.randi() % 6]
		var along2 := rng.randf_range(-66.0, 66.0)
		var lat2 := 2.45 if rng.randf() < 0.5 else -2.45
		var p2 := Vector3(line2 + lat2, 0, along2) if rng.randf() < 0.5 else Vector3(along2, 0, line2 + lat2)
		if not far_from_spawns(Vector2(p2.x, p2.z), 6.0) or p2.distance_to(car_pos) < 7.0:
			continue
		var s := rng.randf_range(0.5, 0.9)
		box(p2, Vector3(s, s, s), "wood_dark", true, rng.randf() * 3.0)
	for lx in [-50.0, -10.0, 30.0]:
		for lz in [-50.0, -10.0, 30.0]:
			var base := Vector3(lx + 2.4, 0, lz + 2.4)
			cyl(base, 0.08, 3.4, "metal_dark", true, 6)
			var ball := MeshInstance3D.new()
			var sm := SphereMesh.new()
			sm.radius = 0.28
			sm.height = 0.56
			sm.radial_segments = 8
			sm.rings = 4
			ball.mesh = sm
			ball.material_override = g.get_mat("lamp")
			ball.position = base + Vector3(0, 3.5, 0)
			root.add_child(ball)
			add_light(base + Vector3(0, 3.3, 0), Color(1.0, 0.72, 0.4), 1.3, 14.0)

func _house(cx: float, cz: float, w: float, d: float, mat: String, lit: Array, dark: Array) -> void:
	var h := rng.randf_range(7.0, 11.0)
	box(Vector3(cx, 0, cz), Vector3(w, h, d), mat)
	box(Vector3(cx, h, cz), Vector3(w + 0.5, 0.5, d + 0.5), "concrete", false)
	var normals := [Vector2(1, 0), Vector2(-1, 0), Vector2(0, 1), Vector2(0, -1)]
	for n in normals:
		var face_len: float = d if absf(n.x) > 0.5 else w
		var off: float = (w if absf(n.x) > 0.5 else d) * 0.5 + 0.03
		var count := int(face_len / 3.4)
		var basis := Basis(Vector3.UP, atan2(n.x, n.y))
		for k in count:
			var along := -face_len * 0.5 + (k + 0.5) * face_len / float(count)
			for yy in [2.6, 5.4, 8.2]:
				if yy + 1.0 > h:
					continue
				var pos := Vector3(cx, yy, cz) + Vector3(n.x * off, 0, n.y * off)
				if absf(n.x) > 0.5:
					pos.z += along
				else:
					pos.x += along
				var xf := Transform3D(basis, pos)
				if rng.randf() < 0.3:
					lit.append(xf)
				else:
					dark.append(xf)
		# باب
		if rng.randf() < 0.6:
			var dpos := Vector3(cx, 1.15, cz) + Vector3(n.x * (off + 0.01), 0, n.y * (off + 0.01))
			var dm := MeshInstance3D.new()
			var q := QuadMesh.new()
			q.size = Vector2(1.3, 2.3)
			dm.mesh = q
			dm.material_override = g.get_mat("wood_dark")
			dm.transform = Transform3D(basis, dpos)
			root.add_child(dm)
		# مشربية
		if rng.randf() < 0.25:
			var bpos := Vector3(cx, 4.4, cz) + Vector3(n.x * (off + 0.45), 0, n.y * (off + 0.45))
			var bs := Vector3(2.8, 1.3, 0.9) if absf(n.y) > 0.5 else Vector3(0.9, 1.3, 2.8)
			box(bpos - Vector3(0, 0, 0), bs, "wood_dark", false)

func _alley_prop(kind: String, p: Vector3) -> void:
	match kind:
		"برميل":
			cyl(p, 0.85, 1.7, "wood_dark", true, 14)
			cyl(p + Vector3(0, 0.35, 0), 0.88, 0.1, "metal_dark", false, 14)
			cyl(p + Vector3(0, 1.2, 0), 0.88, 0.1, "metal_dark", false, 14)
		"صندوق":
			box(p, Vector3(1.9, 1.7, 1.9), "wood", true, rng.randf() * 0.6)
		_:
			box(p, Vector3(2.7, 1.5, 1.6), "wood_dark", true)
			box(p + Vector3(0, 1.1, 0), Vector3(2.4, 0.5, 1.4), "cloth", false)
			cyl(p + Vector3(1.0, 0.0, 0.9), 0.5, 0.15, "metal_dark", false, 10)
	add_spot(p, kind)

# ───────────── الخريطة 1: المدرسة المهجورة ─────────────
func _school() -> void:
	half = 60.0
	var H := 3.4
	env = {"name": "المدرسة المهجورة", "bg": Color(0.01, 0.02, 0.02), "fog": Color(0.04, 0.07, 0.06), "fog_d": 0.03,
		"amb": Color(0.45, 0.55, 0.5), "amb_e": 0.45, "sun_e": 0.0, "sun_c": Color(0.6, 0.7, 1.0), "wind": 0.6}
	spawns = [Vector3(-58, 0, -58), Vector3(58, 0, -58), Vector3(-58, 0, 58), Vector3(58, 0, 58)]
	monster_spawn = Vector3(0, 0, 0)
	step_name = "step_tile"
	_car(Vector3(0, 0, 58.0), 0.0)
	ground(half * 2.0 + 10.0, "tile")
	box(Vector3(0, H, 0), Vector3(half * 2.0 + 2.0, 0.4, half * 2.0 + 2.0), "ceiling", false)
	ring_walls(half, H + 0.4, "school_wall")
	var centers := [-48.0, -24.0, 0.0, 24.0, 48.0]
	var room_i := 0
	for cx in centers:
		for cz in centers:
			var door := rng.randi() % 4
			var doors := [door]
			if cx == 0.0 and cz == 0.0:
				doors = [0, 2]
			_room(cx, cz, doors, H)
			var bside := 3
			for cand in [3, 2, 1, 0]:
				if not doors.has(cand):
					bside = cand
					break
			var bp := Vector3(cx, 1.0, cz)
			match bside:
				0: box(bp + Vector3(7.7, 0, 0), Vector3(0.1, 1.4, 5.0), "board", false)
				1: box(bp + Vector3(-7.7, 0, 0), Vector3(0.1, 1.4, 5.0), "board", false)
				2: box(bp + Vector3(0, 0, 7.7), Vector3(5.0, 1.4, 0.1), "board", false)
				_: box(bp + Vector3(0, 0, -7.7), Vector3(5.0, 1.4, 0.1), "board", false)
			for dx in [-3.5, 3.5]:
				for dz in [-3.2, 3.2]:
					box(Vector3(cx + dx, 0, cz + dz), Vector3(1.3, 0.8, 0.7), "wood", true)
			if room_i % 4 == 0:
				var wside: int = doors[0] ^ 1
				var wpos := Vector3(cx, 0, cz)
				var wsize := Vector3(1.6, 2.3, 0.8)
				match wside:
					0:
						wpos += Vector3(7.35, 0, 4.5)
						wsize = Vector3(0.8, 2.3, 1.6)
					1:
						wpos += Vector3(-7.35, 0, 4.5)
						wsize = Vector3(0.8, 2.3, 1.6)
					2: wpos += Vector3(4.5, 0, 7.35)
					_: wpos += Vector3(4.5, 0, -7.35)
				box(wpos, wsize, "wood_dark", true)
				add_spot(wpos, "دولاب")
			if room_i % 4 == 2:
				var ls := 0
				for cand2 in [1, 0, 3, 2]:
					if not doors.has(cand2):
						ls = cand2
						break
				for off in [-5.0, 5.0]:
					var lp := Vector3(cx, 0, cz)
					var lsz := Vector3(1.0, 2.2, 0.9)
					match ls:
						0:
							lp += Vector3(8.65, 0, off)
							lsz = Vector3(0.9, 2.2, 1.0)
						1:
							lp += Vector3(-8.65, 0, off)
							lsz = Vector3(0.9, 2.2, 1.0)
						2: lp += Vector3(off, 0, 8.65)
						_: lp += Vector3(off, 0, -8.65)
					box(lp, lsz, "metal", true)
					add_spot(lp, "خزانة")
			room_i += 1
	var lines := [-36.0, -12.0, 12.0, 36.0]
	for c in lines:
		for along in centers:
			box(Vector3(along, H - 0.1, c), Vector3(2.6, 0.08, 0.3), "tube", false)
			box(Vector3(c, H - 0.1, along), Vector3(0.3, 0.08, 2.6), "tube", false)
	var li := 0
	for lx in lines:
		for lz in lines:
			add_light(Vector3(lx, 2.9, lz), Color(0.8, 1.0, 0.88), 1.0, 12.0, li % 3 == 0)
			li += 1

func _room(cx: float, cz: float, doors: Array, H: float) -> void:
	var t := 0.4
	var gap := 3.4
	var seg := (16.0 - gap) * 0.5
	var sh := (gap + seg) * 0.5
	for s in 4:
		var has_door := doors.has(s)
		match s:
			0, 1:
				var x := cx + (8.0 if s == 0 else -8.0)
				if has_door:
					box(Vector3(x, 0, cz - sh), Vector3(t, H, seg + t), "school_wall")
					box(Vector3(x, 0, cz + sh), Vector3(t, H, seg + t), "school_wall")
				else:
					box(Vector3(x, 0, cz), Vector3(t, H, 16.0 + t), "school_wall")
			_:
				var z := cz + (8.0 if s == 2 else -8.0)
				if has_door:
					box(Vector3(cx - sh, 0, z), Vector3(seg + t, H, t), "school_wall")
					box(Vector3(cx + sh, 0, z), Vector3(seg + t, H, t), "school_wall")
				else:
					box(Vector3(cx, 0, z), Vector3(16.0 + t, H, t), "school_wall")

# ───────────── الخريطة 2: الغابة المهجورة ─────────────
func _bk(p: Vector2) -> Vector2i:
	return Vector2i(floori(p.x / 8.0), floori(p.y / 8.0))

func _bucket_free(p: Vector2, r: float, margin: float) -> bool:
	var b := _bk(p)
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			var key := Vector2i(b.x + dx, b.y + dz)
			if buckets.has(key):
				for q in buckets[key]:
					if p.distance_to(q[0]) < r + q[1] + margin:
						return false
	return true

func _bucket_take(p: Vector2, r: float) -> void:
	var key := _bk(p)
	if not buckets.has(key):
		buckets[key] = []
	buckets[key].append([p, r])

func _pit(hatch: Vector3) -> void:
	var cx := hatch.x
	var cz := hatch.z
	box(Vector3(cx, 0.0, cz), Vector3(2.4, 0.14, 2.4), "metal_dark", false)
	box(Vector3(cx, 0.14, cz), Vector3(2.0, 0.05, 0.25), "wood_dark", false)
	box(Vector3(cx, 0.14, cz), Vector3(0.25, 0.05, 2.0), "wood_dark", false)
	var y0 := -30.0
	box(Vector3(cx, y0 - 0.3, cz), Vector3(6.0, 0.3, 6.0), "concrete", false)
	box(Vector3(cx, y0, cz - 3.0), Vector3(6.0, 3.5, 0.3), "brick", false)
	box(Vector3(cx, y0, cz + 3.0), Vector3(6.0, 3.5, 0.3), "brick", false)
	box(Vector3(cx - 3.0, y0, cz), Vector3(0.3, 3.5, 6.0), "brick", false)
	box(Vector3(cx + 3.0, y0, cz), Vector3(0.3, 3.5, 6.0), "brick", false)
	box(Vector3(cx, y0 + 3.5, cz), Vector3(6.6, 0.3, 6.6), "concrete", false)
	box(Vector3(cx + 1.8, y0, cz - 2.0), Vector3(0.9, 0.9, 0.9), "wood", false)
	box(Vector3(cx - 2.0, y0, cz + 1.0), Vector3(0.7, 1.4, 0.7), "metal_dark", false)
	add_light(Vector3(cx, y0 + 2.6, cz), Color(1.0, 0.7, 0.4), 1.6, 9.0)
	pits.append({"hatch": Vector3(cx, 0, cz), "part": Vector3(cx, y0 + 1.0, cz - 0.2), "entry": Vector3(cx, y0, cz + 1.2)})

func _forest() -> void:
	half = 88.0
	env = {"name": "الغابة المهجورة", "bg": Color(0.02, 0.03, 0.04), "fog": Color(0.05, 0.08, 0.09), "fog_d": 0.03,
		"amb": Color(0.3, 0.4, 0.5), "amb_e": 0.55, "sun_e": 0.7, "sun_c": Color(0.55, 0.65, 0.95), "wind": 1.25}
	spawns = [Vector3(-84, 0, -84), Vector3(84, 0, -84), Vector3(-84, 0, 84), Vector3(84, 0, 84)]
	monster_spawn = Vector3(0, 0, 0)
	step_name = "step_grass"
	_car(Vector3(0, 0, -84.0), 0.0)
	ground(half * 2.0 + 80.0, "grass")
	var hh := half + 1.0
	invisible_wall(Vector3(0, 0, -hh), Vector3(half * 2 + 4, 8, 2))
	invisible_wall(Vector3(0, 0, hh), Vector3(half * 2 + 4, 8, 2))
	invisible_wall(Vector3(-hh, 0, 0), Vector3(2, 8, half * 2 + 4))
	invisible_wall(Vector3(hh, 0, 0), Vector3(2, 8, half * 2 + 4))
	_cabin()
	buckets.clear()
	_bucket_take(Vector2(0, 0), 9.0)
	_bucket_take(Vector2(car_pos.x, car_pos.z), 7.0)
	# حفر تحت الأرض فيها قطع المحرك
	var pit_pts: Array = []
	for k in 400:
		if pit_pts.size() >= 5:
			break
		var pp := Vector2(rng.randf_range(-80.0, 80.0), rng.randf_range(-80.0, 80.0))
		if not far_from_spawns(pp, 30.0) or pp.length() < 22.0 or pp.distance_to(Vector2(car_pos.x, car_pos.z)) < 25.0:
			continue
		var ok := true
		for q in pit_pts:
			if pp.distance_to(q) < 38.0:
				ok = false
		if ok:
			pit_pts.append(pp)
	for pp2 in pit_pts:
		_pit(Vector3(pp2.x, 0, pp2.y))
		_bucket_take(pp2, 3.0)
	var trunk_x: Array = []
	var cone1_x: Array = []
	var cone2_x: Array = []
	var plan: Array = []
	for i in 12:
		plan.append("شجيرة")
	for i in 4:
		plan.append("جذع")
	for i in 4:
		plan.append("قش")
	for i in 60:
		plan.append("صخرة")
	for i in 420:
		plan.append("شجرة")
	for kind in plan:
		var r := 0.5
		match kind:
			"شجيرة": r = 1.3
			"جذع": r = 1.8
			"قش": r = 1.4
			"صخرة": r = 1.0
		for t in 40:
			var p := Vector2(rng.randf_range(-85.0, 85.0), rng.randf_range(-85.0, 85.0))
			if absf(p.x) < 9.5 and absf(p.y) < 8.5:
				continue
			if not far_from_spawns(p, 8.0):
				continue
			if not _bucket_free(p, r, 2.6 if kind != "صخرة" else 1.5):
				continue
			_bucket_take(p, r)
			var pos := Vector3(p.x, 0, p.y)
			match kind:
				"شجرة":
					var s := rng.randf_range(0.85, 1.35)
					var yaw := rng.randf() * TAU
					var b := Basis(Vector3.UP, yaw).scaled(Vector3(s, s, s))
					trunk_x.append(Transform3D(b, pos + Vector3(0, 3.0 * s, 0)))
					cone1_x.append(Transform3D(b, pos + Vector3(0, 5.1 * s, 0)))
					cone2_x.append(Transform3D(b, pos + Vector3(0, 6.9 * s, 0)))
					var tb := StaticBody3D.new()
					tb.collision_layer = 1
					tb.collision_mask = 0
					var cs := CollisionShape3D.new()
					var sh := CylinderShape3D.new()
					sh.radius = 0.45 * s
					sh.height = 3.0
					cs.shape = sh
					tb.add_child(cs)
					tb.position = pos + Vector3(0, 1.5, 0)
					root.add_child(tb)
				"شجيرة":
					var sb := StaticBody3D.new()
					sb.collision_layer = 1
					sb.collision_mask = 0
					var mi := MeshInstance3D.new()
					var sm := SphereMesh.new()
					sm.radius = 1.15
					sm.height = 2.0
					sm.radial_segments = 10
					sm.rings = 5
					mi.mesh = sm
					mi.material_override = g.get_mat("leaves2")
					mi.scale = Vector3(1.25, 1.0, 1.25)
					mi.position = Vector3(0, 0.9, 0)
					sb.add_child(mi)
					var cs2 := CollisionShape3D.new()
					var sh2 := CylinderShape3D.new()
					sh2.radius = 1.3
					sh2.height = 1.8
					cs2.shape = sh2
					cs2.position = Vector3(0, 0.9, 0)
					sb.add_child(cs2)
					sb.position = pos
					root.add_child(sb)
					add_spot(pos, "شجيرة")
				"جذع":
					var lb := StaticBody3D.new()
					lb.collision_layer = 1
					lb.collision_mask = 0
					lb.rotation.y = rng.randf() * PI
					var lm := MeshInstance3D.new()
					var lc := CylinderMesh.new()
					lc.top_radius = 0.75
					lc.bottom_radius = 0.75
					lc.height = 3.4
					lc.radial_segments = 10
					lm.mesh = lc
					lm.material_override = g.get_mat("bark")
					lm.rotation.z = PI * 0.5
					lm.position = Vector3(0, 0.75, 0)
					lb.add_child(lm)
					var lcs := CollisionShape3D.new()
					var lbx := BoxShape3D.new()
					lbx.size = Vector3(3.4, 1.5, 1.5)
					lcs.shape = lbx
					lcs.position = Vector3(0, 0.75, 0)
					lb.add_child(lcs)
					lb.position = pos
					root.add_child(lb)
					add_spot(pos, "جذع شجرة")
				"قش":
					var hb := StaticBody3D.new()
					hb.collision_layer = 1
					hb.collision_mask = 0
					var hm := MeshInstance3D.new()
					var hc := CylinderMesh.new()
					hc.top_radius = 0.3
					hc.bottom_radius = 1.5
					hc.height = 2.4
					hc.radial_segments = 10
					hm.mesh = hc
					hm.material_override = g.get_mat("hay")
					hm.position = Vector3(0, 1.2, 0)
					hb.add_child(hm)
					var hcs := CollisionShape3D.new()
					var hsh := CylinderShape3D.new()
					hsh.radius = 1.3
					hsh.height = 2.4
					hcs.shape = hsh
					hcs.position = Vector3(0, 1.2, 0)
					hb.add_child(hcs)
					hb.position = pos
					root.add_child(hb)
					add_spot(pos, "كومة قش")
				_:
					var rs := rng.randf_range(0.7, 1.3)
					var rb := StaticBody3D.new()
					rb.collision_layer = 1
					rb.collision_mask = 0
					var rm := MeshInstance3D.new()
					var rsm := SphereMesh.new()
					rsm.radius = 1.0
					rsm.height = 2.0
					rsm.radial_segments = 8
					rsm.rings = 4
					rm.mesh = rsm
					rm.material_override = g.get_mat("rock")
					rm.scale = Vector3(1.3 * rs, 0.8 * rs, 1.1 * rs)
					rm.position = Vector3(0, 0.4 * rs, 0)
					rb.add_child(rm)
					var rcs := CollisionShape3D.new()
					var rsh := CylinderShape3D.new()
					rsh.radius = 1.0 * rs
					rsh.height = 1.0 * rs
					rcs.shape = rsh
					rcs.position = Vector3(0, 0.4 * rs, 0)
					rb.add_child(rcs)
					rb.position = pos
					rb.rotation.y = rng.randf() * TAU
					root.add_child(rb)
			break
	var tm := CylinderMesh.new()
	tm.top_radius = 0.22
	tm.bottom_radius = 0.4
	tm.height = 6.0
	tm.radial_segments = 7
	tm.rings = 1
	multi(tm, "bark", trunk_x)
	var c1 := CylinderMesh.new()
	c1.top_radius = 0.0
	c1.bottom_radius = 2.4
	c1.height = 4.2
	c1.radial_segments = 8
	c1.rings = 1
	multi(c1, "leaves", cone1_x)
	var c2 := CylinderMesh.new()
	c2.top_radius = 0.0
	c2.bottom_radius = 1.8
	c2.height = 3.4
	c2.radial_segments = 8
	c2.rings = 1
	multi(c2, "leaves2", cone2_x)

func _cabin() -> void:
	var H := 3.0
	var t := 0.4
	var gap := 3.0
	# جدران الكوخ 10 × 8 والباب في الجهة +z
	box(Vector3(0, 0, -4.0), Vector3(10.4, H, t), "wood_dark")
	box(Vector3(-5.0, 0, 0), Vector3(t, H, 8.4), "wood_dark")
	box(Vector3(5.0, 0, 0), Vector3(t, H, 8.4), "wood_dark")
	var seg := (10.0 - gap) * 0.5
	var sh := (gap + seg) * 0.5
	box(Vector3(-sh, 0, 4.0), Vector3(seg + t, H, t), "wood_dark")
	box(Vector3(sh, 0, 4.0), Vector3(seg + t, H, t), "wood_dark")
	box(Vector3(0, H, 0), Vector3(11.2, 0.3, 9.2), "roof", false)
	box(Vector3(0, 0.0, 0), Vector3(10.0, 0.05, 8.0), "wood_dark", false)
	box(Vector3(2.2, 0, -1.6), Vector3(1.8, 0.8, 1.0), "wood", true)
	box(Vector3(-3.3, 0, -2.8), Vector3(2.0, 0.6, 1.0), "wood", true)
	box(Vector3(-4.35, 0, 1.6), Vector3(0.8, 2.1, 1.6), "wood_dark", true)
	add_spot(Vector3(-4.35, 0, 1.6), "دولاب")
	add_light(Vector3(0, 2.4, 0), Color(1.0, 0.75, 0.4), 1.2, 10.0, true)

# ───────────── السيارة (هدف الهروب) ─────────────
func _car(pos: Vector3, yaw: float) -> void:
	car_pos = pos
	car_yaw = yaw
	var car := StaticBody3D.new()
	car.collision_layer = 1
	car.collision_mask = 0
	car.position = pos
	car.rotation.y = yaw
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(4.2, 1.4, 1.8)
	cs.shape = bs
	cs.position.y = 0.7
	car.add_child(cs)
	root.add_child(car)
	var body_m: Material = g.get_mat("metal_dark")
	var paint := StandardMaterial3D.new()
	paint.albedo_color = Color(0.55, 0.1, 0.08)
	paint.roughness = 0.45
	paint.metallic = 0.5
	var parts := [
		[Vector3(0, 0.55, 0), Vector3(4.2, 0.7, 1.8), paint],
		[Vector3(-0.5, 1.15, 0), Vector3(2.0, 0.65, 1.6), paint],
		[Vector3(1.45, 0.95, 0), Vector3(1.2, 0.08, 1.5), body_m],
		[Vector3(1.4, 0.72, 0), Vector3(1.2, 0.1, 1.4), g.get_mat("metal_dark")],
	]
	for p in parts:
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = p[1]
		mi.mesh = bm
		mi.material_override = p[2]
		mi.position = p[0]
		car.add_child(mi)
	# غطاء المحرك مفتوح (مائل) والمحرك ناقص
	var hood := MeshInstance3D.new()
	var hm := BoxMesh.new()
	hm.size = Vector3(1.3, 0.06, 1.6)
	hood.mesh = hm
	hood.material_override = paint
	hood.position = Vector3(1.0, 1.55, 0)
	hood.rotation.z = -1.0
	car.add_child(hood)
	for wx in [-1.3, 1.3]:
		for wz in [-0.95, 0.95]:
			var w := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.38
			cm.bottom_radius = 0.38
			cm.height = 0.3
			cm.radial_segments = 10
			w.mesh = cm
			w.material_override = g.get_mat("metal_dark")
			w.position = Vector3(wx, 0.38, wz)
			w.rotation.x = PI * 0.5
			car.add_child(w)
	for hz in [-0.6, 0.6]:
		var hl := MeshInstance3D.new()
		var hb := BoxMesh.new()
		hb.size = Vector3(0.08, 0.2, 0.35)
		hl.mesh = hb
		hl.material_override = g.get_mat("lamp")
		hl.position = Vector3(2.1, 0.65, hz)
		car.add_child(hl)
	car_light = OmniLight3D.new()
	car_light.position = Vector3(0, 2.2, 0)
	car_light.light_color = Color(1.0, 0.2, 0.15)
	car_light.light_energy = 1.2
	car_light.omni_range = 9.0
	car.add_child(car_light)


# ───────────── الخريطة 3: بيت جراني ─────────────
func hwall(x1: float, x2: float, z: float, gaps: Array, mat: String, h: float = 3.2) -> void:
	var cur := x1
	var gs := gaps.duplicate()
	gs.sort_custom(func(a, b): return a.x < b.x)
	for g in gs:
		var a: float = g.x - g.y * 0.5
		if a > cur + 0.05:
			box(Vector3((cur + a) * 0.5, 0, z), Vector3(a - cur, h, 0.3), mat)
		cur = g.x + g.y * 0.5
	if x2 > cur + 0.05:
		box(Vector3((cur + x2) * 0.5, 0, z), Vector3(x2 - cur, h, 0.3), mat)

func vwall(z1: float, z2: float, x: float, gaps: Array, mat: String, h: float = 3.2) -> void:
	var cur := z1
	var gs := gaps.duplicate()
	gs.sort_custom(func(a, b): return a.x < b.x)
	for g in gs:
		var a: float = g.x - g.y * 0.5
		if a > cur + 0.05:
			box(Vector3(x, 0, (cur + a) * 0.5), Vector3(0.3, h, a - cur), mat)
		cur = g.x + g.y * 0.5
	if z2 > cur + 0.05:
		box(Vector3(x, 0, (cur + z2) * 0.5), Vector3(0.3, h, z2 - cur), mat)

func fur(x: float, z: float, size: Vector3, mat: String, collide: bool = true, yaw: float = 0.0, y: float = 0.0) -> Node3D:
	return box(Vector3(x, y, z), size, mat, collide, yaw)

func floor_rect(x1: float, x2: float, z1: float, z2: float, mat: String) -> void:
	box(Vector3((x1 + x2) * 0.5, 0.0, (z1 + z2) * 0.5), Vector3(x2 - x1, 0.03, z2 - z1), mat, false)

func _granny_house() -> void:
	half = 31.0
	var H := 3.2
	env = {"name": "بيت جراني", "bg": Color(0.015, 0.015, 0.025), "fog": Color(0.05, 0.045, 0.05), "fog_d": 0.022,
		"amb": Color(0.5, 0.45, 0.5), "amb_e": 0.38, "sun_e": 0.0, "sun_c": Color(0.6, 0.7, 1.0), "wind": 0.7, "amb_loop": "amb_house"}
	spawns = [Vector3(-27, 0, -8), Vector3(27, 0, -8), Vector3(-24, 0, 8), Vector3(10, 0, 8)]
	monster_spawn = Vector3(0, 0, 0)
	step_name = "step_wood"
	_car(Vector3(23, 0, 14), 0.0)
	ground(160.0, "grass")
	# الأرضيات
	floor_rect(-30, -8, -22, -2, "wood_floor")
	floor_rect(-8, 10, -22, -2, "marble")
	floor_rect(10, 30, -22, -2, "wood_floor")
	floor_rect(-30, 30, -2, 2, "wood_dark")
	floor_rect(-30, -12, 2, 22, "wood_floor")
	floor_rect(-12, -2, 2, 22, "marble")
	floor_rect(-2, 16, 2, 22, "wood_floor")
	floor_rect(16, 30, 2, 22, "garage_floor")
	box(Vector3(0, H, 0), Vector3(62.0, 0.4, 46.0), "ceiling", false)
	# سقف مائل خارجي (يظهر في القائمة فقط)
	for sg in [-1.0, 1.0]:
		var rf := box(Vector3(0, H + 3.2, 11.6 * sg), Vector3(64.0, 0.3, 24.0), "roof", false)
		rf.rotation.x = 0.27 * sg
	# الجدران الخارجية
	hwall(-30, 30, -22, [], "wallpaper2")
	hwall(-30, 30, 22, [], "wallpaper2")
	vwall(-22, 22, -30, [], "wallpaper")
	vwall(-22, 22, 30, [], "wallpaper")
	# جدران الممر مع الأبواب
	hwall(-30, 30, -2, [Vector2(-19, 3.2), Vector2(1, 3.2), Vector2(20, 3.2)], "white_paint")
	hwall(-30, 30, 2, [Vector2(-21, 3.2), Vector2(-7, 3.2), Vector2(7, 3.2), Vector2(23, 5.0)], "white_paint")
	vwall(-22, -2, -8, [Vector2(-12, 3.2)], "wallpaper")
	vwall(-22, -2, 10, [Vector2(-12, 3.2)], "wallpaper")
	vwall(2, 22, -12, [Vector2(12, 3.2)], "wallpaper2")
	vwall(2, 22, -2, [Vector2(12, 3.2)], "wallpaper")
	vwall(2, 22, 16, [], "white_paint")
	# نوافذ ضوء القمر والستائر
	for wx in [-24.0, -14.0, 4.0, 18.0, 26.0]:
		box(Vector3(wx, 1.0, -21.82), Vector3(1.6, 1.3, 0.06), "window_moon", false)
		box(Vector3(wx, 0.4, -21.7), Vector3(2.2, 2.4, 0.12), "curtain", false)
	for wx2 in [-26.0, -18.0, 0.0, 8.0, 12.0]:
		box(Vector3(wx2, 1.0, 21.82), Vector3(1.6, 1.3, 0.06), "window_moon", false)
	# ── غرفة المعيشة
	fur(-19, -12, Vector3(8, 0.03, 5), "carpet", false)
	fur(-19, -20.6, Vector3(6, 0.5, 1.8), "sofa")
	fur(-19, -21.4, Vector3(6, 1.1, 0.5), "sofa")
	fur(-19, -13.5, Vector3(2.2, 0.5, 1.2), "wood_dark")
	fur(-29.3, -12, Vector3(0.6, 0.6, 3.0), "wood_dark")
	fur(-29.5, -12, Vector3(0.12, 1.0, 1.8), "metal_dark")
	fur(-26, -21.5, Vector3(3.0, 2.2, 0.5), "wood_dark")
	fur(-25, -7.5, Vector3(1.2, 0.9, 1.2), "sofa")
	fur(-8.8, -19, Vector3(0.8, 2.0, 1.6), "wood_dark")
	add_spot(Vector3(-8.8, 0, -19), "خزانة")
	# ── المطبخ
	fur(1, -21.5, Vector3(14, 0.9, 0.7), "marble")
	fur(1, -12, Vector3(3.5, 0.9, 1.4), "marble")
	fur(8.8, -20.5, Vector3(1.0, 2.0, 0.9), "metal")
	fur(-5, -21.4, Vector3(1.4, 0.9, 0.7), "metal_dark")
	fur(-6.9, -7, Vector3(0.7, 0.9, 3.0), "marble")
	# ── غرفة الطعام
	fur(20, -12, Vector3(6, 0.8, 2.4), "wood")
	for cx in [-2.2, 0.0, 2.2]:
		fur(20 + cx, -14.0, Vector3(0.55, 0.9, 0.55), "wood_dark")
		fur(20 + cx, -10.0, Vector3(0.55, 0.9, 0.55), "wood_dark")
	fur(29.3, -12, Vector3(0.8, 2.2, 2.4), "wood_dark")
	add_spot(Vector3(29.3, 0, -12), "خزانة")
	fur(20, -21.5, Vector3(5, 0.9, 0.6), "wood_dark")
	# ── الممر
	fur(0, 0, Vector3(40, 0.03, 1.6), "carpet", false)
	fur(-28.5, 0, Vector3(0.7, 2.4, 0.5), "wood_dark")
	fur(28.5, 0, Vector3(0.5, 0.9, 1.4), "wood_dark")
	for fx in [-24.0, -14.0, -4.0, 6.0, 16.0, 25.0]:
		box(Vector3(fx, 1.3, -1.82), Vector3(0.7, 0.9, 0.05), "wood_dark", false)
		box(Vector3(fx + 0.5, 1.3, 1.82), Vector3(0.6, 0.8, 0.05), "wood_dark", false)
	# ── غرفة النوم أ
	fur(-27.5, 18, Vector3(2.0, 0.6, 2.2), "carpet")
	fur(-27.5, 19.2, Vector3(2.0, 1.2, 0.3), "wood_dark")
	add_spot(Vector3(-27.5, 0, 18), "تحت السرير")
	fur(-21, 21.3, Vector3(2.4, 2.2, 0.7), "wood_dark")
	add_spot(Vector3(-21, 0, 21.3), "دولاب")
	fur(-25.6, 20, Vector3(0.5, 0.5, 0.5), "wood_dark")
	fur(-12.7, 18, Vector3(0.6, 1.0, 1.8), "wood_dark")
	# ── الحمام
	fur(-7, 20.4, Vector3(4.5, 0.6, 1.6), "marble")
	add_spot(Vector3(-7, 0, 20.4), "حوض الاستحمام")
	fur(-3.6, 15, Vector3(0.6, 0.7, 0.8), "white_paint")
	fur(-10.8, 15, Vector3(0.6, 0.9, 1.2), "marble")
	# ── غرفة النوم ب
	fur(7, 19.4, Vector3(2.2, 0.6, 2.2), "carpet")
	fur(7, 20.6, Vector3(2.2, 1.2, 0.3), "wood_dark")
	add_spot(Vector3(7, 0, 19.4), "تحت السرير")
	fur(14.6, 21.3, Vector3(2.4, 2.2, 0.7), "wood_dark")
	add_spot(Vector3(14.6, 0, 21.3), "دولاب")
	fur(0, 21, Vector3(2.0, 0.8, 0.8), "wood")
	# ── الجراج
	fur(29.3, 8, Vector3(0.8, 0.9, 3.5), "metal_dark")
	fur(29.4, 18, Vector3(0.6, 2.0, 3.0), "metal")
	fur(18, 20.4, Vector3(1.4, 1.4, 1.4), "wood")
	add_spot(Vector3(18, 0, 20.4), "صندوق")
	fur(28, 4, Vector3(1.4, 1.4, 1.4), "wood")
	add_spot(Vector3(28, 0, 4), "صندوق")
	cyl(Vector3(19.5, 0, 5), 0.5, 0.8, "metal_dark", true, 10)
	# أضواء الغرف
	var lp_list := [
		[Vector3(-19, 2.8, -12), Color(1.0, 0.72, 0.45), 1.1, false], [Vector3(1, 2.8, -12), Color(0.85, 0.95, 1.0), 1.0, true],
		[Vector3(20, 2.8, -12), Color(1.0, 0.7, 0.4), 1.1, false], [Vector3(-18, 2.8, 0), Color(1.0, 0.75, 0.5), 0.8, false],
		[Vector3(0, 2.8, 0), Color(1.0, 0.75, 0.5), 0.9, true], [Vector3(18, 2.8, 0), Color(1.0, 0.75, 0.5), 0.8, false],
		[Vector3(-21, 2.8, 12), Color(1.0, 0.65, 0.4), 0.9, false], [Vector3(-7, 2.8, 12), Color(0.8, 1.0, 0.9), 1.0, true],
		[Vector3(7, 2.8, 12), Color(1.0, 0.7, 0.45), 0.9, false], [Vector3(23, 2.8, 12), Color(0.8, 0.9, 1.0), 1.1, true]]
	for e in lp_list:
		add_light(e[0], e[1], e[2], 12.0, e[3])
	# أماكن محتملة لقطع المحرك (تُفلتر حسب الوصول)
	part_points = [Vector3(-26, 0, -4), Vector3(-14, 0, -19), Vector3(-22, 0, -9), Vector3(6, 0, -17), Vector3(-4, 0, -5), Vector3(-1, 0, -17),
		Vector3(14, 0, -5), Vector3(26, 0, -5), Vector3(24, 0, -20), Vector3(12, 0, 0), Vector3(-16, 0, 5), Vector3(-16, 0, 20),
		Vector3(-5, 0, 5), Vector3(3, 0, 5), Vector3(12, 0, 9), Vector3(4, 0, 20), Vector3(20, 0, 5), Vector3(27, 0, 11), Vector3(18, 0, 16)]
